# دليل الربط بخدمة حقيقية (قاعدة بيانات + بوابة دفع)

> الهدف: استبدال `MockAppRepository` بخدمة حقيقية **دون تعديل أي شاشة**.
> كل ما تفعله الشاشات هو استدعاء `AppRepository` عبر المتحكّمات (`lib/state/*`).

---

## 1) نظرة عامة على الطبقات

```
Screens  →  Controllers (ChangeNotifier)  →  AppRepository  →  ApiAppRepository (HTTP)
                                                              →  MockAppRepository (الحالي)
```

الملفات التي ستمسّها:

| الملف | التغيير |
|---|---|
| `lib/data/repositories/api_app_repository.dart` | ملف جديد: تنفيذ الـ API |
| `lib/main.dart` | سطر واحد: `ApiAppRepository` بدل `MockAppRepository` |
| `pubspec.yaml` | إضافة `http` أو `dio` |
| `android/app/src/main/AndroidManifest.xml` | صلاحية `INTERNET` (موجودة) و`usesCleartextTraffic` للتطوير فقط |

---

## 2) إضافة حزمة الشبكة

```bash
flutter pub add http        # أخف وأبسط
# أو
flutter pub add dio         # إنترسبتورز، إعادة محاولة، رفع ملفات
```

---

## 3) تنفيذ `ApiAppRepository`

أنشئ الملف **`lib/data/repositories/api_app_repository.dart`**:

```dart
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../core/l10n/localized_text.dart';
import '../models/models.dart';
import 'app_repository.dart';

/// ===========================================================================
///  التنفيذ الحقيقي للبيانات عبر REST API.
///  ملاحظة أمنية: لا تضع مفاتيح سرية داخل التطبيق. الشحن يجب أن يتم باسم
///  المستخدم (token) وأن يتحقق الخادم من الدفع قبل إضافة الرصيد.
/// ===========================================================================
class ApiAppRepository implements AppRepository {
  ApiAppRepository({required this.baseUrl, this.token});

  final String baseUrl;     // مثال: https://api.example.com/v1
  String? token;            // JWT بعد تسجيل الدخول

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Uri _uri(String path) => Uri.parse('$baseUrl$path');

  // ---------------------------------- الدخول ----------------------------------
  @override
  Future<UserProfile?> signIn({
    required String username,
    required String password,
  }) async {
    final res = await http.post(
      _uri('/auth/login'),
      headers: _headers,
      body: jsonEncode({'username': username, 'password': password}),
    );
    if (res.statusCode == 401) return null;
    if (res.statusCode != 200) {
      throw Exception('login failed: ${res.statusCode}');
    }
    final json = jsonDecode(res.body) as Map<String, dynamic>;
    token = json['token'] as String?;
    return UserProfile.fromJson(json['user'] as Map<String, dynamic>);
  }

  @override
  Future<UserProfile?> currentUser() async {
    if (token == null) return null;
    final res = await http.get(_uri('/auth/me'), headers: _headers);
    if (res.statusCode != 200) return null;
    return UserProfile.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  @override
  Future<UserProfile> register({
    required String fullName,
    required String phone,
    required String email,
    required String password,
    required String meterNumber,
  }) async {
    final res = await http.post(
      _uri('/auth/register'),
      headers: _headers,
      body: jsonEncode({
        'full_name': fullName,
        'phone': phone,
        'email': email,
        'password': password,
        'meter_number': meterNumber,
      }),
    );
    if (res.statusCode != 201) {
      throw Exception('register failed: ${res.statusCode}');
    }
    final json = jsonDecode(res.body) as Map<String, dynamic>;
    token = json['token'] as String?;
    return UserProfile.fromJson(json['user'] as Map<String, dynamic>);
  }

  @override
  Future<UserProfile> updateProfile(UserProfile user) async {
    final res = await http.put(
      _uri('/profile'),
      headers: _headers,
      body: jsonEncode(user.toJson()),
    );
    if (res.statusCode != 200) throw Exception('update failed');
    return UserProfile.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  // ---------------------------------- العدادات ----------------------------------
  @override
  Future<List<MeterModel>> fetchMeters() async {
    final res = await http.get(_uri('/meters'), headers: _headers);
    final list = jsonDecode(res.body) as List<dynamic>;
    return list
        .map((e) => MeterModel.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  @override
  Future<List<PaymentMethodModel>> fetchPaymentMethods() async {
    final res = await http.get(_uri('/payment-methods'), headers: _headers);
    final list = jsonDecode(res.body) as List<dynamic>;
    return list.map((e) {
      final m = e as Map<String, dynamic>;
      return PaymentMethodModel(
        id: m['id'] as String,
        name: L(m['name_ar'] as String, m['name_en'] as String),
        walletNumber: m['wallet_number'] as String,
        colorValue: int.parse((m['color'] as String).replaceFirst('#', '0xFF')),
        steps: (m['steps'] as List<dynamic>)
            .map((s) => L((s as Map)['ar'] as String, s['en'] as String))
            .toList(),
      );
    }).toList();
  }

  // ---------------------------------- الإيصالات ----------------------------------
  @override
  Future<List<ReceiptModel>> fetchReceipts() async {
    final res = await http.get(_uri('/receipts'), headers: _headers);
    final list = jsonDecode(res.body) as List<dynamic>;
    return list
        .map((e) => ReceiptModel.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// الشحن: يجب أن ينشئ الخادم الإيصال بعد تأكيد الدفع من المزوّد
  @override
  Future<ReceiptModel> createTopUp({
    required MeterModel meter,
    required double amount,
    required PaymentMethodModel method,
  }) async {
    final res = await http.post(
      _uri('/topups'),
      headers: _headers,
      body: jsonEncode({
        'meter_id': meter.id,
        'meter_number': meter.number,
        'amount': amount,
        'method_id': method.id,
        'idempotency_key': DateTime.now().microsecondsSinceEpoch.toString(),
      }),
    );
    if (res.statusCode != 201) {
      // 402 = الدفع مرفوض، 409 = عملية مكررة، 422 = بيانات غير صحيحة
      throw Exception('topup failed: ${res.statusCode} ${res.body}');
    }
    return ReceiptModel.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  // ---------------------------------- الاستهلاك ----------------------------------
  @override
  Future<ConsumptionSummary> fetchConsumption(ConsumptionRange range) async {
    final res = await http.get(
      _uri('/consumption?range=${range.name}'),
      headers: _headers,
    );
    final json = jsonDecode(res.body) as Map<String, dynamic>;

    List<ConsumptionPoint> parse(String key) =>
        (json[key] as List<dynamic>).map((e) {
          final p = e as Map<String, dynamic>;
          return ConsumptionPoint(p['label'] as String, (p['value'] as num).toDouble());
        }).toList();

    return ConsumptionSummary(
      totalKwh: (json['total_kwh'] as num).toDouble(),
      averageDaily: (json['average_daily'] as num).toDouble(),
      peakUsage: (json['peak_usage'] as num).toDouble(),
      estimatedCost: (json['estimated_cost'] as num).toDouble(),
      currentPeriod: parse('current'),
      previousPeriod: parse('previous'),
    );
  }

  // ---------------------------------- الدعم ----------------------------------
  @override
  Future<List<SupportTicket>> fetchTickets() async {
    final res = await http.get(_uri('/tickets'), headers: _headers);
    final list = jsonDecode(res.body) as List<dynamic>;
    return list.map((e) {
      final t = e as Map<String, dynamic>;
      return SupportTicket(
        id: t['id'] as String,
        title: L(t['title'] as String, t['title'] as String),
        date: DateTime.parse(t['created_at'] as String),
        status: t['status'] == 'open' ? TicketStatus.open : TicketStatus.resolved,
        reachedStep: (t['reached_step'] as num).toInt(),
      );
    }).toList();
  }

  @override
  Future<SupportTicket> createTicket({
    required String title,
    required String details,
  }) async {
    final res = await http.post(
      _uri('/tickets'),
      headers: _headers,
      body: jsonEncode({'title': title, 'details': details}),
    );
    final t = jsonDecode(res.body) as Map<String, dynamic>;
    return SupportTicket(
      id: t['id'] as String,
      title: L(title, title),
      date: DateTime.parse(t['created_at'] as String),
      status: TicketStatus.open,
      reachedStep: 0,
    );
  }

  @override
  Future<List<AppNotification>> fetchNotifications() async {
    final res = await http.get(_uri('/notifications'), headers: _headers);
    final list = jsonDecode(res.body) as List<dynamic>;
    return list.map((e) {
      final n = e as Map<String, dynamic>;
      return AppNotification(
        id: n['id'] as String,
        title: L(n['title_ar'] as String, n['title_en'] as String),
        body: L(n['body_ar'] as String, n['body_en'] as String),
        date: DateTime.parse(n['created_at'] as String),
        kind: NotificationKind.values.firstWhere(
          (k) => k.name == n['kind'],
          orElse: () => NotificationKind.system,
        ),
        read: n['read'] as bool? ?? false,
      );
    }).toList();
  }
}
```

### التبديل في `main.dart`

```dart
// قبل
final AppRepository repo = MockAppRepository();

// بعد
final AppRepository repo = ApiAppRepository(
  baseUrl: 'https://api.example.com/v1',
);
```

> إن أردت تشغيل الوضع التجريبي والوضع الحقيقي معاً (مثلاً بضغطة مطوّر):
> استخدم `--dart-define=USE_API=true` واقرأها بـ
> `const bool.fromEnvironment('USE_API')`.

---

## 4) مقترح قاعدة البيانات (MySQL / PostgreSQL)

```sql
-- المشتركون
CREATE TABLE users (
  id            BIGSERIAL PRIMARY KEY,
  full_name     VARCHAR(120) NOT NULL,
  username      VARCHAR(60) UNIQUE NOT NULL,
  phone         VARCHAR(20) UNIQUE NOT NULL,
  email         VARCHAR(160) UNIQUE,
  password_hash VARCHAR(255) NOT NULL,        -- bcrypt/argon2 (لا تخزّن كلمة المرور نصاً)
  city          VARCHAR(80),
  subscriber_no VARCHAR(30),
  created_at    TIMESTAMPTZ DEFAULT now()
);

-- العدادات
CREATE TABLE meters (
  id                  BIGSERIAL PRIMARY KEY,
  user_id             BIGINT REFERENCES users(id) ON DELETE CASCADE,
  meter_number        VARCHAR(30) UNIQUE NOT NULL,
  alias               VARCHAR(40),
  kind                VARCHAR(12) DEFAULT 'prepaid',
  balance             NUMERIC(12,2) DEFAULT 0,
  remaining_kwh       NUMERIC(12,2) DEFAULT 0,
  monthly_cap_kwh     NUMERIC(12,2) DEFAULT 400,
  used_kwh_this_month NUMERIC(12,2) DEFAULT 0,
  connected           BOOLEAN DEFAULT TRUE,
  last_sync_at        TIMESTAMPTZ
);

-- الشحنات/الإيصالات
CREATE TABLE receipts (
  id               BIGSERIAL PRIMARY KEY,
  receipt_number   VARCHAR(24) UNIQUE NOT NULL,  -- VG-2026-000128
  user_id          BIGINT REFERENCES users(id),
  meter_number     VARCHAR(30) NOT NULL,
  amount           NUMERIC(12,2) NOT NULL,
  kwh              NUMERIC(12,2) NOT NULL,
  balance_after    NUMERIC(12,2) NOT NULL,
  method_id        VARCHAR(20) NOT NULL,
  status           VARCHAR(12) DEFAULT 'completed',
  provider_ref     VARCHAR(80),                  -- مرجع بوابة الدفع
  idempotency_key  VARCHAR(80) UNIQUE,
  created_at       TIMESTAMPTZ DEFAULT now()
);

-- استهلاك دوري (نقاط الرسم البياني)
CREATE TABLE consumption_points (
  id          BIGSERIAL PRIMARY KEY,
  meter_id    BIGINT REFERENCES meters(id) ON DELETE CASCADE,
  period      VARCHAR(8) NOT NULL,   -- hours | days | months
  label       VARCHAR(12) NOT NULL,  -- 10/25
  value_kwh   NUMERIC(12,3) NOT NULL,
  recorded_at TIMESTAMPTZ DEFAULT now()
);

-- تذاكر الدعم
CREATE TABLE tickets (
  id           BIGSERIAL PRIMARY KEY,
  user_id      BIGINT REFERENCES users(id),
  title        VARCHAR(120),
  details      TEXT,
  status       VARCHAR(12) DEFAULT 'open',
  reached_step SMALLINT DEFAULT 0,
  created_at   TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE notifications (
  id         BIGSERIAL PRIMARY KEY,
  user_id    BIGINT REFERENCES users(id),
  title_ar   VARCHAR(160), title_en VARCHAR(160),
  body_ar    TEXT,         body_en TEXT,
  kind       VARCHAR(16) DEFAULT 'system',
  read       BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT now()
);
```

### نقاط نهاية مقترحة (REST)

| الطريقة | المسار | الوظيفة |
|---|---|---|
| POST | `/auth/login` | دخول → `{token, user}` |
| POST | `/auth/register` | إنشاء حساب |
| GET | `/auth/me` | المستخدم الحالي |
| GET | `/meters` | عدادات المستخدم |
| GET | `/payment-methods` | محافظ/طرق الدفع |
| GET | `/receipts` | سجل الإيصالات |
| POST | `/topups` | تنفيذ شحن (بعد تأكيد الدفع) |
| GET | `/consumption?range=days` | نقاط الاستهلاك |
| GET/POST | `/tickets` | التذاكر |
| GET | `/notifications` | الإشعارات |

---

## 5) الشحن الحقيقي (مهم جداً)

1. **لا تضع مفتاح بوابة الدفع (API Key) داخل التطبيق** — يُستخرج بسهولة من الـ APK.
2. التدفق الصحيح:
   ```
   التطبيق ──(amount, meter, method)──► سيرفرك
   سيرفرك ──(مفتاحك السري)──► بوابة الدفع (جيب/جوالي/فلوسك/بوابة بنكية)
   بوابة الدفع ──webhook──► سيرفرك  (تأكيد الدفع)
   سيرفرك: يتحقق + يضيف الرصيد + ينشئ الإيصال  ──► التطبيق (polling / push)
   ```
3. استخدم `idempotency_key` لتجنّب الشحن المزدوج عند انقطاع الشبكة.
4. لا تعتمد أبداً على قيمة «الرصيد» القادمة من التطبيق؛ احسبها في الخادم.
5. عند الحاجة إلى تنبيه فوري: Firebase Cloud Messaging (FCM) عبر حزمة `firebase_messaging`.

---

## 6) حفظ الإيصال في معرض الصور (اختياري)

النسخة الحالية تحفظ الصورة في مجلد التطبيق. لإظهارها في المعرض:

```bash
flutter pub add gal
```

```dart
import 'package:gal/gal.dart';

// بدل ExportService.saveImage(...)
await Gal.putImageFile(File(path));
```

أو استخدم `MediaStore` في Java داخل `MainActivity` إن أردت التحكم الكامل.

---

## 7) قائمة تحقق قبل النشر

- [ ] HTTPS فقط + شهادة صحيحة (`usesCleartextTraffic=false`).
- [ ] تخزين الـ token في `flutter_secure_storage` بدل `SharedPreferences`.
- [ ] تسجيل خروج تلقائي بعد مدة خمول + قفل بالبصمة (موجود).
- [ ] تحديد معدل الطلبات (Rate limiting) على الخادم.
- [ ] تشفير بيانات المشتركين الحساسة + سجل تدقيق (audit log).
- [ ] اختبار على أجهزة حقيقية بأحجام شاشات مختلفة (التصميم متجاوب).
- [ ] توقيع الإصدار بمفتاحك (`android/key.properties`) وليس debug.
- [ ] مراجعة الشروط القانونية لاستخدام اسم/شعار شركة الكهرباء.
