package com.alwas.alwas_energy;

import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.annotation.NonNull;

import io.flutter.embedding.android.FlutterFragmentActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

/**
 * ===========================================================================
 *  MainActivity — الجزء الأصلي (Java) من التطبيق
 * ---------------------------------------------------------------------------
 *  لماذا FlutterFragmentActivity؟
 *    حزمة local_auth (البصمة) تطلب FragmentActivity لعرض BiometricPrompt،
 *    وإلا يتوقف التطبيق عند استدعاء البصمة.
 *
 *  قناة أصلية (MethodChannel) باسم "alwas/native":
 *    • deviceInfo  : إرجاع طراز الجهاز ونظام التشغيل (يُعرض في "عن التطبيق")
 *    • vibrate     : اهتزاز خفيف عند سحب خيط المصباح (بديل عن HapticFeedback)
 *    • exitApp     : إغلاق التطبيق من زر الرجوع عند الحاجة
 * ===========================================================================
 */
public class MainActivity extends FlutterFragmentActivity {

    private static final String CHANNEL = "alwas/native";

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);

        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler((call, result) -> {
                    switch (call.method) {
                        case "deviceInfo":
                            result.success(
                                    Build.MANUFACTURER + " " + Build.MODEL
                                            + " • Android " + Build.VERSION.RELEASE
                                            + " (API " + Build.VERSION.SDK_INT + ")");
                            break;

                        case "vibrate": {
                            int duration = 30;
                            if (call.arguments() instanceof Integer) {
                                duration = (Integer) call.arguments();
                            }
                            vibrate(duration);
                            result.success(true);
                            break;
                        }

                        case "exitApp":
                            finishAffinity();
                            result.success(true);
                            break;

                        default:
                            result.notImplemented();
                    }
                });
    }

    private void vibrate(int milliseconds) {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(
                    milliseconds, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //noinspection deprecation
            vibrator.vibrate(milliseconds);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
