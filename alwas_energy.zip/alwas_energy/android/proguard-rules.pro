# ===========================================================================
#  قواعد ProGuard / R8
#  التطبيق يستخدم minifyEnabled=false افتراضياً. عند تفعيل التصغير أبقِ هذه
#  القواعد حتى لا تُحذف أصناف Flutter والـ plugins.
# ===========================================================================
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-keep class androidx.biometric.** { *; }
-keep class com.alwas.alwas_energy.** { *; }
-dontwarn io.flutter.embedding.**
