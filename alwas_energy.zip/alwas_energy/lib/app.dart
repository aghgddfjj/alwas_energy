import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/l10n/app_strings.dart';
import 'core/theme/app_colors.dart';
import 'core/theme/app_theme.dart';
import 'screens/lock_screen.dart';
import 'screens/login_screen.dart';
import 'screens/main_shell.dart';
import 'screens/splash_screen.dart';
import 'state/session_controller.dart';
import 'state/settings_controller.dart';

/// ============================================================================
///  التطبيق الجذري: الثيم + اللغة (عربي RTL / إنجليزي LTR) + التوجيه
/// ============================================================================
class AlwasApp extends StatelessWidget {
  const AlwasApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettingsController>();

    return MaterialApp(
      title: settings.strings.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      locale: settings.locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        AppStringsDelegate(),
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        // نثبّت تكبير الخط بين 0.9 و 1.15 للحفاظ على تناسق التصميم
        final media = MediaQuery.of(context);
        final scale = media.textScaler.scale(1.0).clamp(0.9, 1.15);
        return MediaQuery(
          data: media.copyWith(textScaler: TextScaler.linear(scale)),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const RootGate(),
    );
  }
}

/// ============================================================================
///  بوابة البداية: شاشة تحميل ← (دخول | قفل بالبصمة | التطبيق)
///  تعتمد على حالة الجلسة في SessionController (تصميم تصريحي بلا أخطاء تنقّل)
/// ============================================================================
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> with WidgetsBindingObserver {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _boot();
  }

  Future<void> _boot() async {
    final session = context.read<SessionController>();
    await session.restore();
    await Future<void>.delayed(const Duration(milliseconds: 1500));
    if (!mounted) return;
    setState(() => _ready = true);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // قفل التطبيق تلقائياً عند العودة إليه إذا كان القفل بالبصمة مفعّلاً
    if (state == AppLifecycleState.paused) {
      final session = context.read<SessionController>();
      final settings = context.read<AppSettingsController>();
      if (settings.biometricEnabled &&
          session.status == SessionStatus.unlocked) {
        session.lock();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) return const SplashScreen();

    final session = context.watch<SessionController>();

    final Widget page;
    switch (session.status) {
      case SessionStatus.signedOut:
        page = const LoginScreen(key: ValueKey('login'));
        break;
      case SessionStatus.locked:
        page = const LockScreen(key: ValueKey('lock'));
        break;
      case SessionStatus.unlocked:
        page = const MainShell(key: ValueKey('shell'));
        break;
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 420),
      switchInCurve: Curves.easeOut,
      switchOutCurve: Curves.easeIn,
      transitionBuilder: (child, animation) => FadeTransition(
        opacity: animation,
        child: Container(color: AppColors.background, child: child),
      ),
      child: page,
    );
  }
}
