import '../../core/l10n/localized_text.dart';
import '../models/models.dart';

/// ============================================================================
///  البيانات التجريبية (Demo Data)
///  كل الأرقام هنا مأخوذة من التصميم المرجعي. لتغييرها: عدّل هذا الملف فقط.
///  عند الربط بخدمة حقيقية استبدل MockAppRepository بـ ApiAppRepository.
/// ============================================================================
class MockData {
  MockData._();

  static const String demoUsername = 'ahmed';
  static const String demoPassword = '1234';

  /// سعر الكيلوواط الواحد (ريال) — مستخدم في حساب الطاقة المضافة
  static const double tariffPerKwh = 250.0;

  static const UserProfile user = UserProfile(
    id: 'u-1000001',
    name: 'أحمد محمد',
    username: 'ahmed',
    phone: '+967 777 000 111',
    email: 'ahmed@example.com',
    subscriberNumber: '1000001',
    city: 'صنعاء - حدة',
    memberSince: '2024-03-12',
    avatarIndex: 0,
  );

  static const List<MeterModel> meters = [
    MeterModel(
      id: 'm-1',
      number: '1000001',
      alias: 'عدادي',
      kind: MeterKind.prepaid,
      balance: 18500,
      remainingKwh: 74.0,
      currentLoadKw: 1.8,
      monthlyCapKwh: 400,
      usedKwhThisMonth: 142.8,
      connected: true,
    ),
    MeterModel(
      id: 'm-2',
      number: '1000002',
      alias: 'عداد آخر',
      kind: MeterKind.prepaid,
      balance: 7250,
      remainingKwh: 29.0,
      currentLoadKw: 0.9,
      monthlyCapKwh: 200,
      usedKwhThisMonth: 71.2,
      connected: true,
    ),
  ];

  static const List<PaymentMethodModel> paymentMethods = [
    PaymentMethodModel(
      id: 'jaib',
      name: L('جيب', 'Jaib'),
      walletNumber: '700000001',
      colorValue: 0xFFE23B4E,
      steps: [
        L('افتح تطبيق جيب واختر "تحويل إلى مشترك".',
            'Open Jaib and choose "Transfer to subscriber".'),
        L('أدخل رقم محفظة المحطة: 700000001',
            'Enter the station wallet: 700000001'),
        L('اكتب المبلغ الذي تريد شحنه.', 'Enter the amount to top up.'),
        L('في خانة الملاحظة اكتب رقم العداد: 1000001',
            'In the note write the meter number: 1000001'),
        L('أكّد التحويل وسيصل الرصيد خلال دقائق.',
            'Confirm the transfer; balance arrives in minutes.'),
      ],
    ),
    PaymentMethodModel(
      id: 'jawali',
      name: L('جوالي', 'Jawali'),
      walletNumber: '770000002',
      colorValue: 0xFFF58220,
      steps: [
        L('افتح تطبيق جوالي واختر "حوالة".',
            'Open Jawali and choose "Transfer".'),
        L('أدخل رقم محفظة المحطة: 770000002',
            'Enter the station wallet: 770000002'),
        L('اكتب المبلغ الذي تريد شحنه.', 'Enter the amount to top up.'),
        L('اكتب رقم العداد في خانة الملاحظة.',
            'Write the meter number in the note field.'),
        L('أكّد العملية وانتظر رسالة التأكيد.',
            'Confirm and wait for the confirmation message.'),
      ],
    ),
    PaymentMethodModel(
      id: 'floosak',
      name: L('فلوسك', 'Floosak'),
      walletNumber: '710000003',
      colorValue: 0xFF2FA8E0,
      steps: [
        L('افتح تطبيق فلوسك واختر "تحويل".',
            'Open Floosak and choose "Transfer".'),
        L('أدخل رقم محفظة المحطة: 710000003',
            'Enter the station wallet: 710000003'),
        L('اكتب المبلغ الذي تريد شحنه.', 'Enter the amount to top up.'),
        L('اكتب رقم العداد في خانة الملاحظة.',
            'Write the meter number in the note field.'),
        L('أكّد العملية وسيصلك إشعار بالشحن.',
            'Confirm; you will get a top-up notification.'),
      ],
    ),
  ];

  static List<ReceiptModel> receipts() => [
        ReceiptModel(
          id: 'r-128',
          receiptNumber: 'VG-2026-000128',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000001',
          meterNumber: '1000001',
          amount: 5000,
          kwh: 20.0,
          balanceAfter: 18500,
          methodId: 'jaib',
          methodName: const L('جيب', 'Jaib'),
          dateTime: DateTime(2026, 10, 27, 6, 57),
        ),
        ReceiptModel(
          id: 'r-127',
          receiptNumber: 'VG-2026-000127',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000001',
          meterNumber: '1000001',
          amount: 10000,
          kwh: 40.0,
          balanceAfter: 13500,
          methodId: 'jawali',
          methodName: const L('جوالي', 'Jawali'),
          dateTime: DateTime(2026, 10, 24, 18, 12),
        ),
        ReceiptModel(
          id: 'r-126',
          receiptNumber: 'VG-2026-000126',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000001',
          meterNumber: '1000001',
          amount: 3000,
          kwh: 12.0,
          balanceAfter: 3500,
          methodId: 'floosak',
          methodName: const L('فلوسك', 'Floosak'),
          dateTime: DateTime(2026, 10, 20, 9, 40),
        ),
        ReceiptModel(
          id: 'r-125',
          receiptNumber: 'VG-2026-000125',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000001',
          meterNumber: '1000001',
          amount: 7500,
          kwh: 30.0,
          balanceAfter: 9200,
          methodId: 'jaib',
          methodName: const L('جيب', 'Jaib'),
          dateTime: DateTime(2026, 10, 16, 20, 5),
        ),
        ReceiptModel(
          id: 'r-124',
          receiptNumber: 'VG-2026-000124',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000001',
          meterNumber: '1000001',
          amount: 5000,
          kwh: 20.0,
          balanceAfter: 6100,
          methodId: 'jawali',
          methodName: const L('جوالي', 'Jawali'),
          dateTime: DateTime(2026, 10, 12, 11, 30),
        ),
        ReceiptModel(
          id: 'r-123',
          receiptNumber: 'VG-2026-000123',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000002',
          meterNumber: '1000002',
          amount: 12000,
          kwh: 48.0,
          balanceAfter: 12800,
          methodId: 'jaib',
          methodName: const L('جيب', 'Jaib'),
          dateTime: DateTime(2026, 10, 8, 7, 15),
        ),
        ReceiptModel(
          id: 'r-122',
          receiptNumber: 'VG-2026-000122',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000001',
          meterNumber: '1000001',
          amount: 6000,
          kwh: 24.0,
          balanceAfter: 6400,
          methodId: 'jawali',
          methodName: const L('جوالي', 'Jawali'),
          dateTime: DateTime(2026, 10, 5, 16, 48),
        ),
        ReceiptModel(
          id: 'r-121',
          receiptNumber: 'VG-2026-000121',
          subscriberName: 'أحمد محمد',
          accountNumber: '1000001',
          meterNumber: '1000001',
          amount: 4000,
          kwh: 16.0,
          balanceAfter: 2100,
          methodId: 'floosak',
          methodName: const L('فلوسك', 'Floosak'),
          dateTime: DateTime(2026, 10, 2, 8, 22),
        ),
      ];

  // ----------------------------- الاستهلاك -----------------------------
  static const List<ConsumptionPoint> daysPeriod = [
    ConsumptionPoint('10/22', 6.2),
    ConsumptionPoint('10/23', 5.6),
    ConsumptionPoint('10/24', 6.5),
    ConsumptionPoint('10/25', 6.9),
    ConsumptionPoint('10/26', 7.0),
    ConsumptionPoint('10/27', 4.1),
    ConsumptionPoint('10/28', 4.4),
  ];

  static const List<ConsumptionPoint> previousDaysPeriod = [
    ConsumptionPoint('10/22', 5.1),
    ConsumptionPoint('10/23', 5.3),
    ConsumptionPoint('10/24', 5.0),
    ConsumptionPoint('10/25', 4.6),
    ConsumptionPoint('10/26', 4.2),
    ConsumptionPoint('10/27', 3.9),
    ConsumptionPoint('10/28', 4.0),
  ];

  static const List<ConsumptionPoint> hoursPeriod = [
    ConsumptionPoint('00', 0.3),
    ConsumptionPoint('02', 0.2),
    ConsumptionPoint('04', 0.2),
    ConsumptionPoint('06', 0.6),
    ConsumptionPoint('08', 1.4),
    ConsumptionPoint('10', 1.1),
    ConsumptionPoint('12', 1.6),
    ConsumptionPoint('14', 1.9),
    ConsumptionPoint('16', 2.2),
    ConsumptionPoint('18', 2.6),
    ConsumptionPoint('20', 2.1),
    ConsumptionPoint('22', 0.8),
  ];

  static const List<ConsumptionPoint> monthsPeriod = [
    ConsumptionPoint('05', 118.4),
    ConsumptionPoint('06', 132.0),
    ConsumptionPoint('07', 149.6),
    ConsumptionPoint('08', 155.2),
    ConsumptionPoint('09', 138.7),
    ConsumptionPoint('10', 142.8),
  ];

  static const List<ConsumptionPoint> previousMonthsPeriod = [
    ConsumptionPoint('05', 104.2),
    ConsumptionPoint('06', 121.5),
    ConsumptionPoint('07', 139.0),
    ConsumptionPoint('08', 141.8),
    ConsumptionPoint('09', 130.4),
    ConsumptionPoint('10', 128.1),
  ];

  static ConsumptionSummary consumptionSummary(ConsumptionRange range) {
    switch (range) {
      case ConsumptionRange.hours:
        return const ConsumptionSummary(
          totalKwh: 15.0,
          averageDaily: 0.6,
          peakUsage: 2.6,
          estimatedCost: 3750,
          currentPeriod: hoursPeriod,
          previousPeriod: hoursPeriod,
        );
      case ConsumptionRange.days:
        return const ConsumptionSummary(
          totalKwh: 142.8,
          averageDaily: 4.8,
          peakUsage: 7.0,
          estimatedCost: 35700,
          currentPeriod: daysPeriod,
          previousPeriod: previousDaysPeriod,
        );
      case ConsumptionRange.months:
        return const ConsumptionSummary(
          totalKwh: 836.7,
          averageDaily: 27.9,
          peakUsage: 155.2,
          estimatedCost: 209175,
          currentPeriod: monthsPeriod,
          previousPeriod: previousMonthsPeriod,
        );
    }
  }

  /// بيانات الرسم البياني الموجي في ملخص الفواتير (7 أعمدة)
  static const List<double> invoicesWave = [3.2, 6.8, 3.9, 5.1, 2.8, 6.2, 3.0];

  // ----------------------------- البلاغات -----------------------------
  static List<SupportTicket> tickets() => [
        SupportTicket(
          id: 'T-2026-1042',
          title: const L('تأخر شحن', 'Delayed top-up'),
          date: DateTime(2026, 10, 28, 7, 10),
          status: TicketStatus.open,
          reachedStep: 1,
        ),
        SupportTicket(
          id: 'T-2026-1031',
          title: const L('العداد مفصول رغم وجود رصيد',
              'Meter disconnected despite balance'),
          date: DateTime(2026, 10, 24, 19, 25),
          status: TicketStatus.open,
          reachedStep: 1,
        ),
        SupportTicket(
          id: 'T-2026-0987',
          title: const L('استفسار عن الفاتورة', 'Invoice inquiry'),
          date: DateTime(2026, 10, 19, 12, 5),
          status: TicketStatus.resolved,
          reachedStep: 2,
        ),
      ];

  // ----------------------------- الإشعارات -----------------------------
  static List<AppNotification> notifications() => [
        AppNotification(
          id: 'n-1',
          title: const L('نجح شحن العداد', 'Meter top-up succeeded'),
          body: const L('تم شحن مبلغ 5,000 ر.ي للعداد 1000001',
              'Top-up of 5,000 YER for meter 1000001 succeeded'),
          date: DateTime(2026, 10, 27, 6, 57),
          kind: NotificationKind.recharge,
        ),
        AppNotification(
          id: 'n-2',
          title: const L('صيانة مجدولة', 'Scheduled maintenance'),
          body: const L('إشعار من المحطة: صيانة مجدولة يوم الخميس 6:00 صباحاً',
              'Notice from the station: maintenance on Thursday 6:00 AM'),
          date: DateTime(2026, 10, 26, 9, 0),
          kind: NotificationKind.maintenance,
        ),
        AppNotification(
          id: 'n-3',
          title: const L('تحديث التعرفة', 'Tariff update'),
          body: const L(
              'إشعار من المحطة: تحديث تعرفة الكيلوواط اعتباراً من نوفمبر',
              'Notice from the station: kWh tariff update starting November'),
          date: DateTime(2026, 10, 23, 14, 30),
          kind: NotificationKind.tariff,
        ),
        AppNotification(
          id: 'n-4',
          title: const L('انقطاع قريب', 'Upcoming outage'),
          body: const L('سيتم فصل الخدمة للصيانة بعد 11 يوماً',
              'Service will be interrupted for maintenance in 11 days'),
          date: DateTime(2026, 10, 21, 8, 15),
          kind: NotificationKind.outage,
          read: true,
        ),
      ];
}
