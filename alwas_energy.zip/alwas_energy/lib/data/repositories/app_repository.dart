import '../../core/l10n/localized_text.dart';
import '../mock/mock_data.dart';
import '../models/models.dart';

/// ============================================================================
///  طبقة الوصول للبيانات (Repository)
///  الواجهات (Screens) لا تعرف من أين تأتي البيانات، لذلك يكفي أن نستبدل
///  MockAppRepository بـ ApiAppRepository (HTTP + قاعدة بيانات) دون لمس الواجهات.
/// ============================================================================
abstract class AppRepository {
  Future<UserProfile?> signIn(
      {required String username, required String password});

  /// المستخدم المحفوظ حالياً (للاستعادة عند فتح التطبيق)
  Future<UserProfile?> currentUser();
  Future<UserProfile> register({
    required String fullName,
    required String phone,
    required String email,
    required String password,
    required String meterNumber,
  });
  Future<List<MeterModel>> fetchMeters();
  Future<List<PaymentMethodModel>> fetchPaymentMethods();
  Future<List<ReceiptModel>> fetchReceipts();
  Future<ConsumptionSummary> fetchConsumption(ConsumptionRange range);
  Future<List<SupportTicket>> fetchTickets();
  Future<SupportTicket> createTicket(
      {required String title, required String details});
  Future<List<AppNotification>> fetchNotifications();
  Future<ReceiptModel> createTopUp({
    required MeterModel meter,
    required double amount,
    required PaymentMethodModel method,
  });
  Future<UserProfile> updateProfile(UserProfile user);
}

/// ---------------------------------------------------------------------------
///  التنفيذ التجريبي: يحاكي تأخير الشبكة ويحفظ التغييرات في الذاكرة.
/// ---------------------------------------------------------------------------
class MockAppRepository implements AppRepository {
  final List<MeterModel> _meters = List<MeterModel>.from(MockData.meters);
  final List<ReceiptModel> _receipts = MockData.receipts();
  final List<SupportTicket> _tickets = MockData.tickets();
  final List<AppNotification> _notifications = MockData.notifications();
  UserProfile _user = MockData.user;
  int _receiptCounter = 129;
  int _ticketCounter = 1050;

  static const Duration _latency = Duration(milliseconds: 550);

  @override
  Future<UserProfile?> signIn({
    required String username,
    required String password,
  }) async {
    await Future<void>.delayed(_latency);
    final u = username.trim().toLowerCase();
    if (password.length >= 4 &&
        (u == MockData.demoUsername ||
            u == _user.phone.replaceAll(' ', '') ||
            u == _user.email)) {
      return _user;
    }
    return null;
  }

  @override
  Future<UserProfile?> currentUser() async {
    await Future<void>.delayed(const Duration(milliseconds: 120));
    return _user;
  }

  @override
  Future<UserProfile> register({
    required String fullName,
    required String phone,
    required String email,
    required String password,
    required String meterNumber,
  }) async {
    await Future<void>.delayed(_latency);
    _user = UserProfile(
      id: 'u-${DateTime.now().millisecondsSinceEpoch}',
      name: fullName,
      username: email.split('@').first,
      phone: phone,
      email: email,
      subscriberNumber: meterNumber,
      city: _user.city,
      memberSince: DateTime.now().toIso8601String().substring(0, 10),
    );
    return _user;
  }

  @override
  Future<List<MeterModel>> fetchMeters() async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return List<MeterModel>.unmodifiable(_meters);
  }

  @override
  Future<List<PaymentMethodModel>> fetchPaymentMethods() async {
    await Future<void>.delayed(const Duration(milliseconds: 200));
    return MockData.paymentMethods;
  }

  @override
  Future<List<ReceiptModel>> fetchReceipts() async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return List<ReceiptModel>.unmodifiable(_receipts);
  }

  @override
  Future<ConsumptionSummary> fetchConsumption(ConsumptionRange range) async {
    await Future<void>.delayed(const Duration(milliseconds: 200));
    return MockData.consumptionSummary(range);
  }

  @override
  Future<List<SupportTicket>> fetchTickets() async {
    await Future<void>.delayed(const Duration(milliseconds: 300));
    return List<SupportTicket>.unmodifiable(_tickets);
  }

  @override
  Future<SupportTicket> createTicket({
    required String title,
    required String details,
  }) async {
    await Future<void>.delayed(_latency);
    final ticket = SupportTicket(
      id: 'T-2026-${_ticketCounter++}',
      title: L(title, title),
      date: DateTime.now(),
      status: TicketStatus.open,
      reachedStep: 0,
    );
    _tickets.insert(0, ticket);
    return ticket;
  }

  @override
  Future<List<AppNotification>> fetchNotifications() async {
    await Future<void>.delayed(const Duration(milliseconds: 250));
    return List<AppNotification>.unmodifiable(_notifications);
  }

  @override
  Future<ReceiptModel> createTopUp({
    required MeterModel meter,
    required double amount,
    required PaymentMethodModel method,
  }) async {
    await Future<void>.delayed(const Duration(milliseconds: 900));
    final kwh = amount / MockData.tariffPerKwh;
    final newBalance = meter.balance + amount;
    final receipt = ReceiptModel(
      id: 'r-${DateTime.now().millisecondsSinceEpoch}',
      receiptNumber: 'VG-2026-${_receiptCounter.toString().padLeft(6, '0')}',
      subscriberName: _user.name,
      accountNumber: meter.number,
      meterNumber: meter.number,
      amount: amount,
      kwh: double.parse(kwh.toStringAsFixed(1)),
      balanceAfter: newBalance,
      methodId: method.id,
      methodName: method.name,
      dateTime: DateTime.now(),
    );
    _receiptCounter++;

    // تحديث حالة العداد في الذاكرة + إضافة الإيصال والإشعار
    final index = _meters.indexWhere((m) => m.id == meter.id);
    if (index != -1) {
      _meters[index] = _meters[index].copyWith(
        balance: newBalance,
        remainingKwh: _meters[index].remainingKwh + kwh,
        usedKwhThisMonth: _meters[index].usedKwhThisMonth,
      );
    }
    _receipts.insert(0, receipt);
    _notifications.insert(
      0,
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: const L('نجح شحن العداد', 'Meter top-up succeeded'),
        body: L(
          'تم شحن مبلغ ${amount.toStringAsFixed(0)} ر.ي للعداد ${meter.number}',
          'Top-up of ${amount.toStringAsFixed(0)} YER for meter ${meter.number} succeeded',
        ),
        date: DateTime.now(),
        kind: NotificationKind.recharge,
      ),
    );
    return receipt;
  }

  @override
  Future<UserProfile> updateProfile(UserProfile user) async {
    await Future<void>.delayed(const Duration(milliseconds: 400));
    _user = user;
    return _user;
  }
}
