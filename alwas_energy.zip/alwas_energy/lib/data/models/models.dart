import '../../core/l10n/localized_text.dart';

/// ============================================================================
///  نماذج البيانات (Models) — تُستخدم مع البيانات التجريبية الآن،
///  ويمكن استبدال مصدرها بـ JSON من واجهة API لاحقاً دون تغيير الواجهات.
///  كل نموذج يحتوي onJson / toJson ليسهل الربط بقاعدة البيانات.
/// ============================================================================

// ---------------------------------- المستخدم ----------------------------------
class UserProfile {
  final String id;
  final String name;
  final String username;
  final String phone;
  final String email;
  final String subscriberNumber;
  final String city;
  final String memberSince;
  final int avatarIndex;

  const UserProfile({
    required this.id,
    required this.name,
    required this.username,
    required this.phone,
    required this.email,
    required this.subscriberNumber,
    required this.city,
    required this.memberSince,
    this.avatarIndex = 0,
  });

  UserProfile copyWith({
    String? name,
    String? phone,
    String? email,
    String? city,
    int? avatarIndex,
  }) {
    return UserProfile(
      id: id,
      name: name ?? this.name,
      username: username,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      subscriberNumber: subscriberNumber,
      city: city ?? this.city,
      memberSince: memberSince,
      avatarIndex: avatarIndex ?? this.avatarIndex,
    );
  }

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        id: json['id'] as String,
        name: json['name'] as String,
        username: json['username'] as String,
        phone: json['phone'] as String,
        email: json['email'] as String,
        subscriberNumber: json['subscriber_number'] as String,
        city: json['city'] as String,
        memberSince: json['member_since'] as String,
        avatarIndex: (json['avatar_index'] as num?)?.toInt() ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'username': username,
        'phone': phone,
        'email': email,
        'subscriber_number': subscriberNumber,
        'city': city,
        'member_since': memberSince,
        'avatar_index': avatarIndex,
      };
}

// ---------------------------------- العداد ----------------------------------
enum MeterKind { prepaid, postpaid }

class MeterModel {
  final String id;
  final String number; // رقم العداد
  final String alias; // اسم مستعار
  final MeterKind kind;
  final double balance; // الرصيد بالريال
  final double remainingKwh; // الطاقة المتبقية
  final double currentLoadKw; // الحمل الحالي
  final double monthlyCapKwh; // السقف الشهري
  final double usedKwhThisMonth; // المستهلك هذا الشهر
  final bool connected;

  const MeterModel({
    required this.id,
    required this.number,
    required this.alias,
    required this.kind,
    required this.balance,
    required this.remainingKwh,
    required this.currentLoadKw,
    required this.monthlyCapKwh,
    required this.usedKwhThisMonth,
    this.connected = true,
  });

  double get capRatio => monthlyCapKwh <= 0
      ? 0
      : (usedKwhThisMonth / monthlyCapKwh).clamp(0.0, 1.0);

  MeterModel copyWith({
    double? balance,
    double? remainingKwh,
    double? currentLoadKw,
    double? usedKwhThisMonth,
    bool? connected,
    double? monthlyCapKwh,
  }) {
    return MeterModel(
      id: id,
      number: number,
      alias: alias,
      kind: kind,
      balance: balance ?? this.balance,
      remainingKwh: remainingKwh ?? this.remainingKwh,
      currentLoadKw: currentLoadKw ?? this.currentLoadKw,
      monthlyCapKwh: monthlyCapKwh ?? this.monthlyCapKwh,
      usedKwhThisMonth: usedKwhThisMonth ?? this.usedKwhThisMonth,
      connected: connected ?? this.connected,
    );
  }

  factory MeterModel.fromJson(Map<String, dynamic> json) => MeterModel(
        id: json['id'] as String,
        number: json['number'] as String,
        alias: json['alias'] as String,
        kind:
            json['kind'] == 'postpaid' ? MeterKind.postpaid : MeterKind.prepaid,
        balance: (json['balance'] as num).toDouble(),
        remainingKwh: (json['remaining_kwh'] as num).toDouble(),
        currentLoadKw: (json['current_load_kw'] as num).toDouble(),
        monthlyCapKwh: (json['monthly_cap_kwh'] as num).toDouble(),
        usedKwhThisMonth: (json['used_kwh_this_month'] as num).toDouble(),
        connected: json['connected'] as bool? ?? true,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'number': number,
        'alias': alias,
        'kind': kind.name,
        'balance': balance,
        'remaining_kwh': remainingKwh,
        'current_load_kw': currentLoadKw,
        'monthly_cap_kwh': monthlyCapKwh,
        'used_kwh_this_month': usedKwhThisMonth,
        'connected': connected,
      };
}

// -------------------------------- طريقة الدفع --------------------------------
class PaymentMethodModel {
  final String id;
  final L name;
  final String walletNumber; // رقم محفظة المحطة لهذه الطريقة
  final int colorValue; // لون الشعار
  final List<L> steps; // خطوات التسديد

  const PaymentMethodModel({
    required this.id,
    required this.name,
    required this.walletNumber,
    required this.colorValue,
    required this.steps,
  });
}

// ---------------------------------- الإيصال ----------------------------------
enum ReceiptStatus { completed, pending, failed }

class ReceiptModel {
  final String id;
  final String receiptNumber; // VG-2026-000128
  final String subscriberName;
  final String accountNumber;
  final String meterNumber;
  final double amount;
  final double kwh;
  final double balanceAfter;
  final String methodId;
  final L methodName;
  final DateTime dateTime;
  final ReceiptStatus status;

  const ReceiptModel({
    required this.id,
    required this.receiptNumber,
    required this.subscriberName,
    required this.accountNumber,
    required this.meterNumber,
    required this.amount,
    required this.kwh,
    required this.balanceAfter,
    required this.methodId,
    required this.methodName,
    required this.dateTime,
    this.status = ReceiptStatus.completed,
  });

  factory ReceiptModel.fromJson(Map<String, dynamic> json) => ReceiptModel(
        id: json['id'] as String,
        receiptNumber: json['receipt_number'] as String,
        subscriberName: json['subscriber_name'] as String,
        accountNumber: json['account_number'] as String,
        meterNumber: json['meter_number'] as String,
        amount: (json['amount'] as num).toDouble(),
        kwh: (json['kwh'] as num).toDouble(),
        balanceAfter: (json['balance_after'] as num).toDouble(),
        methodId: json['method_id'] as String,
        methodName: L(
            json['method_name_ar'] as String, json['method_name_en'] as String),
        dateTime: DateTime.parse(json['date_time'] as String),
        status: ReceiptStatus.values.firstWhere(
          (e) => e.name == json['status'],
          orElse: () => ReceiptStatus.completed,
        ),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'receipt_number': receiptNumber,
        'subscriber_name': subscriberName,
        'account_number': accountNumber,
        'meter_number': meterNumber,
        'amount': amount,
        'kwh': kwh,
        'balance_after': balanceAfter,
        'method_id': methodId,
        'method_name_ar': methodName.ar,
        'method_name_en': methodName.en,
        'date_time': dateTime.toIso8601String(),
        'status': status.name,
      };
}

// ------------------------------- الاستهلاك -------------------------------
enum ConsumptionRange { hours, days, months }

class ConsumptionPoint {
  final String label;
  final double value; // كيلوواط ساعة
  const ConsumptionPoint(this.label, this.value);
}

class ConsumptionSummary {
  final double totalKwh;
  final double averageDaily;
  final double peakUsage;
  final double estimatedCost;
  final List<ConsumptionPoint> currentPeriod;
  final List<ConsumptionPoint> previousPeriod;

  const ConsumptionSummary({
    required this.totalKwh,
    required this.averageDaily,
    required this.peakUsage,
    required this.estimatedCost,
    required this.currentPeriod,
    required this.previousPeriod,
  });
}

// -------------------------------- البلاغات --------------------------------
enum TicketStatus { open, resolved }

class SupportTicket {
  final String id;
  final L title;
  final DateTime date;
  final TicketStatus status;
  final int reachedStep; // 0 = تم الاستلام، 1 = قيد المعالجة، 2 = تم الحل

  const SupportTicket({
    required this.id,
    required this.title,
    required this.date,
    required this.status,
    required this.reachedStep,
  });
}

// -------------------------------- الإشعارات --------------------------------
enum NotificationKind { recharge, maintenance, tariff, outage, system }

class AppNotification {
  final String id;
  final L title;
  final L body;
  final DateTime date;
  final NotificationKind kind;
  final bool read;

  const AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.date,
    required this.kind,
    this.read = false,
  });

  AppNotification markRead() => AppNotification(
        id: id,
        title: title,
        body: body,
        date: date,
        kind: kind,
        read: true,
      );
}
