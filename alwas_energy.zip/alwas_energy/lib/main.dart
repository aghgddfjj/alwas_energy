import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'core/theme/app_colors.dart';
import 'data/repositories/app_repository.dart';
import 'services/storage_service.dart';
import 'state/energy_controller.dart';
import 'state/lamp_controller.dart';
import 'state/session_controller.dart';
import 'state/settings_controller.dart';
import 'state/support_controller.dart';

/// ============================================================================
///  نقطة تشغيل التطبيق
///  1) تهيئة الخدمات (SharedPreferences)
///  2) تثبيت الوضع العمودي وشريط الحالة الشفاف
///  3) تسجيل المتحكّمات (Providers) مع طبقة البيانات (Repository)
/// ============================================================================
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: AppColors.background,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  final storage = StorageService();
  await storage.init();

  // لتبديل البيانات الوهمية بخدمة حقيقية لاحقاً:
  //   final AppRepository repo = ApiAppRepository(baseUrl: 'https://api.example.com');
  final AppRepository repo = MockAppRepository();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AppSettingsController>(
          create: (_) => AppSettingsController(storage),
        ),
        ChangeNotifierProvider<LampController>(
          create: (_) => LampController(storage),
        ),
        ChangeNotifierProvider<SessionController>(
          create: (_) => SessionController(
            repository: repo,
            storage: storage,
          ),
        ),
        ChangeNotifierProvider<EnergyController>(
          create: (_) => EnergyController(repo)..load(),
        ),
        ChangeNotifierProvider<SupportController>(
          create: (_) => SupportController(repo)..load(),
        ),
      ],
      child: const AlwasApp(),
    ),
  );
}
