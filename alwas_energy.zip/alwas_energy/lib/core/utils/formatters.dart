import 'package:intl/intl.dart';

/// ============================================================================
///  أدوات التنسيق: الأرقام (بفواصل الآلاف) والتواريخ (عربي / إنجليزي)
///  ملاحظة: نستخدم الأرقام اللاتينية (1,2,3) كما في التصميم المرجعي،
///  مع أسماء الأشهر والأيام بالعربية عند اللغة العربية.
/// ============================================================================
class Fmt {
  Fmt._();

  static final NumberFormat _plain = NumberFormat('#,##0', 'en');
  static final NumberFormat _decimal = NumberFormat('#,##0.#', 'en');
  static final NumberFormat _oneDecimal = NumberFormat('#,##0.0', 'en');

  /// 18500 -> "18,500"
  static String number(num value) => _plain.format(value);

  /// 74.0 -> "74" / 74.5 -> "74.5"
  static String decimal(num value) => _decimal.format(value);

  /// 74.0 -> "74.0"
  static String oneDecimal(num value) => _oneDecimal.format(value);

  /// 18500 -> "ر.ي 18,500" أو "18,500 ر.ي"
  static String currency(num value, String currencyLabel,
          {bool arabic = true}) =>
      arabic
          ? '${number(value)} $currencyLabel'
          : '$currencyLabel ${number(value)}';

  /// 2026-10-27 06:57
  static String dateTime(DateTime value) =>
      '${DateFormat('yyyy-MM-dd', 'en').format(value)} ${DateFormat('HH:mm', 'en').format(value)}';

  /// 27-10-2026
  static String shortDate(DateTime value) =>
      DateFormat('dd-MM-yyyy', 'en').format(value);

  /// 06:57 ص / 06:57 AM
  static String time(DateTime value, {required bool arabic}) {
    final hour = value.hour;
    final minute = value.minute.toString().padLeft(2, '0');
    final isPm = hour >= 12;
    final h12 = hour % 12 == 0 ? 12 : hour % 12;
    final suffix = arabic ? (isPm ? 'م' : 'ص') : (isPm ? 'PM' : 'AM');
    return '$h12:$minute $suffix';
  }

  static const List<String> _arDays = [
    'الاثنين',
    'الثلاثاء',
    'الأربعاء',
    'الخميس',
    'الجمعة',
    'السبت',
    'الأحد',
  ];

  static const List<String> _enDays = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  static const List<String> _arMonths = [
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر',
  ];

  static const List<String> _enMonths = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  /// "الأربعاء، 28 أكتوبر • 6:58 ص"
  static String headerDate(DateTime value, {required bool arabic}) {
    final dayName = (arabic ? _arDays : _enDays)[value.weekday - 1];
    final month = (arabic ? _arMonths : _enMonths)[value.month - 1];
    return arabic
        ? '$dayName، ${value.day} $month • ${time(value, arabic: true)}'
        : '$dayName, $month ${value.day} • ${time(value, arabic: false)}';
  }

  static String monthName(int month, {required bool arabic}) =>
      (arabic ? _arMonths : _enMonths)[(month - 1).clamp(0, 11)];

  static String weekday(DateTime value, {required bool arabic}) =>
      (arabic ? _arDays : _enDays)[value.weekday - 1];
}
