import 'package:flutter/material.dart';

/// ============================================================================
///  الهوية البصرية للتطبيق  (Design Tokens)
///  كل الألوان المستخدمة في التطبيق موجودة هنا فقط. تعديل أي لون من هذا الملف
///  ينعكس تلقائياً على كل الشاشات والبطاقات والأزرار.
/// ============================================================================
class AppColors {
  AppColors._();

  // ---------------------------- الخلفيات ----------------------------
  /// خلفية الشاشة: أسود مائل للبني
  static const Color background = Color(0xFF0B0906);

  /// تدرّج خلفية أعلى الشاشة (لمعة بنية خفيفة)
  static const Color backgroundTop = Color(0xFF1A130C);

  /// خلفية البطاقات
  static const Color card = Color(0xFF15110D);

  /// خلفية البطاقة الثانية (أفتح قليلاً)
  static const Color cardAlt = Color(0xFF1D1712);

  /// خلفية الحقول والحاويات الداخلية
  static const Color field = Color(0xFF100D0A);

  /// خلفية القائمة الجانبية
  static const Color drawer = Color(0xFF120E0A);

  // ---------------------------- الذهبي / العسلي ----------------------------
  /// الذهبي الأساسي (أزرار + أيقونات)
  static const Color gold = Color(0xFFE8A33D);

  /// ذهبي فاتح (بداية التدرّج / النصوص المهمة)
  static const Color goldLight = Color(0xFFFFC96B);

  /// ذهبي عسلي غامق (نهاية التدرّج)
  static const Color goldDark = Color(0xFFB9741C);

  /// ذهبي باهت للإطارات الرفيعة
  static const Color goldBorder = Color(0xFF3A2C1B);

  /// ذهبي شبه شفاف للفواصل
  static const Color goldDivider = Color(0xFF2A2118);

  // ---------------------------- النصوص ----------------------------
  static const Color textPrimary = Color(0xFFF6F1E7);
  static const Color textSecondary = Color(0xFFA79A89);
  static const Color textMuted = Color(0xFF7C7166);

  // ---------------------------- الدلالات ----------------------------
  static const Color success = Color(0xFF3DD68C);
  static const Color successDark = Color(0xFF1F6B45);
  static const Color danger = Color(0xFFFF5C5C);
  static const Color warning = Color(0xFFF2B33D);
  static const Color info = Color(0xFF4DA3FF);

  // ألوان شعارات شركات الدفع (كما في التصميم المرجعي)
  static const Color jaibRed = Color(0xFFE23B4E);
  static const Color jawaliOrange = Color(0xFFF58220);
  static const Color floosakBlue = Color(0xFF2FA8E0);

  // ---------------------------- التدرّجات ----------------------------
  /// تدرّج الأزرار الذهبية
  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [goldLight, gold],
  );

  /// تدرّج البطاقات
  static const LinearGradient cardGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF1B1510), Color(0xFF120E0B)],
  );

  /// تدرّج ضوء المصباح
  static const LinearGradient lampBeamGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0x66FFCE7A),
      Color(0x33FFC462),
      Color(0x14E8A33D),
      Color(0x00E8A33D),
    ],
    stops: [0.0, 0.35, 0.7, 1.0],
  );

  // ---------------------------- الظلال ----------------------------
  /// توهّج ذهبي هادئ
  static List<BoxShadow> get goldGlow => [
        BoxShadow(
          color: gold.withOpacity(0.22),
          blurRadius: 24,
          spreadRadius: 1,
        ),
      ];

  /// ظل بطاقة عادي
  static List<BoxShadow> get cardShadow => [
        BoxShadow(
          color: Colors.black.withOpacity(0.45),
          blurRadius: 18,
          offset: const Offset(0, 10),
        ),
      ];
}
