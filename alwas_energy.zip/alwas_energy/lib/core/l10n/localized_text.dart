/// نص ثنائي اللغة يُستخدم في بيانات النماذج (Mock / API)
class L {
  final String ar;
  final String en;
  const L(this.ar, this.en);

  String resolve({required bool arabic}) => arabic ? ar : en;

  @override
  String toString() => ar;
}
