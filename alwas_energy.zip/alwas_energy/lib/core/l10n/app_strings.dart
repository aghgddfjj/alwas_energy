import 'package:flutter/widgets.dart';

/// ============================================================================
///  الترجمة (العربية / الإنجليزية)
///  الطريقة: كل نص في التطبيق له Getter هنا ويعيد النص المناسب حسب اللغة.
///  لإضافة لغة ثالثة: أضف قيمة إلى enum AppLang + فرع في دالة pick.
/// ============================================================================
enum AppLang { ar, en }

class AppStrings {
  final AppLang lang;
  const AppStrings(this.lang);

  bool get isArabic => lang == AppLang.ar;

  /// اختيار النص حسب اللغة
  String pick(String ar, String en) => isArabic ? ar : en;

  static AppStrings of(BuildContext context) {
    final strings = Localizations.of<AppStrings>(context, AppStrings);
    return strings ?? const AppStrings(AppLang.ar);
  }

  // ------------------------------ عام ------------------------------
  String get appName => pick('الوس للطاقة', 'Alwas Energy');
  String get ok => pick('حسناً', 'OK');
  String get cancel => pick('إلغاء', 'Cancel');
  String get save => pick('حفظ', 'Save');
  String get share => pick('مشاركة', 'Share');
  String get copy => pick('نسخ', 'Copy');
  String get copied => pick('تم النسخ', 'Copied');
  String get close => pick('إغلاق', 'Close');
  String get retry => pick('إعادة المحاولة', 'Retry');
  String get currency => pick('ر.ي', 'YER');
  String get kwh => pick('كيلوواط', 'kWh');
  String get demoNotice => pick(
        'بيانات تجريبية — لم يتم ربط بوابة دفع أو خدمة شركة الكهرباء بعد.',
        'Demo data — no payment gateway or utility service is connected yet.',
      );
  String get seeAll => pick('عرض الكل', 'See all');

  // ------------------------------ الدخول ------------------------------
  String get loginTitle => pick('تسجيل الدخول', 'Sign in');
  String get loginSubtitle =>
      pick('سجّل الدخول إلى حسابك', 'Sign in to your account');
  String get username => pick('اسم المستخدم', 'Username');
  String get password => pick('كلمة المرور', 'Password');
  String get rememberMe => pick('تذكّر', 'Remember me');
  String get forgotPassword => pick('نسيت كلمة المرور؟', 'Forgot password?');
  String get loginButton => pick('تسجيل الدخول', 'Sign in');
  String get noAccount => pick('ما عندك حساب؟', 'No account yet?');
  String get registerNow => pick('سجّل الآن', 'Register now');
  String get loginEmptyFields => pick('الرجاء إدخال اسم المستخدم وكلمة المرور',
      'Please enter username and password');
  String get loginFailed => pick(
      'اسم المستخدم أو كلمة المرور غير صحيحة', 'Invalid username or password');
  String get loginSuccess =>
      pick('تم تسجيل الدخول بنجاح', 'Signed in successfully');
  String get loggingIn => pick('جارٍ تسجيل الدخول...', 'Signing in...');
  String get orSignInWith => pick('أو الدخول عبر', 'Or sign in with');
  String get guestLogin => pick('الدخول كزائر', 'Continue as guest');

  // ------------------------------ إنشاء حساب ------------------------------
  String get registerTitle => pick('إنشاء حساب جديد', 'Create account');
  String get registerSubtitle => pick('أدخل بياناتك لإنشاء حساب مشترك',
      'Enter your details to create an account');
  String get fullName => pick('الاسم الكامل', 'Full name');
  String get phone => pick('رقم الجوال', 'Phone number');
  String get email => pick('البريد الإلكتروني', 'Email');
  String get meterNumberLabel => pick('رقم العداد', 'Meter number');
  String get confirmPassword => pick('تأكيد كلمة المرور', 'Confirm password');
  String get agreeTerms =>
      pick('أوافق على الشروط والأحكام', 'I agree to the terms & conditions');
  String get registerButton => pick('إنشاء الحساب', 'Create account');
  String get haveAccount => pick('لديك حساب؟', 'Already have an account?');
  String get signIn => pick('تسجيل الدخول', 'Sign in');
  String get passwordMismatch =>
      pick('كلمتا المرور غير متطابقتين', 'Passwords do not match');
  String get mustAgree =>
      pick('يجب الموافقة على الشروط والأحكام', 'You must accept the terms');
  String get registerSuccess =>
      pick('تم إنشاء الحساب بنجاح', 'Account created successfully');
  String get invalidPhone =>
      pick('رقم الجوال غير صحيح', 'Invalid phone number');
  String get invalidEmail =>
      pick('البريد الإلكتروني غير صحيح', 'Invalid email address');

  // ------------------------------ القفل ------------------------------
  String get appLocked => pick('التطبيق مقفل', 'App locked');
  String get appLockedSub => pick('استخدم بصمتك أو رمز قفل الهاتف لفتح التطبيق',
      'Use your fingerprint or device passcode to unlock');
  String get touchFingerprint =>
      pick('المس رمز البصمة للمتابعة', 'Touch the fingerprint to continue');
  String get openApp => pick('فتح التطبيق', 'Open app');
  String get authenticating => pick('جارٍ التحقق...', 'Authenticating...');
  String get authFailed => pick(
      'فشل التحقق، حاول مرة أخرى', 'Verification failed, please try again');
  String get biometricUnavailable => pick(
      'البصمة غير متاحة على هذا الجهاز — تم فتح القفل تجريبياً',
      'Biometrics unavailable on this device — unlocked in demo mode');
  String get biometricReason =>
      pick('التحقق من هويتك لفتح التطبيق', 'Verify your identity to unlock');
  String get usePasswordInstead =>
      pick('الدخول بكلمة المرور', 'Use password instead');
  String get unlocked => pick('تم فتح القفل', 'Unlocked');

  // ------------------------------ التنقل ------------------------------
  String get home => pick('الرئيسية', 'Home');
  String get payment => pick('الدفع', 'Payment');
  String get invoices => pick('الفواتير', 'Invoices');
  String get menu => pick('القائمة', 'Menu');

  // ------------------------------ الرئيسية ------------------------------
  String get welcome => pick('مرحباً،', 'Welcome,');
  String get meterConnected => pick('العداد متصل', 'Meter connected');
  String get balance => pick('الرصيد الحالي', 'Current balance');
  String get currentLoad => pick('الحمل الحالي', 'Current load');
  String get upcomingOutage => pick('انقطاع قريب', 'Upcoming outage');
  String get remainingEnergy => pick('الطاقة المتبقية', 'Remaining energy');
  String get shareUsage => pick('مشاركة الاستخدام', 'Share usage');
  String get downloadData => pick('تنزيل البيانات', 'Download data');
  String get consumptionAnalysis =>
      pick('تحليل الاستهلاك', 'Consumption analysis');
  String get pickDate => pick('تحديد تاريخ', 'Pick date');
  String get hours => pick('ساعات', 'Hours');
  String get days => pick('أيام', 'Days');
  String get months => pick('أشهر', 'Months');
  String get thisMonthTotal => pick('هذا الشهر:', 'This month:');
  String get currentPeriod => pick('الفترة الحالية', 'Current period');
  String get lastPeriod => pick('الفترة السابقة', 'Previous period');
  String get latestOperations =>
      pick('أحدث العمليات والرسائل', 'Latest operations & messages');
  String get seeFullAnalysis =>
      pick('عرض التحليل الكامل', 'View full analysis');
  String get scheduleMaintenance =>
      pick('صيانة مجدولة', 'Scheduled maintenance');
  String get scheduleMaintenanceSub =>
      pick('إشعار من المحطة', 'Notice from the station');
  String get tariffUpdate => pick('تحديث التعرفة', 'Tariff update');
  String get tariffUpdateSub =>
      pick('إشعار من المحطة', 'Notice from the station');
  String get chargeSuccessMsg =>
      pick('نجح شحن العداد', 'Meter top-up succeeded');
  String get exportReady =>
      pick('تم تجهيز ملف البيانات ومشاركته', 'Data file prepared and shared');
  String get noNotifications => pick('لا توجد إشعارات', 'No notifications');

  // ------------------------------ الدفع ------------------------------
  String get meterType => pick('نوع العداد', 'Meter type');
  String get myMeter => pick('عدادي', 'My meter');
  String get otherMeter => pick('عداد آخر', 'Another meter');
  String get meterToCharge => pick('العداد المراد شحنه', 'Meter to charge');
  String get chargeVia => pick('توجه الشحن عبر', 'Top-up via');
  String get chooseTransfer =>
      pick('اختر طريقة التحويل', 'Choose transfer method');
  String get paymentData => pick('بيانات التسديد', 'Payment details');
  String get stationWallet => pick('رقم محفظة المحطة', 'Station wallet number');
  String get meterNumberNote => pick('رقم العداد (اكتبه في خانة الملاحظة)',
      'Meter number (write it in the note field)');
  String get howToPayJaib =>
      pick('طريقة التسديد عبر جيب', 'How to pay via Jaib');
  String get step1 => pick('افتح تطبيق جيب واختر "تحويل إلى مشترك".',
      'Open Jaib app and choose "Transfer to subscriber".');
  String get step2 => pick('أدخل رقم محفظة المحطة الموضح أعلاه.',
      'Enter the station wallet number shown above.');
  String get step3 => pick(
      'اكتب المبلغ الذي تريد شحنه.', 'Enter the amount you want to top up.');
  String get step4 => pick('في خانة الملاحظة اكتب رقم العداد.',
      'In the note field write the meter number.');
  String get step5 => pick('أكّد التحويل وسيصل الرصيد خلال دقائق.',
      'Confirm the transfer, the balance arrives within minutes.');
  String get amount => pick('المبلغ', 'Amount');
  String get quickAmounts => pick('مبالغ سريعة', 'Quick amounts');
  String get confirmTopUp => pick('تأكيد الشحن', 'Confirm top-up');
  String get enterAmount =>
      pick('أدخل مبلغاً صحيحاً', 'Please enter a valid amount');
  String get minAmount =>
      pick('الحد الأدنى للشحن 500 ر.ي', 'Minimum top-up is 500 YER');
  String get confirmTopUpTitle => pick('تأكيد عملية الشحن', 'Confirm top-up');
  String get confirmTopUpBody => pick(
        'سيتم شحن المبلغ للعداد المحدد. هذه محاكاة تجريبية ولن يتم خصم أي مبلغ حقيقي.',
        'The amount will be charged to the selected meter. This is a demo simulation, no real money is deducted.',
      );
  String get confirm => pick('تأكيد', 'Confirm');
  String get topUpDone => pick(
      'تم تنفيذ الشحن التجريبي بنجاح', 'Demo top-up completed successfully');
  String get topUpSuccessTitle => pick('تم الشحن بنجاح', 'Top-up successful');
  String get energyAdded => pick('الطاقة المضافة', 'Energy added');
  String get newBalance => pick('الرصيد الجديد', 'New balance');
  String get viewReceipt => pick('عرض الإيصال', 'View receipt');
  String get backHome => pick('العودة للرئيسية', 'Back to home');
  String get noPaymentMethod =>
      pick('اختر طريقة دفع أولاً', 'Choose a payment method first');

  // ------------------------------ الفواتير ------------------------------
  String get invoicesSummary =>
      pick('ملخص الفواتير والشحنات', 'Invoices & top-ups summary');
  String get totalCharges => pick('إجمالي الشحنات', 'Total top-ups');
  String get invoicesCount => pick('عدد الفواتير', 'Invoices count');
  String get topUpsLog =>
      pick('سجل الشحنات والفواتير', 'Top-ups & invoices log');
  String get completed => pick('مكتمل', 'Completed');
  String get pending => pick('معلق', 'Pending');
  String get digitalReceipt => pick('إيصال شحن رقمي', 'Digital top-up receipt');
  String get receiptNumber => pick('رقم الإيصال', 'Receipt number');
  String get subscriberName => pick('اسم المشترك', 'Subscriber name');
  String get accountNumber => pick('رقم السداد', 'Payment number');
  String get chargedAmount => pick('المبلغ المشحون', 'Charged amount');
  String get energyAddedLabel => pick('الطاقة المضافة', 'Energy added');
  String get balanceAfter => pick('الرصيد بعد الشحن', 'Balance after top-up');
  String get paymentMethod => pick('طريقة الدفع', 'Payment method');
  String get dateAndTime => pick('التاريخ والوقت', 'Date & time');
  String get certified => pick('معتمد', 'Certified');
  String get saveReport => pick('حفظ التقرير', 'Save receipt');
  String get shareReceipt => pick('مشاركة الإيصال', 'Share receipt');
  String get reportIssue => pick('الإبلاغ عن مشكلة', 'Report an issue');
  String get receiptSaved => pick('تم حفظ صورة الإيصال في مجلد التنزيلات',
      'Receipt image saved to Downloads');
  String get receiptSaveFailed =>
      pick('تعذّر حفظ الإيصال', 'Could not save the receipt');
  String get receiptCopied =>
      pick('تم نسخ بيانات الإيصال', 'Receipt details copied');
  String get noInvoices => pick('لا توجد فواتير بعد', 'No invoices yet');

  // ------------------------------ الدعم ------------------------------
  String get supportTitle =>
      pick('مركز الدعم والتشخيص الذكي', 'Support & smart diagnostics');
  String get networkHealthy => pick('فحص العداد والشبكة: متصل وسليم',
      'Meter & network check: connected and healthy');
  String get checking =>
      pick('جارٍ فحص العداد والشبكة...', 'Checking meter and network...');
  String get quickDiag =>
      pick('التشخيص السريع (بضغطة واحدة)', 'Quick diagnosis (one tap)');
  String get diagDelayCharge => pick('تأخر شحن', 'Delayed top-up');
  String get diagDelayChargeSub =>
      pick('عدّادك حوله مشكلة', 'Your meter may have an issue');
  String get diagDisconnect => pick('فصل العداد', 'Meter disconnection');
  String get diagDisconnectSub =>
      pick('فحص انقطاع الخدمة', 'Check the service outage');
  String get diagInvoice => pick('استفسار فاتورة', 'Invoice inquiry');
  String get diagInvoiceSub =>
      pick('مراجعة الشركة بالرصيد', 'Review the balance with the company');
  String get diagEmergency => pick('بلاغ طارئ', 'Emergency report');
  String get diagEmergencySub =>
      pick('حلّل فوراً العدّاد', 'Analyze the meter immediately');
  String get ticketsLog =>
      pick('سجل البلاغات والتذاكر', 'Reports & tickets log');
  String get newTicket => pick('تذكرة جديدة', 'New ticket');
  String get statusOpen => pick('مفتوحة', 'Open');
  String get statusResolved => pick('مغلقة', 'Closed');
  String get stepReceived => pick('تم الاستلام', 'Received');
  String get stepProcessing => pick('قيد المعالجة', 'In progress');
  String get stepDone => pick('تم الحل', 'Resolved');
  String get ticketDelayCharge => pick('تأخر شحن', 'Delayed top-up');
  String get ticketDisconnected =>
      pick('العداد مفصول رغم وجود رصيد', 'Meter disconnected despite balance');
  String get ticketInvoiceInquiry =>
      pick('استفسار عن الفاتورة', 'Invoice inquiry');
  String get ticketSubject => pick('موضوع البلاغ', 'Report subject');
  String get ticketDetails => pick('تفاصيل البلاغ', 'Report details');
  String get send => pick('إرسال', 'Send');
  String get ticketCreated =>
      pick('تم إنشاء التذكرة بنجاح', 'Ticket created successfully');
  String get diagnosisDone => pick('تم الفحص: لا توجد أعطال في العداد',
      'Check complete: no meter faults found');

  // ------------------------------ الإعدادات ------------------------------
  String get settings => pick('الإعدادات', 'Settings');
  String get smartSubscriberCard =>
      pick('بطاقة المشترك الذكية', 'Smart subscriber card');
  String get monthlyCap => pick('السقف الشهري (ك.و.س)', 'Monthly cap (kWh)');
  String get ofCap => pick('من السقف', 'of cap');
  String get notificationsSetting => pick('الإشعارات', 'Notifications');
  String get notificationsSettingSub =>
      pick('تنبيهات الشحن وانقطاع الخدمة', 'Top-up and outage alerts');
  String get biometricLock => pick('القفل بالبصمة', 'Biometric lock');
  String get biometricLockSub => pick(
      'سيطلب بصمتك عند فتح التطبيق', 'Asks for your fingerprint on app launch');
  String get lockPreview =>
      pick('معاينة شاشة قفل البصمة', 'Preview lock screen');
  String get changePassword => pick('تغيير كلمة المرور', 'Change password');
  String get language => pick('اللغة', 'Language');
  String get about => pick('عن التطبيق', 'About');
  String get logout => pick('تسجيل الخروج', 'Sign out');
  String get logoutConfirm =>
      pick('هل تريد تسجيل الخروج؟', 'Do you want to sign out?');
  String get version => pick('الإصدار', 'Version');
  String get appearance => pick('المظهر', 'Appearance');
  String get darkGoldTheme => pick('الوضع الداكن الذهبي', 'Dark gold mode');
  String get currentPassword => pick('كلمة المرور الحالية', 'Current password');
  String get newPassword => pick('كلمة المرور الجديدة', 'New password');
  String get passwordChanged =>
      pick('تم تغيير كلمة المرور', 'Password changed');
  String get passwordTooShort => pick(
      'كلمة المرور قصيرة جداً (4 أحرف على الأقل)',
      'Password too short (min 4 characters)');
  String get oldPasswordWrong =>
      pick('كلمة المرور الحالية غير صحيحة', 'Current password is incorrect');

  // ------------------------------ القائمة الجانبية ------------------------------
  String get myAccount => pick('حسابي', 'My account');
  String get notificationsItem => pick('الإشعارات', 'Notifications');
  String get supportItem => pick('الدعم الفني', 'Support');
  String get settingsItem => pick('الإعدادات', 'Settings');
  String get languageItem => pick('اللغة', 'Language');
  String get changeAvatar => pick('تغيير الصورة الرمزية', 'Change avatar');
  String get subscriberSince => pick('مشترك منذ', 'Subscriber since');
  String get switchLanguage => pick('English', 'العربية');

  // ------------------------------ حسابي ------------------------------
  String get accountInfo => pick('بيانات الحساب', 'Account details');
  String get myMeters => pick('عداداتي', 'My meters');
  String get editProfile => pick('تعديل البيانات', 'Edit profile');
  String get savedAddress => pick('العنوان', 'Address');
  String get city => pick('المدينة', 'City');
  String get profileUpdated => pick('تم تحديث البيانات', 'Profile updated');
  String get subscriberNumber => pick('رقم المشترك', 'Subscriber number');

  // ------------------------------ تحليل الاستهلاك ------------------------------
  String get averageDaily => pick('المتوسط اليومي', 'Daily average');
  String get peakUsage => pick('أعلى استهلاك', 'Peak usage');
  String get estimatedCost => pick('التكلفة التقديرية', 'Estimated cost');
  String get usageBreakdown => pick('توزيع الاستهلاك', 'Usage breakdown');
  String get dailyDetails => pick('التفاصيل اليومية', 'Daily details');
  String get day => pick('اليوم', 'Day');
  String get consumption => pick('الاستهلاك', 'Consumption');
  String get cost => pick('التكلفة', 'Cost');
}

/// ============================================================================
///  LocalizationsDelegate حتى تعمل AppStrings.of(context) مع تغيير اللغة
/// ============================================================================
class AppStringsDelegate extends LocalizationsDelegate<AppStrings> {
  const AppStringsDelegate();

  @override
  bool isSupported(Locale locale) => ['ar', 'en'].contains(locale.languageCode);

  @override
  Future<AppStrings> load(Locale locale) async =>
      AppStrings(locale.languageCode == 'en' ? AppLang.en : AppLang.ar);

  @override
  bool shouldReload(AppStringsDelegate old) => false;
}
