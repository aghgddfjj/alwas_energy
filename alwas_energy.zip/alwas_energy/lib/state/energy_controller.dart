import 'package:flutter/foundation.dart';

import '../data/mock/mock_data.dart';
import '../data/models/models.dart';
import '../data/repositories/app_repository.dart';

/// ============================================================================
///  حالة الطاقة: العدادات + طرق الدفع + الإيصالات + تحليل الاستهلاك
/// ============================================================================
class EnergyController extends ChangeNotifier {
  final AppRepository _repo;

  EnergyController(this._repo);

  List<MeterModel> _meters = [];
  List<PaymentMethodModel> _methods = [];
  List<ReceiptModel> _receipts = [];
  final Map<ConsumptionRange, ConsumptionSummary> _summaryCache = {};

  int _selectedMeterIndex = 0;
  int _selectedMethodIndex = 0;
  ConsumptionRange _range = ConsumptionRange.days;

  bool _loading = true;
  bool _topUpBusy = false;

  List<MeterModel> get meters => _meters;
  List<PaymentMethodModel> get methods => _methods;
  List<ReceiptModel> get receipts => _receipts;
  int get selectedMeterIndex => _selectedMeterIndex;
  int get selectedMethodIndex => _selectedMethodIndex;
  ConsumptionRange get range => _range;
  bool get loading => _loading;
  bool get topUpBusy => _topUpBusy;

  MeterModel? get selectedMeter => _meters.isEmpty
      ? null
      : _meters[_selectedMeterIndex.clamp(0, _meters.length - 1)];

  PaymentMethodModel? get selectedMethod => _methods.isEmpty
      ? null
      : _methods[_selectedMethodIndex.clamp(0, _methods.length - 1)];

  ConsumptionSummary? get summary => _summaryCache[_range];

  /// إجمالي الشحنات (كما في شاشة الفواتير)
  double get totalCharged =>
      _receipts.fold<double>(0, (sum, r) => sum + r.amount);

  int get receiptsCount => _receipts.length;

  /// بيانات الرسم الموجي في ملخص الفواتير
  List<double> get invoicesWave => MockData.invoicesWave;

  Future<void> load() async {
    _loading = true;
    notifyListeners();
    final results = await Future.wait([
      _repo.fetchMeters(),
      _repo.fetchPaymentMethods(),
      _repo.fetchReceipts(),
      _repo.fetchConsumption(ConsumptionRange.days),
    ]);
    _meters = results[0] as List<MeterModel>;
    _methods = results[1] as List<PaymentMethodModel>;
    _receipts = results[2] as List<ReceiptModel>;
    _summaryCache[ConsumptionRange.days] = results[3] as ConsumptionSummary;
    _loading = false;
    notifyListeners();
  }

  void selectMeter(int index) {
    if (index == _selectedMeterIndex || index < 0 || index >= _meters.length) {
      return;
    }
    _selectedMeterIndex = index;
    notifyListeners();
  }

  /// اختيار العداد برقمه (يُستخدم عند اختيار "عداد آخر")
  void selectMeterByNumber(String number) {
    final index = _meters.indexWhere((m) => m.number == number);
    if (index != -1) selectMeter(index);
  }

  void selectMethod(int index) {
    if (index == _selectedMethodIndex ||
        index < 0 ||
        index >= _methods.length) {
      return;
    }
    _selectedMethodIndex = index;
    notifyListeners();
  }

  Future<void> setRange(ConsumptionRange range) async {
    _range = range;
    notifyListeners();
    if (_summaryCache.containsKey(range)) return;
    final summary = await _repo.fetchConsumption(range);
    _summaryCache[range] = summary;
    notifyListeners();
  }

  /// تنفيذ شحن (تجريبي) وإرجاع الإيصال الناتج
  Future<ReceiptModel> topUp(double amount) async {
    final meter = selectedMeter;
    final method = selectedMethod;
    if (meter == null || method == null) {
      throw StateError('meter or method is null');
    }
    _topUpBusy = true;
    notifyListeners();
    final receipt = await _repo.createTopUp(
      meter: meter,
      amount: amount,
      method: method,
    );
    // تحديث العدادات والإيصالات من المصدر
    _meters = await _repo.fetchMeters();
    _receipts = await _repo.fetchReceipts();
    _topUpBusy = false;
    notifyListeners();
    return receipt;
  }

  /// تعديل السقف الشهري للعداد المحدد (في الإنتاج: PATCH إلى الخدمة)
  void setMonthlyCap(double capKwh) {
    final index = _selectedMeterIndex;
    if (index < 0 || index >= _meters.length) return;
    _meters[index] = _meters[index].copyWith(monthlyCapKwh: capKwh);
    notifyListeners();
  }

  ReceiptModel? receiptById(String id) {
    for (final r in _receipts) {
      if (r.id == id) return r;
    }
    return null;
  }
}
