import 'package:flutter/foundation.dart';

import '../services/storage_service.dart';

/// ============================================================================
///  حالة المصباح المعلّق
///  isOn = مضاء / منطفئ. تُحفظ القيمة محلياً ليبقى المصباح كما تركه المستخدم.
///  الشدّة (intensity) تُدار بأنيميشن داخل HangingLamp نفسه.
/// ============================================================================
class LampController extends ChangeNotifier {
  final StorageService _storage;
  LampController(this._storage) : _isOn = _storage.lampOn;

  bool _isOn;
  bool get isOn => _isOn;

  /// عدد مرات السحب (يُستخدم لإظهار تلميح "اسحب الخيط" أول مرة فقط)
  int pullCount = 0;

  Future<void> toggle() async {
    _isOn = !_isOn;
    pullCount++;
    notifyListeners();
    await _storage.setLampOn(_isOn);
  }

  Future<void> setOn(bool value) async {
    if (_isOn == value) return;
    _isOn = value;
    notifyListeners();
    await _storage.setLampOn(value);
  }
}
