import 'package:flutter/foundation.dart';

import '../data/models/models.dart';
import '../data/repositories/app_repository.dart';

/// ============================================================================
///  حالة الدعم والإشعارات: التذاكر + التشخيص الذكي + الإشعارات
/// ============================================================================
class SupportController extends ChangeNotifier {
  final AppRepository _repo;
  SupportController(this._repo);

  List<SupportTicket> _tickets = [];
  List<AppNotification> _notifications = [];
  bool _loading = true;
  bool _diagnosing = false;
  bool _networkHealthy = true;

  List<SupportTicket> get tickets => _tickets;
  List<AppNotification> get notifications => _notifications;
  bool get loading => _loading;
  bool get diagnosing => _diagnosing;
  bool get networkHealthy => _networkHealthy;

  int get unreadCount => _notifications.where((n) => !n.read).length;

  Future<void> load() async {
    _loading = true;
    notifyListeners();
    final results = await Future.wait([
      _repo.fetchTickets(),
      _repo.fetchNotifications(),
    ]);
    _tickets = results[0] as List<SupportTicket>;
    _notifications = results[1] as List<AppNotification>;
    _loading = false;
    notifyListeners();
  }

  /// تشخيص سريع: يحاكي فحص الشبكة/العداد (في الإنتاج: طلب إلى خدمة العدادات)
  Future<bool> runDiagnostics() async {
    _diagnosing = true;
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 1400));
    _networkHealthy = true;
    _diagnosing = false;
    notifyListeners();
    return true;
  }

  Future<SupportTicket> createTicket({
    required String title,
    required String details,
  }) async {
    final ticket = await _repo.createTicket(title: title, details: details);
    _tickets = await _repo.fetchTickets();
    notifyListeners();
    return ticket;
  }

  Future<void> refreshNotifications() async {
    _notifications = await _repo.fetchNotifications();
    notifyListeners();
  }

  void markAllRead() {
    _notifications = _notifications.map((n) => n.markRead()).toList();
    notifyListeners();
  }
}
