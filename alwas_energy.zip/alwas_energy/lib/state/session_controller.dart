import 'package:flutter/foundation.dart';

import '../core/l10n/app_strings.dart';
import '../data/models/models.dart';
import '../data/repositories/app_repository.dart';
import '../services/biometric_service.dart';
import '../services/storage_service.dart';

enum SessionStatus { signedOut, locked, unlocked }

/// ============================================================================
///  إدارة الجلسة: تسجيل الدخول / إنشاء حساب / القفل بالبصمة / الخروج
/// ============================================================================
class SessionController extends ChangeNotifier {
  final AppRepository _repo;
  final StorageService _storage;
  final BiometricService biometrics;

  SessionController({
    required AppRepository repository,
    required StorageService storage,
    BiometricService? biometrics,
  })  : _repo = repository,
        _storage = storage,
        biometrics = biometrics ?? BiometricService(),
        _status =
            storage.signedIn ? SessionStatus.locked : SessionStatus.signedOut;

  SessionStatus _status;
  UserProfile? _user;
  bool _busy = false;
  String? _errorKey;

  SessionStatus get status => _status;
  UserProfile? get user => _user;
  bool get busy => _busy;
  String? get errorKey => _errorKey;

  /// هل يوجد جلسة محفوظة (لاختيار الشاشة الأولى)
  bool get hasSavedSession => _storage.signedIn;

  /// استعادة المستخدم المحفوظ عند بدء التطبيق
  Future<void> restore() async {
    if (_user != null) return;
    final saved = await _repo.currentUser();
    if (saved != null) {
      _user = saved;
      notifyListeners();
    }
  }

  void _setBusy(bool value) {
    _busy = value;
    notifyListeners();
  }

  // ------------------------------ تسجيل الدخول ------------------------------
  Future<bool> signIn(
      {required String username, required String password}) async {
    _errorKey = null;
    _setBusy(true);
    final result = await _repo.signIn(username: username, password: password);
    _setBusy(false);
    if (result == null) {
      _errorKey = 'loginFailed';
      notifyListeners();
      return false;
    }
    _user = result;
    _status = SessionStatus.unlocked;
    await _storage.setSignedIn(true);
    notifyListeners();
    return true;
  }

  // ------------------------------ إنشاء حساب ------------------------------
  Future<bool> register({
    required String fullName,
    required String phone,
    required String email,
    required String password,
    required String meterNumber,
  }) async {
    _setBusy(true);
    final user = await _repo.register(
      fullName: fullName,
      phone: phone,
      email: email,
      password: password,
      meterNumber: meterNumber,
    );
    _user = user;
    _status = SessionStatus.unlocked;
    await _storage.setSignedIn(true);
    _setBusy(false);
    return true;
  }

  // ------------------------------ القفل / الفتح ------------------------------
  void lock() {
    if (_status == SessionStatus.signedOut) return;
    _status = SessionStatus.locked;
    notifyListeners();
  }

  void unlockSilently() {
    _status = SessionStatus.unlocked;
    notifyListeners();
  }

  /// يطلب بصمة الجهاز؛ في حال عدم توفرها يفتح القفل في الوضع التجريبي
  Future<BiometricResult> unlockWithBiometrics(AppStrings strings) async {
    _setBusy(true);
    final result =
        await biometrics.authenticate(reason: strings.biometricReason);
    _setBusy(false);
    if (result.status == BiometricStatus.success ||
        result.status == BiometricStatus.unavailable) {
      _status = SessionStatus.unlocked;
      notifyListeners();
    }
    return result;
  }

  // ------------------------------ الخروج ------------------------------
  Future<void> signOut() async {
    _user = null;
    _status = SessionStatus.signedOut;
    await _storage.setSignedIn(false);
    notifyListeners();
  }

  Future<void> updateProfile(UserProfile updated) async {
    _user = await _repo.updateProfile(updated);
    notifyListeners();
  }

  void clearError() {
    _errorKey = null;
    notifyListeners();
  }
}
