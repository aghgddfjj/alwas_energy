import 'package:flutter/material.dart';

import '../core/l10n/app_strings.dart';
import '../services/storage_service.dart';

/// ============================================================================
///  إعدادات التطبيق: اللغة + القفل بالبصمة + الإشعارات + تذكّر الدخول
///  تُخزَّن في SharedPreferences وتبقى بعد إغلاق التطبيق.
/// ============================================================================
class AppSettingsController extends ChangeNotifier {
  final StorageService _storage;

  AppSettingsController(this._storage)
      : _lang = _storage.language == 'en' ? AppLang.en : AppLang.ar,
        _biometricEnabled = _storage.biometricEnabled,
        _notificationsEnabled = _storage.notificationsEnabled,
        _rememberMe = _storage.rememberMe;

  AppLang _lang;
  bool _biometricEnabled;
  bool _notificationsEnabled;
  bool _rememberMe;

  AppLang get lang => _lang;
  bool get isArabic => _lang == AppLang.ar;
  Locale get locale => Locale(_lang == AppLang.ar ? 'ar' : 'en');
  AppStrings get strings => AppStrings(_lang);
  bool get biometricEnabled => _biometricEnabled;
  bool get notificationsEnabled => _notificationsEnabled;
  bool get rememberMe => _rememberMe;

  Future<void> setLanguage(AppLang value) async {
    if (_lang == value) return;
    _lang = value;
    notifyListeners();
    await _storage.setLanguage(value == AppLang.ar ? 'ar' : 'en');
  }

  Future<void> toggleLanguage() =>
      setLanguage(_lang == AppLang.ar ? AppLang.en : AppLang.ar);

  Future<void> setBiometricEnabled(bool value) async {
    _biometricEnabled = value;
    notifyListeners();
    await _storage.setBiometricEnabled(value);
  }

  Future<void> setNotificationsEnabled(bool value) async {
    _notificationsEnabled = value;
    notifyListeners();
    await _storage.setNotificationsEnabled(value);
  }

  Future<void> setRememberMe(bool value) async {
    _rememberMe = value;
    notifyListeners();
    await _storage.setRememberMe(value);
  }
}
