import 'package:flutter/services.dart';
import 'package:local_auth/error_codes.dart' as auth_error;
import 'package:local_auth/local_auth.dart';

/// نتيجة محاولة التحقق بالبصمة
enum BiometricStatus { success, failed, unavailable, error }

class BiometricResult {
  final BiometricStatus status;
  final String? message;
  const BiometricResult(this.status, [this.message]);
}

/// ============================================================================
///  خدمة البصمة (local_auth)
///  - canCheckBiometrics : هل الجهاز يدعم البصمة/الوجه
///  - authenticate       : إظهار نافذة البصمة الأصلية في أندرويد
///  ملاحظة: على المحاكي قد لا تكون البصمة مسجّلة، لذلك نُرجع unavailable
///  ونسمح بالدخول في الوضع التجريبي (انظر SessionController.unlock).
/// ============================================================================
class BiometricService {
  final LocalAuthentication _auth = LocalAuthentication();

  Future<bool> isAvailable() async {
    try {
      final canCheck = await _auth.canCheckBiometrics;
      final supported = await _auth.isDeviceSupported();
      return canCheck && supported;
    } on PlatformException {
      return false;
    }
  }

  Future<BiometricResult> authenticate({required String reason}) async {
    try {
      final available = await isAvailable();
      if (!available) {
        return const BiometricResult(BiometricStatus.unavailable);
      }
      final ok = await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false, // يسمح أيضاً برمز قفل الجهاز كبديل
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
      return ok
          ? const BiometricResult(BiometricStatus.success)
          : const BiometricResult(BiometricStatus.failed);
    } on PlatformException catch (e) {
      if (e.code == auth_error.notAvailable ||
          e.code == auth_error.notEnrolled) {
        return const BiometricResult(BiometricStatus.unavailable);
      }
      return BiometricResult(BiometricStatus.error, e.message);
    } catch (_) {
      // أي خطأ آخر (مثل عدم توفر الإضافة على المنصة) => البصمة غير متاحة
      return const BiometricResult(BiometricStatus.unavailable);
    }
  }
}
