import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// ============================================================================
///  خدمة تصدير الإيصالات ومشاركة البيانات
///  1) captureImage  : تحويل أي Widget (الإيصال) إلى صورة PNG عبر RepaintBoundary
///  2) saveImage     : حفظ الصورة داخل مجلد التطبيق ثم إظهار المسار
///  3) shareImage    : مشاركة الصورة عبر تطبيقات الجهاز (واتساب، بريد، ...)
///  4) shareText     : مشاركة نص (بيانات الإيصال / الاستهلاك)
///  5) saveCsv       : حفظ بيانات الاستهلاك كملف CSV ومشاركته
/// ============================================================================
class ExportService {
  static Future<Uint8List?> captureImage(GlobalKey boundaryKey) async {
    try {
      final ctx = boundaryKey.currentContext;
      if (ctx == null) return null;
      final boundary = ctx.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) return null;
      final image = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      return byteData?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }

  static Future<Directory> _outputDirectory() async {
    // أندرويد: مجلد التطبيق الخارجي (لا يحتاج صلاحية)
    if (Platform.isAndroid) {
      final external = await getExternalStorageDirectory();
      if (external != null) return external;
    }
    final downloads = await getDownloadsDirectory();
    if (downloads != null) return downloads;
    return getApplicationDocumentsDirectory();
  }

  /// يحفظ الصورة ويعيد مسار الملف، أو null عند الفشل
  static Future<String?> saveImage(Uint8List bytes, String fileName) async {
    try {
      final dir = await _outputDirectory();
      final receiptsDir = Directory('${dir.path}/alwas_receipts');
      if (!await receiptsDir.exists()) {
        await receiptsDir.create(recursive: true);
      }
      final file = File('${receiptsDir.path}/$fileName');
      await file.writeAsBytes(bytes, flush: true);
      return file.path;
    } catch (_) {
      return null;
    }
  }

  static Future<bool> shareImage(
      Uint8List bytes, String fileName, String text) async {
    try {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes, flush: true);
      final result = await Share.shareXFiles(
        [XFile(file.path, mimeType: 'image/png')],
        text: text,
      );
      return result.status == ShareResultStatus.success;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> shareText(String text, {String? subject}) async {
    try {
      final result = await Share.share(text, subject: subject);
      return result.status == ShareResultStatus.success;
    } catch (_) {
      return false;
    }
  }

  /// حفظ جدول بيانات كملف CSV (يُفتح في Excel / Google Sheets)
  static Future<String?> saveCsv(
      List<List<String>> rows, String fileName) async {
    try {
      final buffer = StringBuffer();
      for (final row in rows) {
        buffer.writeln(row.map(_escapeCsv).join(','));
      }
      final dir = await _outputDirectory();
      final file = File('${dir.path}/$fileName');
      await file.writeAsString(buffer.toString(), flush: true);
      return file.path;
    } catch (_) {
      return null;
    }
  }

  static String _escapeCsv(String value) {
    if (value.contains(',') || value.contains('"') || value.contains('\n')) {
      return '"${value.replaceAll('"', '""')}"';
    }
    return value;
  }
}
