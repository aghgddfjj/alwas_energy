import 'package:shared_preferences/shared_preferences.dart';

/// ============================================================================
///  خدمة التخزين المحلي (SharedPreferences)
///  تحفظ: اللغة، القفل بالبصمة، الإشعارات، تذكّر الدخول، وحالة تسجيل الدخول.
/// ============================================================================
class StorageService {
  static const String _kLang = 'app_lang';
  static const String _kBiometric = 'biometric_enabled';
  static const String _kNotifications = 'notifications_enabled';
  static const String _kRemember = 'remember_me';
  static const String _kSignedIn = 'signed_in';
  static const String _kLampOn = 'lamp_on';

  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  String get language => _prefs.getString(_kLang) ?? 'ar';
  Future<void> setLanguage(String value) => _prefs.setString(_kLang, value);

  bool get biometricEnabled => _prefs.getBool(_kBiometric) ?? true;
  Future<void> setBiometricEnabled(bool value) =>
      _prefs.setBool(_kBiometric, value);

  bool get notificationsEnabled => _prefs.getBool(_kNotifications) ?? true;
  Future<void> setNotificationsEnabled(bool value) =>
      _prefs.setBool(_kNotifications, value);

  bool get rememberMe => _prefs.getBool(_kRemember) ?? true;
  Future<void> setRememberMe(bool value) => _prefs.setBool(_kRemember, value);

  bool get signedIn => _prefs.getBool(_kSignedIn) ?? false;
  Future<void> setSignedIn(bool value) => _prefs.setBool(_kSignedIn, value);

  bool get lampOn => _prefs.getBool(_kLampOn) ?? true;
  Future<void> setLampOn(bool value) => _prefs.setBool(_kLampOn, value);
}
