import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme/app_colors.dart';

/// ============================================================================
///  المصباح المعلّق التفاعلي (HangingLamp)
///  ---------------------------------------------------------------------------
///  • سلك من سقف الشاشة + غطاء + مظلّة (شيد) + حلقة مضيئة + لمبة.
///  • خيط صغير متدلٍ بجانب المصباح ينتهي بحبّة ذهبية.
///  • اسحب الخيط للأسفل (Drag) فينطفئ/يضيء المصباح، مع حركة سحب مطّاطية واقعية.
///  • تمايل خفيف مستمر (Pendulum) مثل المصباح الحقيقي.
///  • شعاع ضوء ذهبي + توهّج + ذرات غبار متحركة (Dust particles) عند الإضاءة.
///  • كل الحركات مرسومة برمجياً (CustomPainter + AnimationController)
///    بدون أي صورة أو ملف حركة خارجي، لتبقى خفيفة وسريعة.
/// ============================================================================
class HangingLamp extends StatefulWidget {
  const HangingLamp({
    super.key,
    required this.isOn,
    required this.onToggle,
    this.width = 260,
    this.height = 320,
    this.showHint = false,
    this.hintText,
  });

  /// حالة المصباح (مضاء / منطفئ)
  final bool isOn;

  /// تُستدعى عند سحب الخيط أو لمس اللمبة
  final VoidCallback onToggle;

  final double width;
  final double height;

  /// إظهار تلميح "اسحب الخيط" (يظهر على شاشة الدخول)
  final bool showHint;
  final String? hintText;

  @override
  State<HangingLamp> createState() => _HangingLampState();
}

class _HangingLampState extends State<HangingLamp>
    with TickerProviderStateMixin {
  /// تمايل المصباح (يمين/يسار) — مستمر وبطيء
  late final AnimationController _swing;

  /// مقدار سحب الخيط 0..1
  late final AnimationController _pull;

  /// توهّج الضوء 0 (منطفئ) .. 1 (مضاء)
  late final AnimationController _glow;

  /// حركة ذرات الغبار
  late final AnimationController _dust;

  double _dragStartValue = 0;
  bool _dragging = false;

  @override
  void initState() {
    super.initState();
    _swing = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    )..repeat(reverse: true);

    _pull = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
      value: 0,
    );

    _glow = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 750),
      value: widget.isOn ? 1 : 0,
    );

    _dust = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 9),
    )..repeat();
  }

  @override
  void didUpdateWidget(covariant HangingLamp oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.isOn != widget.isOn) {
      if (widget.isOn) {
        _glow.forward();
      } else {
        _glow.reverse();
      }
    }
  }

  @override
  void dispose() {
    _swing.dispose();
    _pull.dispose();
    _glow.dispose();
    _dust.dispose();
    super.dispose();
  }

  // ------------------------------ السحب ------------------------------
  void _onDragStart(DragStartDetails details) {
    _dragging = true;
    _pull.stop();
    _dragStartValue = 0;
  }

  void _onDragUpdate(DragUpdateDetails details) {
    if (!_dragging) return;
    // 46 بكسل سحب = سحب كامل
    _dragStartValue = (_dragStartValue + details.delta.dy / 46).clamp(0.0, 1.0);
    _pull.value = _dragStartValue;
  }

  void _onDragEnd(DragEndDetails details) {
    if (!_dragging) return;
    _dragging = false;
    final shouldToggle =
        _pull.value > 0.45 || details.velocity.pixelsPerSecond.dy > 320;
    // ارتداد مطّاطي للخيط
    _pull.animateTo(
      0,
      duration: const Duration(milliseconds: 900),
      curve: Curves.elasticOut,
    );
    if (shouldToggle) {
      HapticFeedback.mediumImpact();
      widget.onToggle();
    }
  }

  void _onBulbTap() {
    HapticFeedback.lightImpact();
    widget.onToggle();
  }

  @override
  Widget build(BuildContext context) {
    final size = Size(widget.width, widget.height);

    return SizedBox(
      width: size.width,
      height: size.height,
      child: AnimatedBuilder(
        animation: Listenable.merge([_swing, _pull, _glow, _dust]),
        builder: (context, _) {
          final glow = Curves.easeOut.transform(_glow.value);
          // تمايل: يزيد قليلاً لحظة السحب ثم يعود
          final swingAngle = math.sin(_swing.value * math.pi * 2) *
              (0.016 + _pull.value * 0.02);

          return Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.topCenter,
            children: [
              // ---------------- شعاع الضوء + ذرات الغبار ----------------
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _BeamPainter(
                      intensity: glow,
                      dustPhase: _dust.value,
                    ),
                  ),
                ),
              ),

              // ---------------- جسم المصباح (يتمايل) ----------------
              Positioned.fill(
                child: Transform.rotate(
                  angle: swingAngle,
                  alignment: Alignment.topCenter,
                  child: Stack(
                    alignment: Alignment.topCenter,
                    clipBehavior: Clip.none,
                    children: [
                      // السلك + المظلة + اللمبة
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _LampBodyPainter(
                              intensity: glow,
                              pull: _pull.value,
                              size: size,
                            ),
                          ),
                        ),
                      ),

                      // منطقة لمس اللمبة (تشغيل/إطفاء سريع)
                      Positioned(
                        top: size.height * 0.17,
                        width: 120,
                        height: 60,
                        child: GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: _onBulbTap,
                          child: const SizedBox.expand(),
                        ),
                      ),

                      // ---------------- الخيط القابل للسحب ----------------
                      Positioned(
                        // منطقة الخيط: تبدأ من حافة المظلة وتغطي الحبّة
                        top: size.height * 0.19,
                        left: size.width / 2 + size.width * 0.109 - 22,
                        width: 44,
                        height: size.height * 0.28,
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onVerticalDragStart: _onDragStart,
                          onVerticalDragUpdate: _onDragUpdate,
                          onVerticalDragEnd: _onDragEnd,
                          onTap: _onBulbTap,
                          child: const MouseRegion(
                            cursor: SystemMouseCursors.grab,
                            child: SizedBox.expand(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // ---------------- تلميح السحب ----------------
              if (widget.showHint && widget.hintText != null)
                Positioned(
                  top: size.height + 6,
                  child: IgnorePointer(
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 400),
                      opacity: _dragging ? 1 : 0.55,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.keyboard_double_arrow_down_rounded,
                            size: 14,
                            color: AppColors.gold,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            widget.hintText!,
                            style: const TextStyle(
                              fontFamily: 'Tajawal',
                              fontSize: 11,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
///  رسم شعاع الضوء + الهالة + ذرات الغبار
/// ---------------------------------------------------------------------------
class _BeamPainter extends CustomPainter {
  _BeamPainter({required this.intensity, required this.dustPhase});

  final double intensity; // 0..1
  final double dustPhase; // 0..1

  // هندسة مشتركة مع _LampBodyPainter (نسب من حجم المصباح)
  static const double rimYRatio = 0.215;
  static const double rimHalfRatio = 0.21;

  @override
  void paint(Canvas canvas, Size size) {
    if (intensity <= 0.01) return;

    final cx = size.width / 2;
    final rimY = size.height * rimYRatio;
    final rimHalf = size.width * rimHalfRatio;
    final bottomY = size.height;
    final bottomHalf = size.width * 0.56;

    // 1) مخروط الضوء المنبعث من فتحة المظلة
    final beamPath = Path()
      ..moveTo(cx - rimHalf, rimY)
      ..lineTo(cx + rimHalf, rimY)
      ..lineTo(cx + bottomHalf, bottomY)
      ..quadraticBezierTo(cx, bottomY + 26, cx - bottomHalf, bottomY)
      ..close();

    final beamPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xA6FFD489),
          Color(0x59FFC462),
          Color(0x1FE8A33D),
          Color(0x00E8A33D),
        ],
        stops: [0.0, 0.30, 0.66, 1.0],
      ).createShader(Rect.fromLTWH(0, rimY, size.width, bottomY - rimY))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10)
      ..blendMode = BlendMode.plus;

    canvas.saveLayer(
      Offset.zero & size,
      Paint()..color = Colors.white.withOpacity(intensity.clamp(0.0, 1.0)),
    );
    canvas.drawPath(beamPath, beamPaint);

    // 2) هالة دائرية حول فتحة المظلة
    final haloCenter = Offset(cx, rimY + 2);
    final haloPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFFFFE7B8).withOpacity(0.9 * intensity),
          const Color(0xFFFFC462).withOpacity(0.28 * intensity),
          const Color(0xFFE8A33D).withOpacity(0.0),
        ],
        stops: const [0.0, 0.42, 1.0],
      ).createShader(
          Rect.fromCircle(center: haloCenter, radius: size.width * 0.42))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18)
      ..blendMode = BlendMode.plus;
    canvas.drawCircle(haloCenter, size.width * 0.42, haloPaint);

    // 3) ذرات الغبار الطافية داخل الشعاع
    final dustPaint = Paint()..blendMode = BlendMode.plus;
    for (var i = 0; i < 18; i++) {
      final seed = (i * 97) % 100 / 100;
      final seedY = (i * 53) % 100 / 100;
      final t = (dustPhase + seed) % 1.0;
      final y = rimY + 22 + (bottomY - rimY - 34) * ((t + seedY) % 1.0);
      final spread = 0.10 + 0.46 * ((y - rimY) / (bottomY - rimY));
      final x =
          cx + math.sin((t + seed) * math.pi * 4) * size.width * spread * 0.55;
      final r = 0.7 + 1.7 * (((i * 31) % 10) / 10);
      final fade = (1 - ((y - rimY) / (bottomY - rimY))).clamp(0.0, 1.0);
      dustPaint.color = const Color(0xFFFFE0A8).withOpacity(
        (0.5 * intensity * fade).clamp(0.0, 1.0),
      );
      canvas.drawCircle(Offset(x, y), r, dustPaint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _BeamPainter old) =>
      old.intensity != intensity || old.dustPhase != dustPhase;
}

/// ---------------------------------------------------------------------------
///  رسم السلك + المظلة + الحلقة المضيئة + الخيط والحبّة
/// ---------------------------------------------------------------------------
class _LampBodyPainter extends CustomPainter {
  _LampBodyPainter({
    required this.intensity,
    required this.pull,
    required this.size,
  });

  final double intensity;
  final double pull;
  final Size size;

  @override
  void paint(Canvas canvas, Size canvasSize) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;

    final shadeTop = h * 0.115;
    final rimY = h * _BeamPainter.rimYRatio; // 0.215
    final rimHalf = w * _BeamPainter.rimHalfRatio; // 0.21

    // ----------------------------- سلك التعليق -----------------------------
    canvas.drawLine(
      Offset(cx, 0),
      Offset(cx, shadeTop - 4),
      Paint()
        ..color = const Color(0xFF6B5B4A)
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      Offset(cx - 0.7, 0),
      Offset(cx - 0.7, shadeTop - 4),
      Paint()
        ..color = const Color(0xFF9A8C7A)
        ..strokeWidth = 0.7,
    );

    // قاعدة السقف
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx, 2), width: 24, height: 7),
        const Radius.circular(3),
      ),
      Paint()..color = const Color(0xFF33291F),
    );

    // وصلة السلك بالمظلة
    final connector = Path()
      ..moveTo(cx - 7, shadeTop - 6)
      ..lineTo(cx + 7, shadeTop - 6)
      ..lineTo(cx + 5, shadeTop + 2)
      ..lineTo(cx - 5, shadeTop + 2)
      ..close();
    canvas.drawPath(connector, Paint()..color = const Color(0xFF3E3327));

    // ----------------------------- المظلة (الشيد) -----------------------------
    final shadePath = Path()
      ..moveTo(cx - rimHalf, rimY)
      ..cubicTo(
        cx - rimHalf * 0.92,
        shadeTop + (rimY - shadeTop) * 0.24,
        cx - rimHalf * 0.45,
        shadeTop,
        cx,
        shadeTop,
      )
      ..cubicTo(
        cx + rimHalf * 0.45,
        shadeTop,
        cx + rimHalf * 0.92,
        shadeTop + (rimY - shadeTop) * 0.24,
        cx + rimHalf,
        rimY,
      )
      ..close();

    canvas.drawPath(
      shadePath,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF3A2F26), Color(0xFF1C1611), Color(0xFF0C0907)],
          stops: [0.0, 0.55, 1.0],
        ).createShader(
          Rect.fromLTRB(cx - rimHalf, shadeTop, cx + rimHalf, rimY),
        ),
    );
    // حد خارجي رفيع
    canvas.drawPath(
      shadePath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.9
        ..color = const Color(0xFF57452F),
    );
    // لمعة على يسار المظلة
    canvas.drawPath(
      shadePath,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.06),
            Colors.transparent,
          ],
        ).createShader(Rect.fromLTRB(cx - rimHalf, shadeTop, cx, rimY)),
    );

    // ----------------------------- حلقة الفتحة المضيئة -----------------------------
    final rimRect = Rect.fromCenter(
      center: Offset(cx, rimY),
      width: rimHalf * 2,
      height: h * 0.045,
    );

    // الفتحة الداخلية
    canvas.drawOval(
      rimRect.deflate(1.2),
      Paint()
        ..shader = RadialGradient(
          colors: intensity > 0.05
              ? [
                  const Color(0xFFFFF6E0),
                  const Color(0xFFFFD489),
                  const Color(0xFFE8A33D),
                ]
              : [const Color(0xFF2A241D), const Color(0xFF17120E)],
          stops: const [0.0, 0.55, 1.0],
        ).createShader(rimRect),
    );

    // إطار الحلقة الذهبي
    canvas.drawOval(
      rimRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = intensity > 0.05
            ? Color.lerp(
                const Color(0xFF8A6A33), const Color(0xFFFFE0A8), intensity)!
            : const Color(0xFF4A3B2A),
    );

    if (intensity > 0.05) {
      canvas.drawOval(
        rimRect.inflate(3.5),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 7
          ..color = const Color(0xFFFFC462).withOpacity(0.25 * intensity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
      );
      // توهّج مركزي مكان اللمبة
      canvas.drawCircle(
        Offset(cx, rimY),
        w * 0.055,
        Paint()
          ..shader = RadialGradient(
            colors: [
              const Color(0xFFFFF7E4).withOpacity(0.95 * intensity),
              const Color(0x00FFD489),
            ],
          ).createShader(
              Rect.fromCircle(center: Offset(cx, rimY), radius: w * 0.055))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6)
          ..blendMode = BlendMode.plus,
      );
    }

    // ----------------------------- الخيط + الحبّة -----------------------------
    final cordX = cx + rimHalf * 0.52;
    final cordTop = rimY - 4;
    final cordLength = h * 0.10 + pull * h * 0.075; // يزيد مع السحب (مطاطية)
    final cordBottom = cordTop + cordLength;

    canvas.drawLine(
      Offset(cordX, cordTop),
      Offset(cordX, cordBottom),
      Paint()
        ..color = const Color(0xFF7A6752)
        ..strokeWidth = 1.5
        ..strokeCap = StrokeCap.round,
    );

    final beadRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
          center: Offset(cordX, cordBottom + 6), width: 6.5, height: 15),
      const Radius.circular(3.2),
    );
    canvas.drawRRect(
      beadRect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFD489), Color(0xFFC98F3A)],
        ).createShader(beadRect.outerRect),
    );
    if (intensity > 0.05) {
      canvas.drawRRect(
        beadRect.inflate(2),
        Paint()
          ..color = const Color(0xFFFFC462).withOpacity(0.28 * intensity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _LampBodyPainter old) =>
      old.intensity != intensity || old.pull != pull || old.size != size;
}

// ============================================================================
//  LampAmbience: تعتيم الشاشة عند إطفاء المصباح مع إبقاء النصوص واضحة
//  الاستخدام: لفّ محتوى الشاشة بهذا الودجت ثم تمرير حالة المصباح.
// ============================================================================
class LampAmbience extends StatelessWidget {
  const LampAmbience({
    super.key,
    required this.isOn,
    required this.child,
    this.offOpacity = 0.42,
  });

  final bool isOn;
  final Widget child;
  final double offOpacity;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        child,
        // طبقة تعتيم دافئة تظهر عند الانطفاء فقط
        IgnorePointer(
          child: AnimatedOpacity(
            duration: const Duration(milliseconds: 650),
            curve: Curves.easeInOut,
            opacity: isOn ? 0 : offOpacity,
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  radius: 1.1,
                  colors: [Color(0xCC000000), Color(0xFF000000)],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
