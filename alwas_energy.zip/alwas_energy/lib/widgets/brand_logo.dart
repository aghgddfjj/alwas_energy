import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';

/// ============================================================================
///  شعار "الوس" — مونوجرام ذهبي داخل مربع دائري الزوايا مع إطار متدرّج وتوهّج
///  مرسوم بالكامل بـ Widgets (بدون صورة) لذلك يبقى حاداً على كل الشاشات.
/// ============================================================================
class BrandLogo extends StatelessWidget {
  const BrandLogo({
    super.key,
    this.size = 46,
    this.glow = true,
    this.showFrame = true,
  });

  final double size;
  final bool glow;
  final bool showFrame;

  @override
  Widget build(BuildContext context) {
    final inner = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.30),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF231A12), Color(0xFF0D0A07)],
        ),
      ),
      alignment: Alignment.center,
      child: ShaderMask(
        blendMode: BlendMode.srcIn,
        shaderCallback: (rect) => AppColors.goldGradient.createShader(rect),
        child: Text(
          'الوس',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: size * 0.30,
            height: 1.05,
            fontWeight: FontWeight.w800,
            color: Colors.white,
          ),
        ),
      ),
    );

    Widget framed = Container(
      padding: const EdgeInsets.all(1.4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.30 + 1.4),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFD489), Color(0xFF8A6A33), Color(0xFFE8A33D)],
        ),
      ),
      child: inner,
    );

    if (!showFrame) {
      framed = inner;
    }

    if (!glow) return framed;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.34),
        boxShadow: [
          BoxShadow(
            color: AppColors.gold.withOpacity(0.28),
            blurRadius: 18,
            spreadRadius: 1,
          ),
        ],
      ),
      child: framed,
    );
  }
}

/// صورة رمزية ذهبية (تُستخدم في الترويسة والقائمة الجانبية)
class GoldAvatar extends StatelessWidget {
  const GoldAvatar(
      {super.key, this.size = 42, this.icon = Icons.person_rounded});

  final double size;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            AppColors.goldLight.withOpacity(0.95),
            AppColors.gold.withOpacity(0.75),
            AppColors.goldDark.withOpacity(0.9),
          ],
          stops: const [0.0, 0.6, 1.0],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.gold.withOpacity(0.35),
            blurRadius: 14,
            spreadRadius: 0.5,
          ),
        ],
        border:
            Border.all(color: AppColors.goldLight.withOpacity(0.7), width: 1.2),
      ),
      child: Icon(icon, size: size * 0.55, color: const Color(0xFF2A1B08)),
    );
  }
}
