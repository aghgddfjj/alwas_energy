import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../data/models/models.dart';

/// ============================================================================
///  الرسوم البيانية — مرسومة بـ CustomPainter (بدون مكتبات خارجية)
///  1) BarWaveChart   : أعمدة ذهبية + منحنى أبيض ناعم (ملخص الفواتير)
///  2) LineAreaChart  : منحنى الاستهلاك مع تعبئة متدرّجة + شبكة ومحاور
///  3) MiniSparkline  : موجة صغيرة داخل بطاقات الإحصاء
///  4) RingProgress   : حلقة تقدّم ذهبية (السقف الشهري 36%)
///  5) BatteryGlyph   : رسم عدّاد/بطارية مع برق (صفحة الدفع)
/// ============================================================================

// ---------------------------------------------------------------------------
//  1) أعمدة + منحنى
// ---------------------------------------------------------------------------
class BarWaveChart extends StatelessWidget {
  const BarWaveChart({
    super.key,
    required this.values,
    this.height = 120,
    this.showCurve = true,
    this.padding = const EdgeInsets.symmetric(horizontal: 6),
  });

  final List<double> values;
  final double height;
  final bool showCurve;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _BarWavePainter(values: values, showCurve: showCurve),
        child: Padding(padding: padding, child: const SizedBox.expand()),
      ),
    );
  }
}

class _BarWavePainter extends CustomPainter {
  _BarWavePainter({required this.values, required this.showCurve});

  final List<double> values;
  final bool showCurve;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty) return;
    final maxValue = values.reduce(math.max);
    final n = values.length;
    final slot = size.width / n;
    final barWidth = math.min(slot * 0.34, 22.0);
    final usableHeight = size.height * 0.78;
    final baseY = size.height;

    final barPath = Path();
    final centers = <Offset>[];

    for (var i = 0; i < n; i++) {
      final cx = slot * i + slot / 2;
      final h = (values[i] / maxValue) * usableHeight;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - barWidth / 2, baseY - h, barWidth, h),
        const Radius.circular(5),
      );
      barPath.addRRect(rect);
      centers.add(Offset(cx, baseY - h - 8));
    }

    // توهّج خفيف أسفل الأعمدة
    canvas.drawPath(
      barPath,
      Paint()
        ..color = AppColors.gold.withOpacity(0.35)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
    );

    // الأعمدة بتدرّج ذهبي
    canvas.drawPath(
      barPath,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFD489), Color(0xFFE8A33D), Color(0xFF8A5A18)],
          stops: [0.0, 0.55, 1.0],
        ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    // المنحنى الأبيض الناعم
    if (showCurve && centers.length > 1) {
      final path = _smoothPath(centers);
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 5
          ..color = Colors.white.withOpacity(0.10)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.8
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round
          ..shader = const LinearGradient(
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
            colors: [Color(0xFFFFFFFF), Color(0xFFE9E2D6)],
          ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
      );
    }
  }

  Path _smoothPath(List<Offset> points) {
    if (points.length < 2) return Path();
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (var i = 0; i < points.length - 1; i++) {
      final p0 = i == 0 ? points[i] : points[i - 1];
      final p1 = points[i];
      final p2 = points[i + 1];
      final p3 = i + 2 < points.length ? points[i + 2] : p2;
      final c1 =
          Offset(p1.dx + (p2.dx - p0.dx) / 6, p1.dy + (p2.dy - p0.dy) / 6);
      final c2 =
          Offset(p2.dx - (p3.dx - p1.dx) / 6, p2.dy - (p3.dy - p1.dy) / 6);
      path.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, p2.dx, p2.dy);
    }
    return path;
  }

  @override
  bool shouldRepaint(covariant _BarWavePainter old) =>
      old.values != values || old.showCurve != showCurve;
}

// ---------------------------------------------------------------------------
//  2) منحنى الاستهلاك
// ---------------------------------------------------------------------------
class LineAreaChart extends StatelessWidget {
  const LineAreaChart({
    super.key,
    required this.current,
    required this.previous,
    this.height = 190,
    this.yTicks = const [0, 2, 4, 7],
    this.yUnit = '',
  });

  final List<ConsumptionPoint> current;
  final List<ConsumptionPoint> previous;
  final double height;
  final List<double> yTicks;
  final String yUnit;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _LineAreaPainter(
          current: current,
          previous: previous,
          yTicks: yTicks,
          yUnit: yUnit,
        ),
      ),
    );
  }
}

class _LineAreaPainter extends CustomPainter {
  _LineAreaPainter({
    required this.current,
    required this.previous,
    required this.yTicks,
    required this.yUnit,
  });

  final List<ConsumptionPoint> current;
  final List<ConsumptionPoint> previous;
  final List<double> yTicks;
  final String yUnit;

  @override
  void paint(Canvas canvas, Size size) {
    if (current.length < 2) return;

    const leftPad = 24.0;
    const bottomPad = 20.0;
    const topPad = 8.0;
    final chartW = size.width - leftPad - 4;
    final chartH = size.height - bottomPad - topPad;

    final maxValue = math.max(
      yTicks.isEmpty ? 1 : yTicks.reduce(math.max),
      current.map((e) => e.value).reduce(math.max),
    );
    final maxY = maxValue == 0 ? 1.0 : maxValue * 1.08;

    double xAt(int i) => leftPad + chartW * (i / (current.length - 1));
    double yAt(double v) => topPad + chartH - (v / maxY) * chartH;

    // ------------------------- شبكة أفقية + محور Y -------------------------
    final gridPaint = Paint()
      ..strokeWidth = 1
      ..color = AppColors.goldDivider.withOpacity(0.55);
    for (final tick in yTicks) {
      final y = yAt(tick);
      _dashedLine(canvas, Offset(leftPad, y), Offset(size.width, y), gridPaint);
      _text(
        canvas,
        tick.toStringAsFixed(tick % 1 == 0 ? 0 : 1),
        Offset(0, y - 6),
        const TextStyle(
          fontFamily: AppTheme.fontFamily,
          fontSize: 9.5,
          color: AppColors.textMuted,
        ),
      );
    }

    // ------------------------- محور X -------------------------
    for (var i = 0; i < current.length; i++) {
      _text(
        canvas,
        current[i].label,
        Offset(xAt(i) - 12, size.height - 14),
        const TextStyle(
          fontFamily: AppTheme.fontFamily,
          fontSize: 9.5,
          color: AppColors.textMuted,
        ),
        width: 24,
      );
    }

    // ------------------------- الفترة السابقة (رمادي) -------------------------
    if (previous.length == current.length) {
      final prevPts = <Offset>[
        for (var i = 0; i < previous.length; i++)
          Offset(xAt(i), yAt(previous[i].value)),
      ];
      canvas.drawPath(
        _smoothPath(prevPts),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4
          ..strokeCap = StrokeCap.round
          ..color = const Color(0xFFB9B2A6).withOpacity(0.85),
      );
    }

    // ------------------------- الفترة الحالية (ذهبي) -------------------------
    final pts = <Offset>[
      for (var i = 0; i < current.length; i++)
        Offset(xAt(i), yAt(current[i].value)),
    ];
    final curve = _smoothPath(pts);

    // تعبئة متدرّجة تحت المنحنى
    final fill = Path.from(curve)
      ..lineTo(pts.last.dx, topPad + chartH)
      ..lineTo(pts.first.dx, topPad + chartH)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = ui.Gradient.linear(
          const Offset(0, topPad),
          Offset(0, topPad + chartH),
          [
            AppColors.gold.withOpacity(0.42),
            AppColors.gold.withOpacity(0.05),
          ],
        ),
    );

    // ظل + الخط
    canvas.drawPath(
      curve,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..color = AppColors.gold.withOpacity(0.20)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawPath(
      curve,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..shader = const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [Color(0xFFFFD489), Color(0xFFE8A33D)],
        ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );
  }

  void _dashedLine(Canvas canvas, Offset from, Offset to, Paint paint) {
    const dash = 4.0;
    const gap = 4.0;
    var x = from.dx;
    while (x < to.dx) {
      canvas.drawLine(Offset(x, from.dy),
          Offset(math.min(x + dash, to.dx), from.dy), paint);
      x += dash + gap;
    }
  }

  void _text(Canvas canvas, String text, Offset offset, TextStyle style,
      {double? width}) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    )..layout(minWidth: width ?? 0, maxWidth: width ?? double.infinity);
    tp.paint(canvas, offset);
  }

  Path _smoothPath(List<Offset> points) {
    if (points.length < 2) return Path();
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (var i = 0; i < points.length - 1; i++) {
      final p0 = i == 0 ? points[i] : points[i - 1];
      final p1 = points[i];
      final p2 = points[i + 1];
      final p3 = i + 2 < points.length ? points[i + 2] : p2;
      final c1 =
          Offset(p1.dx + (p2.dx - p0.dx) / 6, p1.dy + (p2.dy - p0.dy) / 6);
      final c2 =
          Offset(p2.dx - (p3.dx - p1.dx) / 6, p2.dy - (p3.dy - p1.dy) / 6);
      path.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, p2.dx, p2.dy);
    }
    return path;
  }

  @override
  bool shouldRepaint(covariant _LineAreaPainter old) =>
      old.current != current || old.previous != previous;
}

// ---------------------------------------------------------------------------
//  3) موجة صغيرة
// ---------------------------------------------------------------------------
class MiniSparkline extends StatelessWidget {
  const MiniSparkline({
    super.key,
    required this.values,
    this.color = Colors.white,
    this.height = 26,
    this.strokeWidth = 1.6,
  });

  final List<double> values;
  final Color color;
  final double height;
  final double strokeWidth;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _SparkPainter(
            values: values, color: color, strokeWidth: strokeWidth),
      ),
    );
  }
}

class _SparkPainter extends CustomPainter {
  _SparkPainter(
      {required this.values, required this.color, required this.strokeWidth});

  final List<double> values;
  final Color color;
  final double strokeWidth;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2) return;
    final maxV = values.reduce(math.max);
    final minV = values.reduce(math.min);
    final range = (maxV - minV) == 0 ? 1.0 : (maxV - minV);
    final pts = <Offset>[];
    for (var i = 0; i < values.length; i++) {
      final x = size.width * (i / (values.length - 1));
      final y =
          size.height - 3 - ((values[i] - minV) / range) * (size.height - 8);
      pts.add(Offset(x, y));
    }
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 0; i < pts.length - 1; i++) {
      final mid = Offset(
          (pts[i].dx + pts[i + 1].dx) / 2, (pts[i].dy + pts[i + 1].dy) / 2);
      path.quadraticBezierTo(pts[i].dx, pts[i].dy, mid.dx, mid.dy);
    }
    path.lineTo(pts.last.dx, pts.last.dy);
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round
        ..color = color.withOpacity(0.9),
    );
  }

  @override
  bool shouldRepaint(covariant _SparkPainter old) => old.values != values;
}

// ---------------------------------------------------------------------------
//  4) حلقة التقدّم
// ---------------------------------------------------------------------------
class RingProgress extends StatelessWidget {
  const RingProgress({
    super.key,
    required this.value,
    this.size = 150,
    this.strokeWidth = 10,
    this.center,
  });

  final double value; // 0..1
  final double size;
  final double strokeWidth;
  final Widget? center;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RingPainter(value: value, strokeWidth: strokeWidth),
        child: Center(child: center),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter({required this.value, required this.strokeWidth});

  final double value;
  final double strokeWidth;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromCircle(
      center: Offset(size.width / 2, size.height / 2),
      radius: (size.width - strokeWidth) / 2,
    );
    // المسار الخلفي
    canvas.drawArc(
      rect,
      0,
      math.pi * 2,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xFF241D16),
    );
    // التقدّم
    const start = -math.pi / 2;
    final sweep = (value.clamp(0.0, 1.0)) * math.pi * 1.6;
    canvas.drawArc(
      rect,
      start,
      sweep,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFD489), Color(0xFFE8A33D)],
        ).createShader(rect),
    );
    // نقطة النهاية المضيئة
    final endAngle = start + sweep;
    final endPoint = Offset(
      rect.center.dx + rect.width / 2 * math.cos(endAngle),
      rect.center.dy + rect.width / 2 * math.sin(endAngle),
    );
    canvas.drawCircle(
      endPoint,
      strokeWidth * 0.42,
      Paint()
        ..color = const Color(0xFFFFE7B8)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
    );
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.value != value;
}

// ---------------------------------------------------------------------------
//  5) رسم البطارية + البرق (شاشة الدفع)
// ---------------------------------------------------------------------------
class BatteryGlyph extends StatelessWidget {
  const BatteryGlyph({super.key, this.size = 74, this.level = 0.62});

  final double size;
  final double level;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size * 0.62,
      height: size,
      child: CustomPaint(painter: _BatteryPainter(level: level)),
    );
  }
}

class _BatteryPainter extends CustomPainter {
  _BatteryPainter({required this.level});
  final double level;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final nubH = h * 0.055;

    // القطب العلوي
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
            center: Offset(w / 2, nubH * 0.6), width: w * 0.34, height: nubH),
        const Radius.circular(2),
      ),
      Paint()..color = const Color(0xFF5A4526),
    );

    final bodyRect = Rect.fromLTWH(0, nubH, w, h - nubH);
    final bodyRRect =
        RRect.fromRectAndRadius(bodyRect, Radius.circular(w * 0.22));

    // جسم البطارية
    canvas.drawRRect(
      bodyRRect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF241C14), Color(0xFF0F0B08)],
        ).createShader(bodyRect),
    );

    // مستوى الطاقة (من الأسفل)
    final inner = Rect.fromLTWH(
      bodyRect.left + 3,
      bodyRect.bottom - (bodyRect.height - 6) * level.clamp(0.05, 1.0) - 3,
      bodyRect.width - 6,
      (bodyRect.height - 6) * level.clamp(0.05, 1.0),
    );
    canvas.save();
    canvas.clipRRect(
      RRect.fromRectAndRadius(bodyRect.deflate(3), Radius.circular(w * 0.18)),
    );
    canvas.drawRect(
      inner,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFD489), Color(0xFFC98A2A), Color(0xFF8A5A18)],
        ).createShader(bodyRect),
    );
    canvas.restore();

    // فواصل الخلايا
    for (var i = 1; i < 5; i++) {
      final y = bodyRect.top + bodyRect.height * (i / 5);
      canvas.drawLine(
        Offset(bodyRect.left + 2, y),
        Offset(bodyRect.right - 2, y),
        Paint()
          ..color = Colors.black.withOpacity(0.35)
          ..strokeWidth = 1,
      );
    }

    // الإطار المعدني
    canvas.drawRRect(
      bodyRRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = const Color(0xFF6B5230),
    );

    // لمعة زجاجية
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(bodyRect.left + 4, bodyRect.top + 4, w * 0.22,
            bodyRect.height * 0.55),
        Radius.circular(w * 0.1),
      ),
      Paint()..color = Colors.white.withOpacity(0.06),
    );

    // البرق
    final cy = bodyRect.center.dy;
    final bolt = Path()
      ..moveTo(w * 0.60, cy - h * 0.16)
      ..lineTo(w * 0.32, cy + h * 0.02)
      ..lineTo(w * 0.50, cy + h * 0.02)
      ..lineTo(w * 0.42, cy + h * 0.18)
      ..lineTo(w * 0.70, cy - h * 0.01)
      ..lineTo(w * 0.52, cy - h * 0.01)
      ..close();
    canvas.drawPath(
      bolt,
      Paint()
        ..color = const Color(0xFFFFF4DC)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
    canvas.drawPath(bolt, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant _BatteryPainter old) => old.level != level;
}
