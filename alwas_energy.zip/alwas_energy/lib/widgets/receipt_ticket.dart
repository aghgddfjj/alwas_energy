import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/formatters.dart';
import '../data/models/models.dart';
import 'app_headers.dart';
import 'gold_widgets.dart';

/// ============================================================================
///  بطاقة الإيصال الرقمي (شكل تذكرة بشق سفلي + QR + باركود)
///  كل عنصر داخل هذا الودجت يُرسم من بيانات ReceiptModel الحقيقية.
/// ============================================================================
class ReceiptTicket extends StatelessWidget {
  const ReceiptTicket({super.key, required this.receipt});

  final ReceiptModel receipt;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final arabic = s.isArabic;

    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF1D1712), Color(0xFF120E0B)],
            ),
            borderRadius: const BorderRadius.vertical(
                top: Radius.circular(AppTheme.radiusCard)),
            border: Border.all(color: AppColors.goldBorder),
          ),
          child: Column(
            children: [
              // الشريط الذهبي العلوي
              const Padding(
                padding: EdgeInsets.fromLTRB(14, 12, 14, 0),
                child: GoldTopBar(height: 11),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
                child: Column(
                  children: [
                    // العنوان + شارة الاعتماد
                    Row(
                      children: [
                        GoldPill(
                          text: s.certified,
                          color: AppColors.success,
                          icon: Icons.verified_rounded,
                          filled: true,
                        ),
                        const Spacer(),
                        Text(
                          s.digitalReceipt,
                          style: const TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 15.5,
                            fontWeight: FontWeight.w700,
                            color: AppColors.goldLight,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const GoldDivider(opacity: 0.8),
                    const SizedBox(height: 4),

                    // بيانات الإيصال
                    InfoRow(
                        label: s.receiptNumber, value: receipt.receiptNumber),
                    InfoRow(
                        label: s.subscriberName, value: receipt.subscriberName),
                    InfoRow(
                        label: s.accountNumber, value: receipt.accountNumber),
                    InfoRow(
                      label: s.chargedAmount,
                      value: Fmt.currency(receipt.amount, s.currency,
                          arabic: arabic),
                      valueColor: AppColors.gold,
                    ),
                    InfoRow(
                      label: s.energyAddedLabel,
                      value: '${Fmt.oneDecimal(receipt.kwh)} ${s.kwh}',
                    ),
                    InfoRow(
                      label: s.balanceAfter,
                      value: Fmt.currency(receipt.balanceAfter, s.currency,
                          arabic: arabic),
                    ),
                    InfoRow(
                      label: s.paymentMethod,
                      value: receipt.methodName.resolve(arabic: arabic),
                    ),
                    InfoRow(
                        label: s.dateAndTime,
                        value: Fmt.dateTime(receipt.dateTime)),

                    const SizedBox(height: 10),
                    const GoldDivider(opacity: 0.8),
                    const SizedBox(height: 12),

                    // QR + باركود
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: AppColors.gold.withOpacity(0.45)),
                            color: Colors.white,
                          ),
                          child: QrImageView(
                            data: receipt.receiptNumber,
                            size: 46,
                            version: QrVersions.auto,
                            padding: EdgeInsets.zero,
                            eyeStyle: const QrEyeStyle(
                              eyeShape: QrEyeShape.square,
                              color: Color(0xFF120E0B),
                            ),
                            dataModuleStyle: const QrDataModuleStyle(
                              dataModuleShape: QrDataModuleShape.square,
                              color: Color(0xFF120E0B),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: SizedBox(
                            height: 44,
                            child: CustomPaint(
                              painter:
                                  _BarcodePainter(seed: receipt.receiptNumber),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // الشق السفلي (شكل تذكرة ممزقة)
        SizedBox(
          height: 9,
          child: CustomPaint(
            painter: _SawtoothPainter(),
            child: const SizedBox.expand(),
          ),
        ),
      ],
    );
  }
}

/// ---------------------------------------------------------------------------
///  باركود مرسوم بشكل حتمي من رقم الإيصال
///  (للطباعة الرسمية استخدم حزمة barcode_widget لتوليد Code128 حقيقي)
/// ---------------------------------------------------------------------------
class _BarcodePainter extends CustomPainter {
  _BarcodePainter({required this.seed});
  final String seed;

  @override
  void paint(Canvas canvas, Size size) {
    final hash = seed.codeUnits.fold<int>(7, (a, b) => (a * 31 + b) % 100000);
    final rnd = math.Random(hash);
    final paint = Paint()..color = const Color(0xFFEDE6DB);
    var x = 0.0;
    while (x < size.width) {
      final w = 1.0 + rnd.nextInt(3);
      final gap = 1.0 + rnd.nextInt(3);
      final isBar = rnd.nextBool();
      if (isBar) {
        canvas.drawRect(Rect.fromLTWH(x, 0, w, size.height), paint);
      }
      x += w + gap;
    }
  }

  @override
  bool shouldRepaint(covariant _BarcodePainter old) => old.seed != seed;
}

/// ---------------------------------------------------------------------------
///  الحافة السفلية المتعرجة
/// ---------------------------------------------------------------------------
class _SawtoothPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFF120E0B);
    final path = Path()..moveTo(0, 0);
    const step = 12.0;
    var x = 0.0;
    var up = false;
    while (x < size.width) {
      path.lineTo(x + step / 2, up ? 0 : size.height);
      x += step;
      up = !up;
    }
    path
      ..lineTo(size.width, 0)
      ..close();
    canvas.drawPath(path, paint);
    // خط ذهبي رفيع يحاكي حد الشق
    final strokePath = Path()..moveTo(0, 0);
    x = 0;
    up = false;
    while (x < size.width) {
      strokePath.lineTo(x + step / 2, up ? 0 : size.height);
      x += step;
      up = !up;
    }
    canvas.drawPath(
      strokePath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = AppColors.goldBorder,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
