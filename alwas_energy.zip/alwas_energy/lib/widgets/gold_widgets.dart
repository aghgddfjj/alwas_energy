import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';

/// ============================================================================
///  مكتبة المكوّنات الذهبية المشتركة (Design System)
///  كل الشاشات تستخدم هذه المكوّنات لضمان تطابق التصميم في كل الصفحات.
/// ============================================================================

// ---------------------------------------------------------------------------
//  بطاقة ذهبية عامة
// ---------------------------------------------------------------------------
class GoldCard extends StatelessWidget {
  const GoldCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.onTap,
    this.radius = AppTheme.radiusCard,
    this.borderColor,
    this.gradient,
    this.glow = false,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final VoidCallback? onTap;
  final double radius;
  final Color? borderColor;
  final Gradient? gradient;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    final content = Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        gradient: gradient ?? AppColors.cardGradient,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: borderColor ?? AppColors.goldBorder,
          width: 1,
        ),
        boxShadow: _cardShadows(glow),
      ),
      child: child,
    );

    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(radius),
        splashColor: AppColors.gold.withOpacity(0.08),
        highlightColor: AppColors.gold.withOpacity(0.04),
        child: content,
      ),
    );
  }

  List<BoxShadow> _cardShadows(bool glow) {
    if (!glow) return AppColors.cardShadow;
    return [
      ...AppColors.cardShadow,
      BoxShadow(
        color: AppColors.gold.withOpacity(0.18),
        blurRadius: 22,
        spreadRadius: 1,
      ),
    ];
  }
}

// ---------------------------------------------------------------------------
//  زر ذهبي أساسي (تدرّج + توهّج + مؤشر تحميل)
// ---------------------------------------------------------------------------
class GoldButton extends StatelessWidget {
  const GoldButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.loading = false,
    this.height = 52,
    this.expand = true,
    this.fontSize = 16,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final double height;
  final bool expand;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    final child = AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      height: height,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 22),
      decoration: BoxDecoration(
        gradient: enabled
            ? AppColors.goldGradient
            : LinearGradient(
                colors: [
                  AppColors.gold.withOpacity(0.35),
                  AppColors.goldDark.withOpacity(0.35),
                ],
              ),
        borderRadius: BorderRadius.circular(height / 2),
        boxShadow: enabled
            ? [
                BoxShadow(
                  color: AppColors.gold.withOpacity(0.32),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ]
            : null,
      ),
      child: loading
          ? const SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2.4,
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF2A1B08)),
              ),
            )
          : Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 18, color: const Color(0xFF2A1B08)),
                  const SizedBox(width: 8),
                ],
                Text(
                  label,
                  style: TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: fontSize,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF2A1B08),
                  ),
                ),
              ],
            ),
    );

    return SizedBox(
      width: expand ? double.infinity : null,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: enabled ? onPressed : null,
          borderRadius: BorderRadius.circular(height / 2),
          child: child,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
//  زر ثانوي بإطار ذهبي رفيع
// ---------------------------------------------------------------------------
class GoldOutlineButton extends StatelessWidget {
  const GoldOutlineButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.height = 48,
    this.expand = false,
    this.color,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final double height;
  final bool expand;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final fg = color ?? AppColors.goldLight;
    return SizedBox(
      width: expand ? double.infinity : null,
      height: height,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(height / 2),
          splashColor: AppColors.gold.withOpacity(0.10),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: AppColors.cardAlt.withOpacity(0.75),
              borderRadius: BorderRadius.circular(height / 2),
              border: Border.all(color: AppColors.goldBorder, width: 1),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 16, color: fg),
                  const SizedBox(width: 6),
                ],
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      color: fg,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
//  حقل إدخال ذهبي
// ---------------------------------------------------------------------------
class GoldTextField extends StatefulWidget {
  const GoldTextField({
    super.key,
    this.controller,
    this.hint,
    this.label,
    this.icon,
    this.obscure = false,
    this.keyboardType,
    this.textInputAction,
    this.onChanged,
    this.onSubmitted,
    this.validator,
    this.enabled = true,
    this.maxLines = 1,
    this.autofocus = false,
  });

  final TextEditingController? controller;
  final String? hint;
  final String? label;
  final IconData? icon;
  final bool obscure;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final String? Function(String?)? validator;
  final bool enabled;
  final int maxLines;
  final bool autofocus;

  @override
  State<GoldTextField> createState() => _GoldTextFieldState();
}

class _GoldTextFieldState extends State<GoldTextField> {
  bool _obscured = true;

  @override
  void initState() {
    super.initState();
    _obscured = widget.obscure;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.label != null) ...[
          Padding(
            padding: const EdgeInsets.only(right: 6, left: 6, bottom: 6),
            child: Text(
              widget.label!,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: AppColors.textSecondary,
              ),
            ),
          ),
        ],
        TextFormField(
          controller: widget.controller,
          obscureText: widget.obscure ? _obscured : false,
          enabled: widget.enabled,
          maxLines: widget.obscure ? 1 : widget.maxLines,
          autofocus: widget.autofocus,
          keyboardType: widget.keyboardType,
          textInputAction: widget.textInputAction,
          onChanged: widget.onChanged,
          onFieldSubmitted: widget.onSubmitted,
          validator: widget.validator,
          style: const TextStyle(
            fontFamily: AppTheme.fontFamily,
            fontSize: 15,
            color: AppColors.textPrimary,
          ),
          cursorColor: AppColors.gold,
          decoration: InputDecoration(
            hintText: widget.hint,
            prefixIcon: widget.icon == null
                ? null
                : Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Icon(widget.icon, size: 19, color: AppColors.gold),
                  ),
            prefixIconConstraints:
                const BoxConstraints(minWidth: 44, minHeight: 24),
            suffixIcon: widget.obscure
                ? IconButton(
                    onPressed: () => setState(() => _obscured = !_obscured),
                    icon: Icon(
                      _obscured
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                      size: 19,
                      color: AppColors.textSecondary,
                    ),
                    tooltip: _obscured ? 'إظهار' : 'إخفاء',
                  )
                : null,
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
//  كبسولة حالة (معتمد / مفتوحة / مكتمل ...)
// ---------------------------------------------------------------------------
class GoldPill extends StatelessWidget {
  const GoldPill({
    super.key,
    required this.text,
    this.color = AppColors.success,
    this.icon,
    this.filled = false,
  });

  final String text;
  final Color color;
  final IconData? icon;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: filled ? color.withOpacity(0.18) : color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.55), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 4),
          ],
          Text(
            text,
            style: TextStyle(
              fontFamily: AppTheme.fontFamily,
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
//  مربّع أيقونة ذهبي (يُستخدم في الأزرار والتذاكر)
// ---------------------------------------------------------------------------
class GoldIconBox extends StatelessWidget {
  const GoldIconBox({
    super.key,
    required this.icon,
    this.size = 40,
    this.color = AppColors.goldLight,
    this.radius = 12,
    this.filled = true,
  });

  final IconData icon;
  final double size;
  final Color color;
  final double radius;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: filled
            ? LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  color.withOpacity(0.20),
                  color.withOpacity(0.06),
                ],
              )
            : null,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: color.withOpacity(0.35), width: 1),
      ),
      child: Icon(icon, size: size * 0.48, color: color),
    );
  }
}

// ---------------------------------------------------------------------------
//  عنوان قسم مع إجراء اختياري
// ---------------------------------------------------------------------------
class SectionHeader extends StatelessWidget {
  const SectionHeader({
    super.key,
    required this.title,
    this.actionLabel,
    this.onAction,
    this.actionIcon,
    this.padding = EdgeInsets.zero,
  });

  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;
  final IconData? actionIcon;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          if (actionLabel != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(
                foregroundColor: AppColors.gold,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                minimumSize: const Size(0, 32),
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              child: Row(
                children: [
                  if (actionIcon != null) ...[
                    Icon(actionIcon, size: 15, color: AppColors.gold),
                    const SizedBox(width: 4),
                  ],
                  Text(
                    actionLabel!,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: AppColors.gold,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
//  صف بيانات (عنوان : قيمة) — يُستخدم في الإيصال وبيانات التسديد
// ---------------------------------------------------------------------------
class InfoRow extends StatelessWidget {
  const InfoRow({
    super.key,
    required this.label,
    required this.value,
    this.valueColor = AppColors.textPrimary,
    this.bold = true,
    this.valueStyle,
    this.labelStyle,
    this.padding = const EdgeInsets.symmetric(vertical: 7),
    this.trailing,
  });

  final String label;
  final String value;
  final Color valueColor;
  final bool bold;
  final TextStyle? valueStyle;
  final TextStyle? labelStyle;
  final EdgeInsetsGeometry padding;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: labelStyle ??
                  const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 13,
                    color: AppColors.textSecondary,
                  ),
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            flex: 6,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Flexible(
                  child: Text(
                    value,
                    textAlign: TextAlign.start,
                    style: valueStyle ??
                        TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          fontSize: 13.5,
                          fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
                          color: valueColor,
                        ),
                  ),
                ),
                if (trailing != null) ...[
                  const SizedBox(width: 6),
                  trailing!,
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
//  خانة نسخ (رقم المحفظة / رقم العداد)
// ---------------------------------------------------------------------------
class CopyField extends StatelessWidget {
  const CopyField({
    super.key,
    required this.label,
    required this.value,
    required this.onCopy,
    this.copyLabel,
  });

  final String label;
  final String value;
  final VoidCallback onCopy;
  final String? copyLabel;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.field,
        borderRadius: BorderRadius.circular(AppTheme.radiusField),
        border: Border.all(color: AppColors.goldBorder),
      ),
      child: Row(
        children: [
          // زر النسخ
          InkWell(
            onTap: () {
              Clipboard.setData(ClipboardData(text: value));
              HapticFeedback.selectionClick();
              onCopy();
            },
            borderRadius: BorderRadius.circular(10),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.gold.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.goldBorder),
              ),
              child: Row(
                children: [
                  const Icon(Icons.copy_rounded,
                      size: 12, color: AppColors.goldLight),
                  const SizedBox(width: 4),
                  Text(
                    copyLabel ?? 'نسخ',
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.goldLight,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  textAlign: TextAlign.start,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 11,
                    color: AppColors.textMuted,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontFamily: AppTheme.numberFontFamily,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
//  فاصل ذهبي رفيع
// ---------------------------------------------------------------------------
class GoldDivider extends StatelessWidget {
  const GoldDivider({super.key, this.height = 1, this.opacity = 1});
  final double height;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.transparent,
            AppColors.goldBorder.withOpacity(opacity),
            Colors.transparent,
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
//  قائمة منسدلة ذهبية (اختيار العداد مثلاً)
// ---------------------------------------------------------------------------
class GoldDropdown<T> extends StatelessWidget {
  const GoldDropdown({
    super.key,
    required this.value,
    required this.items,
    required this.onChanged,
    required this.labelBuilder,
    this.icon,
  });

  final T value;
  final List<T> items;
  final ValueChanged<T?> onChanged;
  final String Function(T) labelBuilder;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: AppColors.field,
        borderRadius: BorderRadius.circular(AppTheme.radiusField),
        border: Border.all(color: AppColors.goldBorder),
      ),
      child: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, size: 18, color: AppColors.gold),
            const SizedBox(width: 8),
          ],
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<T>(
                value: value,
                isExpanded: true,
                dropdownColor: AppColors.cardAlt,
                borderRadius: BorderRadius.circular(16),
                icon: const Icon(Icons.expand_more_rounded,
                    color: AppColors.gold, size: 20),
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 14.5,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary,
                ),
                items: items
                    .map(
                      (e) => DropdownMenuItem<T>(
                        value: e,
                        child: Text(labelBuilder(e)),
                      ),
                    )
                    .toList(),
                onChanged: onChanged,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
