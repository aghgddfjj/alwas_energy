import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import 'charts.dart';
import 'gold_widgets.dart';

/// ============================================================================
///  بطاقة إحصاء صغيرة: عنوان + قيمة + وحدة + موجة صغيرة
/// ============================================================================
class StatCard extends StatelessWidget {
  const StatCard({
    super.key,
    required this.label,
    required this.value,
    this.unit,
    this.icon,
    this.sparkValues = const [3, 5, 4, 6, 5, 7, 6],
    this.onTap,
  });

  final String label;
  final String value;
  final String? unit;
  final IconData? icon;
  final List<double> sparkValues;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GoldCard(
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Spacer(),
              if (icon != null)
                Icon(icon, size: 13, color: AppColors.gold.withOpacity(0.9)),
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 11.5,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontFamily: AppTheme.numberFontFamily,
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                  height: 1.1,
                ),
              ),
              if (unit != null) ...[
                const SizedBox(width: 4),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    unit!,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 10.5,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 4),
          MiniSparkline(
              values: sparkValues, height: 22, color: AppColors.goldLight),
        ],
      ),
    );
  }
}

/// ============================================================================
///  شعار العدّاد الإيزومتري (زخرفي، مرسوم برمجياً)
/// ============================================================================
class MeterIsoGlyph extends StatelessWidget {
  const MeterIsoGlyph({super.key, this.size = 86, this.connected = true});

  final double size;
  final bool connected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _MeterIsoPainter(connected: connected),
      ),
    );
  }
}

class _MeterIsoPainter extends CustomPainter {
  _MeterIsoPainter({required this.connected});
  final bool connected;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;

    // ظل أرضي
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(cx, h * 0.90), width: w * 0.66, height: h * 0.10),
      Paint()
        ..color = Colors.black.withOpacity(0.45)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7),
    );

    final halfW = w * 0.33;
    final halfH = h * 0.15;
    final depth = h * 0.30;
    final topY = h * 0.30;

    // الوجه العلوي
    final topFace = Path()
      ..moveTo(cx, topY - halfH)
      ..lineTo(cx + halfW, topY)
      ..lineTo(cx, topY + halfH)
      ..lineTo(cx - halfW, topY)
      ..close();

    final rightFace = Path()
      ..moveTo(cx + halfW, topY)
      ..lineTo(cx, topY + halfH)
      ..lineTo(cx, topY + halfH + depth)
      ..lineTo(cx + halfW, topY + depth)
      ..close();

    final leftFace = Path()
      ..moveTo(cx - halfW, topY)
      ..lineTo(cx, topY + halfH)
      ..lineTo(cx, topY + halfH + depth)
      ..lineTo(cx - halfW, topY + depth)
      ..close();

    // الوجه الأمامي (تفاصيل العدّاد)
    canvas.drawPath(
      rightFace,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFD08F2C), Color(0xFF8A5A18)],
        ).createShader(Offset.zero & size),
    );
    canvas.drawPath(
      leftFace,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFA9701F), Color(0xFF5F3E10)],
        ).createShader(Offset.zero & size),
    );
    canvas.drawPath(
      topFace,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFE3AE), Color(0xFFFFC96B)],
        ).createShader(Offset.zero & size),
    );

    // شاشة صغيرة على الوجه الأيمن
    final screenRect = Path()
      ..moveTo(cx + halfW * 0.62, topY + depth * 0.28)
      ..lineTo(cx + halfW * 0.28, topY + halfH * 0.48 + depth * 0.28)
      ..lineTo(cx + halfW * 0.28, topY + halfH * 0.48 + depth * 0.58)
      ..lineTo(cx + halfW * 0.62, topY + depth * 0.58)
      ..close();
    canvas.drawPath(screenRect, Paint()..color = const Color(0xFF2A1B08));
    canvas.drawPath(
      screenRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8
        ..color = const Color(0xFFFFE7B8).withOpacity(0.75),
    );

    // خطوط سفلية على الوجه الأيمن
    for (var i = 0; i < 2; i++) {
      canvas.drawLine(
        Offset(cx + halfW * 0.90, topY + depth * (0.30 + i * 0.16)),
        Offset(
            cx + halfW * 0.62, topY + halfH * 0.20 + depth * (0.30 + i * 0.16)),
        Paint()
          ..color = const Color(0xFF4A2F0B).withOpacity(0.45)
          ..strokeWidth = 1.1,
      );
    }

    // مؤشر الحالة
    canvas.drawCircle(
      Offset(cx + halfW * 0.42, topY + halfH * 0.20),
      2.4,
      Paint()..color = connected ? AppColors.success : AppColors.danger,
    );

    // توهّج خفيف على الوجه العلوي
    canvas.drawPath(
      topFace,
      Paint()
        ..color = AppColors.goldLight.withOpacity(0.30)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
    );
  }

  @override
  bool shouldRepaint(covariant _MeterIsoPainter old) =>
      old.connected != connected;
}

/// ============================================================================
///  شارة "العداد متصل" مع نقطة نابضة
/// ============================================================================
class LiveBadge extends StatefulWidget {
  const LiveBadge(
      {super.key, required this.label, this.color = AppColors.success});

  final String label;
  final Color color;

  @override
  State<LiveBadge> createState() => _LiveBadgeState();
}

class _LiveBadgeState extends State<LiveBadge>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: widget.color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: widget.color.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _controller,
            builder: (context, _) => Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color,
                boxShadow: [
                  BoxShadow(
                    color: widget.color
                        .withOpacity(0.25 + 0.45 * _controller.value),
                    blurRadius: 6 + 4 * _controller.value,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 5),
          Text(
            widget.label,
            style: TextStyle(
              fontFamily: AppTheme.fontFamily,
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              color: widget.color,
            ),
          ),
        ],
      ),
    );
  }
}

/// ============================================================================
///  شريحة أرقام العداد (1 0 0 0 0 0 1) — آخر خانة ذهبية
/// ============================================================================
class MeterDigits extends StatelessWidget {
  const MeterDigits({super.key, required this.number});

  final String number;

  @override
  Widget build(BuildContext context) {
    final digits = number.split('');
    // الأرقام تُعرض من اليسار إلى اليمين دائماً (مثل شاشة العدّاد) حتى في الواجهة العربية
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          for (var i = 0; i < digits.length; i++)
            Padding(
              padding: const EdgeInsets.only(right: 5),
              child: _DigitCell(
                digit: digits[i],
                highlighted: i == digits.length - 1,
              ),
            ),
        ],
      ),
    );
  }
}

class _DigitCell extends StatelessWidget {
  const _DigitCell({required this.digit, required this.highlighted});

  final String digit;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 26,
      height: 30,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: highlighted ? AppColors.gold : AppColors.field,
        borderRadius: BorderRadius.circular(7),
        border: Border.all(
          color: highlighted ? AppColors.goldLight : AppColors.goldBorder,
        ),
        boxShadow: highlighted
            ? [
                BoxShadow(
                  color: AppColors.gold.withOpacity(0.35),
                  blurRadius: 10,
                ),
              ]
            : null,
      ),
      child: Text(
        digit,
        style: TextStyle(
          fontFamily: AppTheme.numberFontFamily,
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: highlighted ? const Color(0xFF2A1B08) : AppColors.textPrimary,
        ),
      ),
    );
  }
}

/// ============================================================================
///  دائرة اختيار طريقة الدفع (شعار ملون + اسم)
/// ============================================================================
class MethodTile extends StatelessWidget {
  const MethodTile({
    super.key,
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
    this.icon = Icons.account_balance_wallet_rounded,
  });

  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
        decoration: BoxDecoration(
          gradient: selected
              ? LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppColors.gold.withOpacity(0.22),
                    AppColors.gold.withOpacity(0.05),
                  ],
                )
              : const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF1B1510), Color(0xFF120E0B)],
                ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: selected ? AppColors.gold : AppColors.goldBorder,
            width: selected ? 1.4 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: AppColors.gold.withOpacity(0.18),
                    blurRadius: 16,
                  ),
                ]
              : null,
        ),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.35),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: Icon(icon, size: 21, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 12.5,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color:
                    selected ? AppColors.textPrimary : AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// نقطة عشوائية ثابتة مفيدة لتوليد أشكال زخرفية ثابتة
double pseudoRandom(int seed) => (math.sin(seed * 12.9898) * 43758.5453) % 1;
