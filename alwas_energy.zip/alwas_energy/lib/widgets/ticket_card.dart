import 'package:flutter/material.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/formatters.dart';
import '../data/models/models.dart';
import 'gold_widgets.dart';

/// ============================================================================
///  بطاقة تذكرة الدعم مع مسار الحالة (تم الاستلام ← قيد المعالجة ← تم الحل)
/// ============================================================================
class TicketCard extends StatelessWidget {
  const TicketCard({super.key, required this.ticket, this.onTap});

  final SupportTicket ticket;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final steps = [s.stepReceived, s.stepProcessing, s.stepDone];
    final isOpen = ticket.status == TicketStatus.open;

    return GoldCard(
      margin: const EdgeInsets.only(bottom: 12),
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
      child: Column(
        children: [
          // العنوان + الحالة
          Row(
            children: [
              GoldPill(
                text: isOpen ? s.statusOpen : s.statusResolved,
                color: isOpen ? AppColors.gold : AppColors.success,
                icon: isOpen
                    ? Icons.schedule_rounded
                    : Icons.check_circle_outline,
              ),
              const Spacer(),
              Flexible(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Flexible(
                      child: Text(
                        ticket.title.resolve(arabic: s.isArabic),
                        textAlign: TextAlign.right,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    const GoldIconBox(
                        icon: Icons.support_agent_rounded, size: 30, radius: 9),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              '${ticket.id} • ${Fmt.shortDate(ticket.date)}',
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 10.5,
                color: AppColors.textMuted,
              ),
            ),
          ),
          const SizedBox(height: 12),

          // مسار الحالة
          Row(
            children: [
              for (var i = 0; i < steps.length; i++)
                Expanded(
                  child: _TimelineStep(
                    label: steps[i],
                    state: i < ticket.reachedStep
                        ? _StepState.done
                        : (i == ticket.reachedStep
                            ? _StepState.current
                            : _StepState.pending),
                    isFirst: i == 0,
                    isLast: i == steps.length - 1,
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

enum _StepState { done, current, pending }

class _TimelineStep extends StatelessWidget {
  const _TimelineStep({
    required this.label,
    required this.state,
    required this.isFirst,
    required this.isLast,
  });

  final String label;
  final _StepState state;
  final bool isFirst;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final active = state != _StepState.pending;
    return Column(
      children: [
        SizedBox(
          height: 16,
          child: Row(
            children: [
              Expanded(
                child: Container(
                  height: 2,
                  color: isLast
                      ? Colors.transparent
                      : (state == _StepState.done || state == _StepState.current
                          ? AppColors.gold.withOpacity(0.75)
                          : AppColors.goldDivider),
                ),
              ),
              Container(
                width: state == _StepState.current ? 13 : 9,
                height: state == _StepState.current ? 13 : 9,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: active ? AppColors.gold : AppColors.cardAlt,
                  border: Border.all(
                    color: active ? AppColors.goldLight : AppColors.goldBorder,
                    width: 1.2,
                  ),
                  boxShadow: state == _StepState.current
                      ? [
                          BoxShadow(
                            color: AppColors.gold.withOpacity(0.65),
                            blurRadius: 10,
                          ),
                        ]
                      : null,
                ),
              ),
              Expanded(
                child: Container(
                  height: 2,
                  color: isFirst
                      ? Colors.transparent
                      : (state == _StepState.done
                          ? AppColors.gold.withOpacity(0.75)
                          : AppColors.goldDivider),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontFamily: AppTheme.fontFamily,
            fontSize: 10,
            fontWeight: active ? FontWeight.w600 : FontWeight.w400,
            color: active ? AppColors.goldLight : AppColors.textMuted,
          ),
        ),
      ],
    );
  }
}
