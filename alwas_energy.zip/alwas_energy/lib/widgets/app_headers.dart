import 'package:flutter/material.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import 'brand_logo.dart';

/// ============================================================================
///  ترويسة الصفحة الرئيسية: صورة المشترك + الترحيب + الإشعارات + الشعار
/// ============================================================================
class HomeHeader extends StatelessWidget {
  const HomeHeader({
    super.key,
    required this.greeting,
    required this.name,
    required this.onNotifications,
    this.unread = 0,
    this.onAvatarTap,
  });

  final String greeting;
  final String name;
  final VoidCallback onNotifications;
  final int unread;
  final VoidCallback? onAvatarTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        GestureDetector(onTap: onAvatarTap, child: const GoldAvatar(size: 44)),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                greeting,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 11.5,
                  color: AppColors.textSecondary,
                ),
              ),
              Text(
                name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ),
        _CircleIconButton(
          icon: Icons.notifications_none_rounded,
          onTap: onNotifications,
          badge: unread,
        ),
        const SizedBox(width: 8),
        const BrandLogo(size: 42),
      ],
    );
  }
}

/// ============================================================================
///  ترويسة الصفحات الفرعية: سهم رجوع + عنوان في الوسط
/// ============================================================================
class ScreenHeader extends StatelessWidget {
  const ScreenHeader({
    super.key,
    required this.title,
    this.onBack,
    this.action,
    this.subtitle,
  });

  final String title;
  final VoidCallback? onBack;
  final Widget? action;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _CircleIconButton(
          icon: Icons.arrow_forward_rounded,
          // في الواجهة العربية يكون زر الرجوع سهماً نحو اليمين
          flipForRtl: true,
          onTap: onBack ?? () => Navigator.of(context).maybePop(),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            children: [
              Text(
                title,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              if (subtitle != null)
                Text(
                  subtitle!,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 11,
                    color: AppColors.textMuted,
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        action ??
            const SizedBox(
              width: 38,
              height: 38,
            ),
      ],
    );
  }
}

class _CircleIconButton extends StatelessWidget {
  const _CircleIconButton({
    required this.icon,
    required this.onTap,
    this.badge = 0,
    this.flipForRtl = false,
  });

  final IconData icon;
  final VoidCallback onTap;
  final int badge;
  final bool flipForRtl;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF1E1811), Color(0xFF100C09)],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.goldBorder),
              ),
              child: flipForRtl &&
                      Directionality.of(context) == TextDirection.rtl
                  ? Transform.flip(
                      flipX: true,
                      child: Icon(icon, size: 18, color: AppColors.goldLight),
                    )
                  : Icon(icon, size: 18, color: AppColors.goldLight),
            ),
          ),
        ),
        if (badge > 0)
          Positioned(
            top: -2,
            right: -2,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
              constraints: const BoxConstraints(minWidth: 14),
              decoration: BoxDecoration(
                color: AppColors.danger,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.background, width: 1.4),
              ),
              child: Text(
                '$badge',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 8.5,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// ============================================================================
///  كبسولة التاريخ والوقت (الأربعاء، 28 أكتوبر • 6:58 ص)
/// ============================================================================
class DateChip extends StatelessWidget {
  const DateChip({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: AppColors.cardAlt.withOpacity(0.7),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.goldBorder),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.access_time_rounded,
                size: 13, color: AppColors.textSecondary),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 11.5,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ============================================================================
///  شريط علوي ذهبي (أعلى بطاقة الإيصال)
/// ============================================================================
class GoldTopBar extends StatelessWidget {
  const GoldTopBar(
      {super.key, this.height = 10, this.margin = EdgeInsets.zero});

  final double height;
  final EdgeInsetsGeometry margin;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      margin: margin,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            Color(0xFFB9741C),
            Color(0xFFFFD489),
            Color(0xFFE8A33D),
            Color(0xFFB9741C),
          ],
        ),
        borderRadius: BorderRadius.circular(height / 2),
        boxShadow: [
          BoxShadow(
            color: AppColors.gold.withOpacity(0.45),
            blurRadius: 14,
            offset: const Offset(0, 2),
          ),
        ],
      ),
    );
  }
}

/// ============================================================================
///  شعار اللغة (كرة أرضية + English)
/// ============================================================================
class LanguageChip extends StatelessWidget {
  const LanguageChip({super.key, required this.onTap, required this.label});

  final VoidCallback onTap;
  final String label;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: AppColors.cardAlt.withOpacity(0.85),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.goldBorder),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.language_rounded,
                size: 15, color: AppColors.goldLight),
          ],
        ),
      ),
    );
  }
}

/// ============================================================================
///  ملاحظة تجريبية صغيرة (لتوضيح أن البيانات غير حقيقية)
/// ============================================================================
class DemoBadge extends StatelessWidget {
  const DemoBadge({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.warning.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.warning.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.info_outline_rounded,
              size: 13, color: AppColors.warning),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              s.demoNotice,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 10.5,
                height: 1.5,
                color: AppColors.warning,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
