import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../screens/account/account_screen.dart';
import '../screens/notifications/notifications_screen.dart';
import '../screens/settings/settings_screen.dart';
import '../screens/support/support_screen.dart';
import '../state/energy_controller.dart';
import '../state/session_controller.dart';
import '../state/support_controller.dart';
import '../state/settings_controller.dart';
import '../widgets/brand_logo.dart';
import '../widgets/gold_widgets.dart';

/// ============================================================================
///  القائمة الجانبية (Drawer)
///  تظهر من اليمين في العربية: بيانات المشترك + العدادات + التنقل + اللغة
/// ============================================================================
class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final settings = context.watch<AppSettingsController>();
    final session = context.watch<SessionController>();
    final energy = context.watch<EnergyController>();
    final user = session.user;

    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.82,
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF17120D), AppColors.drawer],
          ),
          border: Border(
            left: BorderSide(color: AppColors.goldBorder, width: 1),
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // ------------------------- ترويسة المشترك -------------------------
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
                child: Row(
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        const GoldAvatar(size: 54),
                        Positioned(
                          bottom: -2,
                          left: -2,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: AppColors.cardAlt,
                              shape: BoxShape.circle,
                              border: Border.all(color: AppColors.goldBorder),
                            ),
                            child: const Icon(Icons.photo_camera_outlined,
                                size: 11, color: AppColors.goldLight),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user?.name ?? '—',
                            style: const TextStyle(
                              fontFamily: AppTheme.fontFamily,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '@${user?.username ?? ''}',
                            style: const TextStyle(
                              fontFamily: AppTheme.fontFamily,
                              fontSize: 12,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            s.changeAvatar,
                            style: const TextStyle(
                              fontFamily: AppTheme.fontFamily,
                              fontSize: 11,
                              color: AppColors.gold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // أرقام العدادات
              if (energy.meters.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Row(
                    children: [
                      for (var i = 0; i < energy.meters.length; i++) ...[
                        Expanded(
                          child: _MeterChip(
                            number: energy.meters[i].number,
                            active: i == energy.selectedMeterIndex,
                            onTap: () {
                              energy.selectMeter(i);
                              Navigator.of(context).pop();
                            },
                          ),
                        ),
                        if (i != energy.meters.length - 1)
                          const SizedBox(width: 8),
                      ],
                    ],
                  ),
                ),

              const SizedBox(height: 14),
              const GoldDivider(opacity: 0.7),
              const SizedBox(height: 6),

              // ------------------------- عناصر التنقل -------------------------
              Expanded(
                child: ListView(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  children: [
                    _DrawerItem(
                      icon: Icons.person_outline_rounded,
                      label: s.myAccount,
                      onTap: () {
                        Navigator.of(context).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const AccountScreen()),
                        );
                      },
                    ),
                    _DrawerItem(
                      icon: Icons.notifications_none_rounded,
                      label: s.notificationsItem,
                      badge: context.watch<SupportController>().unreadCount,
                      onTap: () {
                        Navigator.of(context).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const NotificationsScreen()),
                        );
                      },
                    ),
                    _DrawerItem(
                      icon: Icons.headset_mic_outlined,
                      label: s.supportItem,
                      onTap: () {
                        Navigator.of(context).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const SupportScreen()),
                        );
                      },
                    ),
                    _DrawerItem(
                      icon: Icons.settings_outlined,
                      label: s.settingsItem,
                      onTap: () {
                        Navigator.of(context).pop();
                        Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const SettingsScreen()),
                        );
                      },
                    ),

                    const SizedBox(height: 10),
                    // ------------------------- اللغة -------------------------
                    Container(
                      margin: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppColors.cardAlt.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.goldBorder),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.language_rounded,
                              size: 18, color: AppColors.gold),
                          const SizedBox(width: 10),
                          Text(
                            s.languageItem,
                            style: const TextStyle(
                              fontFamily: AppTheme.fontFamily,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const Spacer(),
                          GestureDetector(
                            onTap: () => settings.toggleLanguage(),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                gradient: AppColors.goldGradient,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                s.switchLanguage,
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xFF2A1B08),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // ------------------------- تذييل -------------------------
              Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    const BrandLogo(size: 30, glow: false),
                    const SizedBox(width: 8),
                    Text(
                      '${s.appName} • ${s.version} 1.0.0',
                      style: const TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: 10.5,
                        color: AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MeterChip extends StatelessWidget {
  const _MeterChip({
    required this.number,
    required this.active,
    required this.onTap,
  });

  final String number;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          gradient: active
              ? LinearGradient(
                  colors: [
                    AppColors.gold.withOpacity(0.20),
                    AppColors.gold.withOpacity(0.05),
                  ],
                )
              : null,
          color: active ? null : AppColors.field,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color:
                active ? AppColors.gold.withOpacity(0.6) : AppColors.goldBorder,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              active
                  ? Icons.check_circle_rounded
                  : Icons.radio_button_unchecked,
              size: 11,
              color: active ? AppColors.success : AppColors.textMuted,
            ),
            const SizedBox(width: 5),
            Flexible(
              child: Text(
                number,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontFamily: AppTheme.numberFontFamily,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  color:
                      active ? AppColors.textPrimary : AppColors.textSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.badge,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final int? badge;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          child: Row(
            children: [
              Icon(icon, size: 19, color: AppColors.gold),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              if (badge != null && badge! > 0)
                Container(
                  margin: const EdgeInsets.only(left: 8),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.danger,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '$badge',
                    style: const TextStyle(fontSize: 10, color: Colors.white),
                  ),
                ),
              const Icon(Icons.chevron_left_rounded,
                  size: 18, color: AppColors.textMuted),
            ],
          ),
        ),
      ),
    );
  }
}
