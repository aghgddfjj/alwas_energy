import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/ui_helpers.dart';
import '../../state/energy_controller.dart';
import '../../state/session_controller.dart';
import '../../state/settings_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/brand_logo.dart';
import '../../widgets/charts.dart';
import '../../widgets/gold_widgets.dart';
import '../lock_screen.dart';
import 'change_password_screen.dart';

/// ============================================================================
///  الإعدادات: بطاقة المشترك + السقف الشهري + القفل بالبصمة + اللغة + الخروج
/// ============================================================================
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final settings = context.watch<AppSettingsController>();
    final session = context.watch<SessionController>();
    final energy = context.watch<EnergyController>();
    final meter = energy.selectedMeter;
    final user = session.user;

    final cap = meter?.monthlyCapKwh ?? 400;
    final used = meter?.usedKwhThisMonth ?? 0;
    final ratio = cap <= 0 ? 0.0 : (used / cap).clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF16110C), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
                child: ScreenHeader(title: s.settings),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 22),
                  children: [
                    // ------------------ بطاقة المشترك الذكية ------------------
                    Container(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: [
                            Color(0xFFFFD489),
                            Color(0xFFE8A33D),
                            Color(0xFF9C6416),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.gold.withOpacity(0.30),
                            blurRadius: 26,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      s.smartSubscriberCard,
                                      style: const TextStyle(
                                        fontFamily: AppTheme.fontFamily,
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w600,
                                        color: Color(0xCC2A1B08),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      user?.name ?? '—',
                                      style: const TextStyle(
                                        fontFamily: AppTheme.fontFamily,
                                        fontSize: 18,
                                        fontWeight: FontWeight.w800,
                                        color: Color(0xFF2A1B08),
                                      ),
                                    ),
                                    Text(
                                      '@${user?.username ?? ''}',
                                      style: const TextStyle(
                                        fontFamily: AppTheme.fontFamily,
                                        fontSize: 11.5,
                                        color: Color(0xBB2A1B08),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color:
                                      const Color(0xFF2A1B08).withOpacity(0.14),
                                  border: Border.all(
                                    color: const Color(0xFF2A1B08)
                                        .withOpacity(0.30),
                                  ),
                                ),
                                child: const Icon(Icons.person_rounded,
                                    color: Color(0xFF2A1B08), size: 24),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              for (var i = 0;
                                  i < energy.meters.length;
                                  i++) ...[
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF2A1B08).withOpacity(
                                        i == energy.selectedMeterIndex
                                            ? 0.22
                                            : 0.10),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        i == energy.selectedMeterIndex
                                            ? Icons.check_circle_rounded
                                            : Icons.radio_button_unchecked,
                                        size: 10,
                                        color: i == energy.selectedMeterIndex
                                            ? AppColors.successDark
                                            : const Color(0x992A1B08),
                                      ),
                                      const SizedBox(width: 5),
                                      Text(
                                        energy.meters[i].number,
                                        style: const TextStyle(
                                          fontFamily: 'Cairo',
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                          color: Color(0xFF2A1B08),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (i != energy.meters.length - 1)
                                  const SizedBox(width: 8),
                              ],
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    // ------------------ السقف الشهري ------------------
                    GoldCard(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
                      child: Column(
                        children: [
                          Text(
                            s.monthlyCap,
                            style: const TextStyle(
                              fontFamily: AppTheme.fontFamily,
                              fontSize: 14.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 12),
                          RingProgress(
                            value: ratio,
                            size: 158,
                            strokeWidth: 11,
                            center: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '${(ratio * 100).round()}%',
                                  style: const TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 24,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                Text(
                                  '${Fmt.number(cap)} ${s.kwh}',
                                  style: const TextStyle(
                                    fontFamily: AppTheme.fontFamily,
                                    fontSize: 10.5,
                                    color: AppColors.textMuted,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              trackHeight: 3,
                              thumbShape: const RoundSliderThumbShape(
                                  enabledThumbRadius: 7),
                              overlayShape: const RoundSliderOverlayShape(
                                  overlayRadius: 16),
                            ),
                            child: Slider(
                              value: cap.clamp(100, 1000),
                              min: 100,
                              max: 1000,
                              divisions: 18,
                              label: '${Fmt.number(cap)} ${s.kwh}',
                              onChanged: (value) =>
                                  energy.setMonthlyCap(value.roundToDouble()),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${s.consumption}: ${Fmt.oneDecimal(used)} ${s.kwh}',
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 10.5,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              const Text(
                                '100 • 1000',
                                style: TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 9.5,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    // ------------------ قائمة الإعدادات ------------------
                    GoldCard(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Column(
                        children: [
                          _SettingSwitch(
                            icon: Icons.notifications_active_outlined,
                            title: s.notificationsSetting,
                            subtitle: s.notificationsSettingSub,
                            value: settings.notificationsEnabled,
                            onChanged: settings.setNotificationsEnabled,
                          ),
                          const GoldDivider(opacity: 0.6),
                          _SettingSwitch(
                            icon: Icons.fingerprint_rounded,
                            title: s.biometricLock,
                            subtitle: s.biometricLockSub,
                            value: settings.biometricEnabled,
                            onChanged: settings.setBiometricEnabled,
                          ),
                          const GoldDivider(opacity: 0.6),
                          _SettingTile(
                            icon: Icons.qr_code_scanner_rounded,
                            title: s.lockPreview,
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (_) => const LockScreen()),
                            ),
                          ),
                          const GoldDivider(opacity: 0.6),
                          _SettingTile(
                            icon: Icons.password_rounded,
                            title: s.changePassword,
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (_) => const ChangePasswordScreen()),
                            ),
                          ),
                          const GoldDivider(opacity: 0.6),
                          _SettingTile(
                            icon: Icons.language_rounded,
                            title: s.language,
                            trailing: GestureDetector(
                              onTap: settings.toggleLanguage,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 11, vertical: 5),
                                decoration: BoxDecoration(
                                  gradient: AppColors.goldGradient,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  s.switchLanguage,
                                  style: const TextStyle(
                                    fontFamily: AppTheme.fontFamily,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: Color(0xFF2A1B08),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const GoldDivider(opacity: 0.6),
                          _SettingTile(
                            icon: Icons.info_outline_rounded,
                            title: s.about,
                            trailing: const Text(
                              '1.0.0',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 11,
                                color: AppColors.textMuted,
                              ),
                            ),
                            onTap: () => _about(context, s),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // ------------------ تسجيل الخروج ------------------
                    GoldOutlineButton(
                      label: s.logout,
                      icon: Icons.logout_rounded,
                      expand: true,
                      color: AppColors.danger,
                      onPressed: () async {
                        final ok = await showConfirmDialog(
                          context,
                          title: s.logout,
                          body: s.logoutConfirm,
                          confirmLabel: s.logout,
                          cancelLabel: s.cancel,
                          danger: true,
                        );
                        if (ok) {
                          await session.signOut();
                          if (context.mounted) {
                            Navigator.of(context).popUntil((r) => r.isFirst);
                          }
                        }
                      },
                    ),
                    const SizedBox(height: 14),
                    // توقيع التطبيق
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        BrandLogo(size: 26, glow: false),
                        SizedBox(width: 8),
                        Text(
                          'Alwas Energy © 2026',
                          style: TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 10,
                            color: AppColors.textMuted,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const DemoBadge(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _about(BuildContext context, AppStrings s) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.about),
        content: Text(
          s.pick(
            '${s.appName} — تطبيق شحن العدادات الكهربائية ومتابعة الاستهلاك.\n\n'
                '• الواجهة: Flutter (Dart)\n'
                '• الأجزاء الأصلية: Java + Gradle\n'
                '• الإصدار: 1.0.0\n\n'
                'ملاحظة: هذه نسخة تجريبية ببيانات وهمية، وليست مرتبطة ببوابة دفع أو شركة كهرباء.',
            '${s.appName} — meter top-up and consumption tracking app.\n\n'
                '• UI: Flutter (Dart)\n'
                '• Native parts: Java + Gradle\n'
                '• Version: 1.0.0\n\n'
                'Note: demo build with mock data; not connected to a payment gateway or utility provider.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(
              s.ok,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontWeight: FontWeight.w700,
                color: AppColors.gold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingTile extends StatelessWidget {
  const _SettingTile({
    required this.icon,
    required this.title,
    this.onTap,
    this.trailing,
  });

  final IconData icon;
  final String title;
  final VoidCallback? onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: Row(
            children: [
              Icon(icon, size: 18, color: AppColors.gold),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              if (trailing != null) trailing!,
              const SizedBox(width: 6),
              const Icon(Icons.chevron_left_rounded,
                  size: 18, color: AppColors.textMuted),
            ],
          ),
        ),
      ),
    );
  }
}

class _SettingSwitch extends StatelessWidget {
  const _SettingSwitch({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.gold),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 10.5,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
          Switch.adaptive(
            value: value,
            onChanged: (v) {
              hapticTap();
              onChanged(v);
            },
          ),
        ],
      ),
    );
  }
}
