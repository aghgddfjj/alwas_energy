import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/ui_helpers.dart';
import '../../data/mock/mock_data.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/gold_widgets.dart';

/// ============================================================================
///  تغيير كلمة المرور
///  التحقق الحالي يتم مقابل كلمة المرور التجريبية (MockData.demoPassword).
///  عند الربط بالخدمة: استبدل التحقق بطلب POST /auth/change-password.
/// ============================================================================
class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _current = TextEditingController();
  final _next = TextEditingController();
  final _confirm = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _current.dispose();
    _next.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final s = AppStrings.of(context);
    if (_current.text != MockData.demoPassword) {
      showAppSnack(context, s.oldPasswordWrong, error: true);
      return;
    }
    if (_next.text.length < 4) {
      showAppSnack(context, s.passwordTooShort, error: true);
      return;
    }
    if (_next.text != _confirm.text) {
      showAppSnack(context, s.passwordMismatch, error: true);
      return;
    }
    setState(() => _busy = true);
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    setState(() => _busy = false);
    showAppSnack(context, s.passwordChanged, success: true);
    Navigator.of(context).maybePop();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF16110C), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
            child: Column(
              children: [
                ScreenHeader(title: s.changePassword),
                const SizedBox(height: 18),
                GoldCard(
                  padding: const EdgeInsets.all(16),
                  glow: true,
                  child: Column(
                    children: [
                      const Icon(Icons.shield_outlined,
                          size: 42, color: AppColors.goldLight),
                      const SizedBox(height: 8),
                      Text(
                        s.isArabic
                            ? 'اختر كلمة مرور قوية لحماية حسابك'
                            : 'Choose a strong password to protect your account',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 18),
                      GoldTextField(
                        controller: _current,
                        hint: s.currentPassword,
                        icon: Icons.lock_outline_rounded,
                        obscure: true,
                      ),
                      const SizedBox(height: 10),
                      GoldTextField(
                        controller: _next,
                        hint: s.newPassword,
                        icon: Icons.lock_reset_rounded,
                        obscure: true,
                      ),
                      const SizedBox(height: 10),
                      GoldTextField(
                        controller: _confirm,
                        hint: s.confirmPassword,
                        icon: Icons.lock_reset_rounded,
                        obscure: true,
                      ),
                      const SizedBox(height: 18),
                      GoldButton(
                        label: s.save,
                        icon: Icons.check_rounded,
                        loading: _busy,
                        onPressed: _busy ? null : _submit,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                const DemoBadge(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
