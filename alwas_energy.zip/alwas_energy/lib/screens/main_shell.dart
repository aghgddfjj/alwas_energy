import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../widgets/app_bottom_nav.dart';
import '../widgets/app_drawer.dart';
import 'home/home_screen.dart';
import 'invoices/invoices_screen.dart';
import 'payment/payment_screen.dart';

/// ============================================================================
///  الحاوية الرئيسية: شريط سفلي (الرئيسية / الدفع / الفواتير) + القائمة الجانبية
///  IndexedStack يحافظ على حالة كل صفحة عند التنقل (بدون إعادة تحميل).
/// ============================================================================
class MainShell extends StatefulWidget {
  const MainShell({super.key, this.initialIndex = 0});

  final int initialIndex;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  late int _index = widget.initialIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      drawer: const AppDrawer(),
      drawerEnableOpenDragGesture: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF14100B), AppColors.background],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: _index,
            children: const [
              HomeScreen(),
              PaymentScreen(),
              InvoicesScreen(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: AppBottomNav(
          index: _index,
          onChanged: (i) => setState(() => _index = i),
        ),
      ),
    );
  }
}
