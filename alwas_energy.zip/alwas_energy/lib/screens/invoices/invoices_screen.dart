import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/models.dart';
import '../../state/energy_controller.dart';
import '../../state/session_controller.dart';
import '../../state/support_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/charts.dart';
import '../../widgets/gold_widgets.dart';
import '../notifications/notifications_screen.dart';
import 'receipt_details_screen.dart';

/// ============================================================================
///  صفحة الفواتير والإيصالات: ملخص + رسم بياني + سجل الشحنات
/// ============================================================================
class InvoicesScreen extends StatelessWidget {
  const InvoicesScreen({super.key, this.now});

  /// وقت ثابت للعرض (للاختبارات)
  final DateTime? now;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final energy = context.watch<EnergyController>();
    final session = context.watch<SessionController>();
    final support = context.watch<SupportController>();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
      children: [
        HomeHeader(
          greeting: s.welcome,
          name: session.user?.name.split(' ').first ?? '—',
          unread: support.unreadCount,
          onAvatarTap: () => Scaffold.of(context).openDrawer(),
          onNotifications: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const NotificationsScreen()),
          ),
        ),
        const SizedBox(height: 12),
        DateChip(
          label: Fmt.headerDate(now ?? DateTime.now(), arabic: s.isArabic),
        ),
        const SizedBox(height: 14),

        // ------------------------- الملخص -------------------------
        GoldCard(
          glow: true,
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
          child: Column(
            children: [
              Row(
                children: [
                  const Spacer(),
                  Text(
                    s.invoicesSummary,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 15.5,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          s.totalCharges,
                          style: const TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 11,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              Fmt.number(energy.totalCharged),
                              style: const TextStyle(
                                fontFamily: AppTheme.numberFontFamily,
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                color: AppColors.gold,
                                height: 1.1,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 2),
                              child: Text(
                                s.currency,
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 10,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(width: 1, height: 40, color: AppColors.goldDivider),
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          s.invoicesCount,
                          style: const TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 11,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${energy.receiptsCount}',
                          style: const TextStyle(
                            fontFamily: AppTheme.numberFontFamily,
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                            height: 1.1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              BarWaveChart(values: energy.invoicesWave, height: 110),
            ],
          ),
        ),
        const SizedBox(height: 16),

        SectionHeader(title: s.topUpsLog),
        const SizedBox(height: 8),

        if (energy.receipts.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Column(
              children: [
                const Icon(Icons.receipt_long_outlined,
                    size: 44, color: AppColors.textMuted),
                const SizedBox(height: 10),
                Text(
                  s.noInvoices,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 13,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          )
        else
          ...energy.receipts.map((r) => _ReceiptRow(receipt: r)),

        const SizedBox(height: 10),
        const DemoBadge(),
      ],
    );
  }
}

/// صف إيصال في السجل
class _ReceiptRow extends StatelessWidget {
  const _ReceiptRow({required this.receipt});

  final ReceiptModel receipt;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final completed = receipt.status == ReceiptStatus.completed;

    return GoldCard(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ReceiptDetailsScreen(receipt: receipt),
        ),
      ),
      child: Row(
        children: [
          // أيقونة الإيصال
          GoldIconBox(
            icon: Icons.receipt_long_rounded,
            size: 38,
            color: completed ? AppColors.goldLight : AppColors.warning,
            radius: 12,
          ),
          const SizedBox(width: 10),

          // رقم الإيصال + الطريقة والتاريخ
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  receipt.receiptNumber,
                  style: const TextStyle(
                    fontFamily: AppTheme.numberFontFamily,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.6,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${receipt.methodName.resolve(arabic: s.isArabic)} • ${Fmt.shortDate(receipt.dateTime)}',
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 10.5,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),

          // المبلغ + الحالة
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '+${Fmt.number(receipt.amount)} ${s.currency}',
                style: TextStyle(
                  fontFamily: AppTheme.numberFontFamily,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: completed ? AppColors.success : AppColors.warning,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                completed ? s.completed : s.pending,
                style: TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w600,
                  color: completed ? AppColors.success : AppColors.warning,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
