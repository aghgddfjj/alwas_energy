import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/ui_helpers.dart';
import '../../data/models/models.dart';
import '../../services/export_service.dart';
import '../../state/support_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/gold_widgets.dart';
import '../../widgets/receipt_ticket.dart';

/// ============================================================================
///  صفحة تفاصيل إيصال الشحن
///  • الإيصال يُرسم من بيانات ReceiptModel (QR حقيقي + باركود)
///  • حفظ التقرير : تحويل الإيصال إلى صورة PNG داخل مجلد التطبيق
///  • مشاركة     : مشاركة صورة الإيصال عبر تطبيقات الجهاز
///  • الإبلاغ عن مشكلة: ينشئ تذكرة دعم فعلية
/// ============================================================================
class ReceiptDetailsScreen extends StatefulWidget {
  const ReceiptDetailsScreen({super.key, required this.receipt});

  final ReceiptModel receipt;

  @override
  State<ReceiptDetailsScreen> createState() => _ReceiptDetailsScreenState();
}

class _ReceiptDetailsScreenState extends State<ReceiptDetailsScreen> {
  final GlobalKey _ticketKey = GlobalKey();
  bool _busy = false;

  String _plainText(AppStrings s) {
    final r = widget.receipt;
    return '${s.digitalReceipt}\n'
        '${s.receiptNumber}: ${r.receiptNumber}\n'
        '${s.subscriberName}: ${r.subscriberName}\n'
        '${s.accountNumber}: ${r.accountNumber}\n'
        '${s.chargedAmount}: ${Fmt.number(r.amount)} ${s.currency}\n'
        '${s.energyAddedLabel}: ${Fmt.oneDecimal(r.kwh)} ${s.kwh}\n'
        '${s.balanceAfter}: ${Fmt.number(r.balanceAfter)} ${s.currency}\n'
        '${s.paymentMethod}: ${r.methodName.resolve(arabic: s.isArabic)}\n'
        '${s.dateAndTime}: ${Fmt.dateTime(r.dateTime)}\n'
        '— ${s.appName}';
  }

  Future<void> _save(AppStrings s) async {
    setState(() => _busy = true);
    final bytes = await ExportService.captureImage(_ticketKey);
    String? path;
    if (bytes != null) {
      path = await ExportService.saveImage(
        bytes,
        '${widget.receipt.receiptNumber}.png',
      );
    }
    if (!mounted) return;
    setState(() => _busy = false);
    showAppSnack(
      context,
      path == null ? s.receiptSaveFailed : '${s.receiptSaved}\n$path',
      success: path != null,
      error: path == null,
    );
  }

  Future<void> _share(AppStrings s) async {
    setState(() => _busy = true);
    final bytes = await ExportService.captureImage(_ticketKey);
    var ok = false;
    if (bytes != null) {
      ok = await ExportService.shareImage(
        bytes,
        '${widget.receipt.receiptNumber}.png',
        _plainText(s),
      );
    } else {
      ok = await ExportService.shareText(_plainText(s));
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (!ok) {
      showAppSnack(context, s.receiptCopied, icon: Icons.copy_rounded);
    }
  }

  Future<void> _reportIssue(AppStrings s) async {
    final ok = await showConfirmDialog(
      context,
      title: s.reportIssue,
      body: s.pick(
        'سيتم إنشاء تذكرة دعم مرتبطة بالإيصال ${widget.receipt.receiptNumber}.',
        'A support ticket linked to receipt ${widget.receipt.receiptNumber} will be created.',
      ),
      confirmLabel: s.send,
      cancelLabel: s.cancel,
    );
    if (!ok || !mounted) return;
    await context.read<SupportController>().createTicket(
          title: '${s.reportIssue} - ${widget.receipt.receiptNumber}',
          details: _plainText(s),
        );
    if (!mounted) return;
    showAppSnack(context, s.ticketCreated, success: true);
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF16110C), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
                child: ScreenHeader(title: s.digitalReceipt),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
                  children: [
                    RepaintBoundary(
                      key: _ticketKey,
                      child: Container(
                        // خلفية الإيصال عند تصديره كصورة
                        color: AppColors.background,
                        padding: const EdgeInsets.all(2),
                        child: ReceiptTicket(receipt: widget.receipt),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: GoldOutlineButton(
                            label: s.reportIssue,
                            icon: Icons.report_gmailerrorred_rounded,
                            expand: true,
                            color: AppColors.textSecondary,
                            onPressed: () => _reportIssue(s),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: GoldButton(
                            label: s.saveReport,
                            icon: Icons.download_rounded,
                            height: 48,
                            fontSize: 13.5,
                            loading: _busy,
                            onPressed: _busy ? null : () => _save(s),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    GoldOutlineButton(
                      label: s.shareReceipt,
                      icon: Icons.share_rounded,
                      expand: true,
                      onPressed: _busy ? null : () => _share(s),
                    ),
                    const SizedBox(height: 16),
                    const DemoBadge(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
