import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../widgets/brand_logo.dart';

/// ============================================================================
///  شاشة البداية (Splash): شعار متوهّج + حلقة تحميل ذهبية
/// ============================================================================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1600),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.2),
            radius: 0.95,
            colors: [Color(0xFF231A0F), AppColors.background],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 170,
                height: 170,
                child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context, _) => Stack(
                    alignment: Alignment.center,
                    children: [
                      CustomPaint(
                        size: const Size(170, 170),
                        painter:
                            _SplashRingPainter(progress: _controller.value),
                      ),
                      const BrandLogo(size: 78),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 22),
              ShaderMask(
                blendMode: BlendMode.srcIn,
                shaderCallback: (rect) =>
                    AppColors.goldGradient.createShader(rect),
                child: Text(
                  s.appName,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                s.pick(
                  'عداداتك وطاقتك في مكان واحد',
                  'Your meters and energy in one place',
                ),
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontSize: 11.5,
                  color: AppColors.textMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SplashRingPainter extends CustomPainter {
  _SplashRingPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final rect = Rect.fromCircle(center: center, radius: size.width / 2 - 4);

    canvas.drawCircle(
      center,
      rect.width / 2,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = AppColors.gold.withOpacity(0.10),
    );

    final start = progress * math.pi * 2;
    canvas.drawArc(
      rect,
      start,
      math.pi * 0.55,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..strokeCap = StrokeCap.round
        ..shader = const LinearGradient(
          colors: [Color(0x00FFD489), Color(0xFFFFD489), Color(0xFFE8A33D)],
        ).createShader(rect)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.4),
    );
    canvas.drawArc(
      rect,
      start + math.pi,
      math.pi * 0.30,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8
        ..strokeCap = StrokeCap.round
        ..color = AppColors.gold.withOpacity(0.5),
    );
  }

  @override
  bool shouldRepaint(covariant _SplashRingPainter old) =>
      old.progress != progress;
}
