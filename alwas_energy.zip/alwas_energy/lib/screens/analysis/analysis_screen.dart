import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/models.dart';
import '../../state/energy_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/charts.dart';
import '../../widgets/gold_widgets.dart';
import '../../widgets/segmented_tabs.dart';

/// ============================================================================
///  صفحة تحليل الاستهلاك والإحصائيات (تفصيلية)
/// ============================================================================
class AnalysisScreen extends StatelessWidget {
  const AnalysisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final energy = context.watch<EnergyController>();
    final summary = energy.summary;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF16110C), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
                child: ScreenHeader(
                  title: s.consumptionAnalysis,
                  subtitle: energy.selectedMeter?.number,
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 22),
                  children: [
                    SegmentedTabs(
                      labels: [s.hours, s.days, s.months],
                      index: energy.range.index,
                      onChanged: (i) =>
                          energy.setRange(ConsumptionRange.values[i]),
                    ),
                    const SizedBox(height: 12),

                    // ------------------ المؤشرات ------------------
                    Row(
                      children: [
                        Expanded(
                          child: _MetricCard(
                            label: s.consumption,
                            value: Fmt.oneDecimal(summary?.totalKwh ?? 0),
                            unit: s.kwh,
                            icon: Icons.bolt_rounded,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _MetricCard(
                            label: s.averageDaily,
                            value: Fmt.oneDecimal(summary?.averageDaily ?? 0),
                            unit: s.kwh,
                            icon: Icons.show_chart_rounded,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _MetricCard(
                            label: s.peakUsage,
                            value: Fmt.oneDecimal(summary?.peakUsage ?? 0),
                            unit: s.kwh,
                            icon: Icons.trending_up_rounded,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _MetricCard(
                            label: s.estimatedCost,
                            value: Fmt.number(summary?.estimatedCost ?? 0),
                            unit: s.currency,
                            icon: Icons.payments_outlined,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    // ------------------ الرسم ------------------
                    GoldCard(
                      padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
                      glow: true,
                      child: Column(
                        children: [
                          Row(
                            children: [
                              _LegendDot(
                                  color: AppColors.gold,
                                  label: s.currentPeriod),
                              const SizedBox(width: 12),
                              _LegendDot(
                                color: const Color(0xFFB9B2A6),
                                label: s.lastPeriod,
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          LineAreaChart(
                            current: summary?.currentPeriod ?? const [],
                            previous: summary?.previousPeriod ?? const [],
                            height: 200,
                            yTicks: _ticks(energy.range),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    // ------------------ التفاصيل ------------------
                    SectionHeader(title: s.dailyDetails),
                    const SizedBox(height: 8),
                    GoldCard(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                flex: 2,
                                child: Text(s.consumption, style: _headerStyle),
                              ),
                              Expanded(
                                flex: 1,
                                child: Text(s.cost,
                                    textAlign: TextAlign.center,
                                    style: _headerStyle),
                              ),
                              Expanded(
                                flex: 1,
                                child: Text(s.day,
                                    textAlign: TextAlign.end,
                                    style: _headerStyle),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          const GoldDivider(opacity: 0.7),
                          ...?summary?.currentPeriod.reversed.map(
                            (p) => Padding(
                              padding: const EdgeInsets.symmetric(vertical: 9),
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 6,
                                          height: 6,
                                          decoration: const BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: AppColors.gold,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          '${Fmt.oneDecimal(p.value)} ${s.kwh}',
                                          style: const TextStyle(
                                            fontFamily: 'Cairo',
                                            fontSize: 12,
                                            color: AppColors.textPrimary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Text(
                                      Fmt.number(p.value * 250),
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 12,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Text(
                                      p.label,
                                      textAlign: TextAlign.end,
                                      style: const TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 12,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    const DemoBadge(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static const TextStyle _headerStyle = TextStyle(
    fontFamily: AppTheme.fontFamily,
    fontSize: 11,
    fontWeight: FontWeight.w600,
    color: AppColors.textMuted,
  );

  List<double> _ticks(ConsumptionRange range) {
    switch (range) {
      case ConsumptionRange.hours:
        return const [0, 0.9, 1.8, 2.8];
      case ConsumptionRange.days:
        return const [0, 2, 4, 7];
      case ConsumptionRange.months:
        return const [0, 50, 100, 160];
    }
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.label,
    required this.value,
    required this.unit,
    required this.icon,
  });

  final String label;
  final String value;
  final String unit;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return GoldCard(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 13, color: AppColors.gold),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Flexible(
                child: Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 19,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                    height: 1.1,
                  ),
                ),
              ),
              const SizedBox(width: 3),
              Padding(
                padding: const EdgeInsets.only(bottom: 2),
                child: Text(
                  unit,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 9.5,
                    color: AppColors.textMuted,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LegendDot extends StatelessWidget {
  const _LegendDot({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(shape: BoxShape.circle, color: color),
        ),
        const SizedBox(width: 5),
        Text(
          label,
          style: const TextStyle(
            fontFamily: AppTheme.fontFamily,
            fontSize: 10,
            color: AppColors.textMuted,
          ),
        ),
      ],
    );
  }
}
