import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/models.dart';
import '../../state/support_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/gold_widgets.dart';

/// ============================================================================
///  الإشعارات: الشحنات، الصيانة، تحديث التعرفة، انقطاع الخدمة
/// ============================================================================
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  IconData _iconFor(NotificationKind kind) {
    switch (kind) {
      case NotificationKind.recharge:
        return Icons.bolt_rounded;
      case NotificationKind.maintenance:
        return Icons.build_circle_outlined;
      case NotificationKind.tariff:
        return Icons.price_change_outlined;
      case NotificationKind.outage:
        return Icons.power_off_rounded;
      case NotificationKind.system:
        return Icons.info_outline_rounded;
    }
  }

  Color _colorFor(NotificationKind kind) {
    switch (kind) {
      case NotificationKind.recharge:
        return AppColors.success;
      case NotificationKind.maintenance:
        return AppColors.info;
      case NotificationKind.tariff:
        return AppColors.warning;
      case NotificationKind.outage:
        return AppColors.danger;
      case NotificationKind.system:
        return AppColors.gold;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final support = context.watch<SupportController>();
    final items = support.notifications;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF16110C), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                child: ScreenHeader(
                  title: s.notificationsItem,
                  action: TextButton(
                    onPressed: support.markAllRead,
                    child: Text(
                      s.isArabic ? 'قراءة الكل' : 'Read all',
                      style: const TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: 11,
                        color: AppColors.gold,
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: items.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.notifications_off_outlined,
                                size: 46, color: AppColors.textMuted),
                            const SizedBox(height: 10),
                            Text(
                              s.noNotifications,
                              style: const TextStyle(
                                fontFamily: AppTheme.fontFamily,
                                fontSize: 13,
                                color: AppColors.textMuted,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, i) {
                          final n = items[i];
                          final color = _colorFor(n.kind);
                          return GoldCard(
                            padding: const EdgeInsets.all(12),
                            borderColor: n.read
                                ? AppColors.goldBorder
                                : color.withOpacity(0.35),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                GoldIconBox(
                                  icon: _iconFor(n.kind),
                                  size: 36,
                                  color: color,
                                  radius: 11,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              n.title
                                                  .resolve(arabic: s.isArabic),
                                              style: const TextStyle(
                                                fontFamily: AppTheme.fontFamily,
                                                fontSize: 13.5,
                                                fontWeight: FontWeight.w700,
                                                color: AppColors.textPrimary,
                                              ),
                                            ),
                                          ),
                                          if (!n.read)
                                            Container(
                                              width: 7,
                                              height: 7,
                                              decoration: const BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: AppColors.gold,
                                              ),
                                            ),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        n.body.resolve(arabic: s.isArabic),
                                        style: const TextStyle(
                                          fontFamily: AppTheme.fontFamily,
                                          fontSize: 11.5,
                                          height: 1.6,
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        '${Fmt.shortDate(n.date)} • ${Fmt.time(n.date, arabic: s.isArabic)}',
                                        style: const TextStyle(
                                          fontFamily: AppTheme.fontFamily,
                                          fontSize: 10,
                                          color: AppColors.textMuted,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
