import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/ui_helpers.dart';
import '../services/biometric_service.dart';
import '../state/session_controller.dart';
import '../widgets/brand_logo.dart';
import '../widgets/gold_widgets.dart';

/// ============================================================================
///  شاشة قفل التطبيق بالبصمة
///  • حلقة ذهبية دوّارة + أيقونة بصمة متوهجة
///  • الضغط على البصمة أو زر "فتح التطبيق" يستدعي بصمة الجهاز (local_auth)
///  • عند عدم توفر البصمة (محاكي/جهاز بدون بصمة) يُفتح القفل بالوضع التجريبي
/// ============================================================================
class LockScreen extends StatefulWidget {
  const LockScreen({super.key, this.autoAuthenticate = true});

  /// طلب البصمة تلقائياً عند فتح الشاشة (يُعطَّل في الاختبارات/المعاينة)
  final bool autoAuthenticate;

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> with TickerProviderStateMixin {
  late final AnimationController _rotate;
  late final AnimationController _pulse;
  bool _authenticating = false;

  @override
  void initState() {
    super.initState();
    _rotate = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 7),
    )..repeat();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    // محاولة تلقائية بعد فتح الشاشة (مرة واحدة)
    if (widget.autoAuthenticate) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Future<void>.delayed(const Duration(milliseconds: 500), () {
          if (mounted) _authenticate();
        });
      });
    }
  }

  @override
  void dispose() {
    _rotate.dispose();
    _pulse.dispose();
    super.dispose();
  }

  Future<void> _authenticate() async {
    if (_authenticating) return;
    final s = AppStrings.of(context);
    setState(() => _authenticating = true);
    final result =
        await context.read<SessionController>().unlockWithBiometrics(s);
    if (!mounted) return;
    setState(() => _authenticating = false);
    switch (result.status) {
      case BiometricStatus.success:
        showAppSnack(context, s.unlocked, success: true);
        break;
      case BiometricStatus.unavailable:
        showAppSnack(context, s.biometricUnavailable,
            icon: Icons.fingerprint_rounded);
        break;
      case BiometricStatus.failed:
      case BiometricStatus.error:
        showAppSnack(context, s.authFailed, error: true);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.15),
            radius: 1.0,
            colors: [Color(0xFF1C1409), Color(0xFF080605)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const BrandLogo(size: 52),
                  const SizedBox(height: 26),
                  Text(
                    s.appLocked,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    s.appLockedSub,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 12.5,
                      height: 1.7,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 34),

                  // ------------------ حلقة البصمة ------------------
                  GestureDetector(
                    onTap: _authenticate,
                    child: SizedBox(
                      width: 210,
                      height: 210,
                      child: AnimatedBuilder(
                        animation: Listenable.merge([_rotate, _pulse]),
                        builder: (context, _) {
                          return Stack(
                            alignment: Alignment.center,
                            children: [
                              // الحلقة الذهبية الدوّارة
                              Transform.rotate(
                                angle: _rotate.value * math.pi * 2,
                                child: CustomPaint(
                                  size: const Size(210, 210),
                                  painter: _ArcRingPainter(
                                    pulse: _pulse.value,
                                    busy: _authenticating,
                                  ),
                                ),
                              ),
                              // الدائرة الداخلية
                              Container(
                                width: 150,
                                height: 150,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: RadialGradient(
                                    colors: [
                                      AppColors.gold.withOpacity(
                                          0.16 + 0.06 * _pulse.value),
                                      const Color(0xFF100C08),
                                    ],
                                  ),
                                  border: Border.all(
                                    color: AppColors.gold.withOpacity(0.35),
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.gold.withOpacity(
                                          0.18 + 0.10 * _pulse.value),
                                      blurRadius: 30,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: _authenticating
                                      ? const SizedBox(
                                          width: 34,
                                          height: 34,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2.4,
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                                    AppColors.gold),
                                          ),
                                        )
                                      : Icon(
                                          Icons.fingerprint_rounded,
                                          size: 78,
                                          color: AppColors.goldLight,
                                          shadows: [
                                            Shadow(
                                              color: AppColors.gold
                                                  .withOpacity(0.75),
                                              blurRadius: 22,
                                            ),
                                          ],
                                        ),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),
                  Text(
                    _authenticating ? s.authenticating : s.touchFingerprint,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.gold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: 190,
                    height: 46,
                    child: GoldOutlineButton(
                      label: s.openApp,
                      icon: Icons.lock_open_rounded,
                      expand: true,
                      onPressed: _authenticating ? null : _authenticate,
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextButton(
                    onPressed: () {
                      // الدخول بكلمة المرور: يعيد المستخدم لشاشة الدخول
                      context.read<SessionController>().signOut();
                    },
                    child: Text(
                      s.usePasswordInstead,
                      style: const TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: 12,
                        color: AppColors.textSecondary,
                        decoration: TextDecoration.underline,
                        decorationColor: AppColors.textMuted,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ArcRingPainter extends CustomPainter {
  _ArcRingPainter({required this.pulse, required this.busy});

  final double pulse;
  final bool busy;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromCircle(
      center: Offset(size.width / 2, size.height / 2),
      radius: size.width / 2 - 6,
    );

    // خلفية الحلقة
    canvas.drawCircle(
      rect.center,
      rect.width / 2,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = AppColors.gold.withOpacity(0.12),
    );

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.4
      ..strokeCap = StrokeCap.round
      ..shader = const LinearGradient(
        colors: [Color(0x00FFD489), Color(0xFFFFD489), Color(0xFFE8A33D)],
      ).createShader(rect)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5);

    // قوسان متقابلان (يعطيان إحساس الدوران)
    canvas.drawArc(rect, 0.15, math.pi * 0.62, false, paint);
    canvas.drawArc(rect, math.pi + 0.15, math.pi * 0.62, false, paint);

    // نقطة على الحلقة
    final angle = pulse * math.pi * 2;
    final dot = Offset(
      rect.center.dx + rect.width / 2 * math.cos(angle),
      rect.center.dy + rect.width / 2 * math.sin(angle),
    );
    canvas.drawCircle(
      dot,
      4.5,
      Paint()
        ..color = const Color(0xFFFFE7B8)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
    );
  }

  @override
  bool shouldRepaint(covariant _ArcRingPainter old) =>
      old.pulse != pulse || old.busy != busy;
}
