import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/ui_helpers.dart';
import '../state/lamp_controller.dart';
import '../state/session_controller.dart';
import '../state/settings_controller.dart';
import '../widgets/app_headers.dart';
import '../widgets/gold_widgets.dart';
import '../widgets/hanging_lamp.dart';

/// ============================================================================
///  شاشة إنشاء حساب جديد — بنفس الهوية (مصباح + بطاقة ذهبية)
/// ============================================================================
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _meter = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _agree = false;
  bool _loading = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _email.dispose();
    _meter.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final s = AppStrings.of(context);
    if (_name.text.trim().isEmpty ||
        _phone.text.trim().isEmpty ||
        _email.text.trim().isEmpty ||
        _meter.text.trim().isEmpty ||
        _password.text.isEmpty) {
      showAppSnack(context, s.loginEmptyFields, error: true);
      return;
    }
    if (!_email.text.contains('@')) {
      showAppSnack(context, s.invalidEmail, error: true);
      return;
    }
    if (_phone.text.replaceAll(RegExp(r'\D'), '').length < 9) {
      showAppSnack(context, s.invalidPhone, error: true);
      return;
    }
    if (_password.text.length < 4) {
      showAppSnack(context, s.passwordTooShort, error: true);
      return;
    }
    if (_password.text != _confirm.text) {
      showAppSnack(context, s.passwordMismatch, error: true);
      return;
    }
    if (!_agree) {
      showAppSnack(context, s.mustAgree, error: true);
      return;
    }
    setState(() => _loading = true);
    await context.read<SessionController>().register(
          fullName: _name.text.trim(),
          phone: _phone.text.trim(),
          email: _email.text.trim(),
          password: _password.text,
          meterNumber: _meter.text.trim(),
        );
    if (!mounted) return;
    setState(() => _loading = false);
    showAppSnack(context, s.registerSuccess, success: true);
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final lamp = context.watch<LampController>();
    final settings = context.watch<AppSettingsController>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: LampAmbience(
        isOn: lamp.isOn,
        child: Container(
          decoration: const BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(0, -0.9),
              radius: 1.2,
              colors: [Color(0xFF241A0E), Color(0xFF0B0806)],
            ),
          ),
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Row(
                    children: [
                      LanguageChip(
                        label: s.switchLanguage,
                        onTap: settings.toggleLanguage,
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () => Navigator.of(context).maybePop(),
                        icon: const Icon(Icons.close_rounded,
                            color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                  HangingLamp(
                    isOn: lamp.isOn,
                    onToggle: lamp.toggle,
                    width: MediaQuery.of(context).size.width * 0.55,
                    height: 170,
                  ),
                  const SizedBox(height: 6),
                  GoldCard(
                    padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
                    glow: true,
                    child: Column(
                      children: [
                        Text(
                          s.registerTitle,
                          style: const TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          s.registerSubtitle,
                          style: const TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 11.5,
                            color: AppColors.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 16),
                        GoldTextField(
                          controller: _name,
                          hint: s.fullName,
                          icon: Icons.person_outline_rounded,
                        ),
                        const SizedBox(height: 10),
                        GoldTextField(
                          controller: _phone,
                          hint: s.phone,
                          icon: Icons.phone_outlined,
                          keyboardType: TextInputType.phone,
                        ),
                        const SizedBox(height: 10),
                        GoldTextField(
                          controller: _email,
                          hint: s.email,
                          icon: Icons.alternate_email_rounded,
                          keyboardType: TextInputType.emailAddress,
                        ),
                        const SizedBox(height: 10),
                        GoldTextField(
                          controller: _meter,
                          hint: s.meterNumberLabel,
                          icon: Icons.speed_rounded,
                          keyboardType: TextInputType.number,
                        ),
                        const SizedBox(height: 10),
                        GoldTextField(
                          controller: _password,
                          hint: s.password,
                          icon: Icons.lock_outline_rounded,
                          obscure: true,
                        ),
                        const SizedBox(height: 10),
                        GoldTextField(
                          controller: _confirm,
                          hint: s.confirmPassword,
                          icon: Icons.lock_reset_rounded,
                          obscure: true,
                        ),
                        const SizedBox(height: 12),
                        GestureDetector(
                          onTap: () => setState(() => _agree = !_agree),
                          behavior: HitTestBehavior.opaque,
                          child: Row(
                            children: [
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 180),
                                width: 18,
                                height: 18,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: _agree
                                      ? AppColors.gold
                                      : Colors.transparent,
                                  border: Border.all(
                                    color: _agree
                                        ? AppColors.goldLight
                                        : AppColors.textMuted,
                                    width: 1.3,
                                  ),
                                ),
                                child: _agree
                                    ? const Icon(Icons.check_rounded,
                                        size: 13, color: Color(0xFF2A1B08))
                                    : null,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  s.agreeTerms,
                                  style: const TextStyle(
                                    fontFamily: AppTheme.fontFamily,
                                    fontSize: 12,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        GoldButton(
                          label: s.registerButton,
                          loading: _loading,
                          onPressed: _loading ? null : _submit,
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              s.haveAccount,
                              style: const TextStyle(
                                fontFamily: AppTheme.fontFamily,
                                fontSize: 12.5,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            const SizedBox(width: 6),
                            GestureDetector(
                              onTap: () => Navigator.of(context).maybePop(),
                              child: Text(
                                s.signIn,
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.goldLight,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  const DemoBadge(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
