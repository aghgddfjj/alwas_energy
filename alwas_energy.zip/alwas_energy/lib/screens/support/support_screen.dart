import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/ui_helpers.dart';
import '../../state/support_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/gold_widgets.dart';
import '../../widgets/ticket_card.dart';

/// ============================================================================
///  مركز الدعم والتشخيص الذكي
///  • كرة ذهبية متوهجة بمساران مداريان (زخرفية، مرسومة برمجياً)
///  • فحص العداد والشبكة (تشخيص تجريبي)
///  • 4 أزرار تشخيص سريع تُنشئ بلاغاً فعلياً في السجل
///  • سجل البلاغات والتذاكر + إنشاء تذكرة جديدة
/// ============================================================================
class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _orbController = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 8),
  )..repeat();

  @override
  void dispose() {
    _orbController.dispose();
    super.dispose();
  }

  Future<void> _runDiagnostics(AppStrings s, {String? title}) async {
    final support = context.read<SupportController>();
    if (title != null) {
      await support.createTicket(title: title, details: s.quickDiag);
      if (!mounted) return;
      showAppSnack(context, s.ticketCreated, success: true);
      return;
    }
    final healthy = await support.runDiagnostics();
    if (!mounted) return;
    showAppSnack(
      context,
      healthy ? s.diagnosisDone : s.authFailed,
      success: healthy,
      error: !healthy,
    );
  }

  Future<void> _newTicket(AppStrings s) async {
    final subject = TextEditingController();
    final details = TextEditingController();
    await showAppSheet<void>(
      context,
      Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              s.newTicket,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 16),
            GoldTextField(
              controller: subject,
              hint: s.ticketSubject,
              icon: Icons.title_rounded,
            ),
            const SizedBox(height: 10),
            GoldTextField(
              controller: details,
              hint: s.ticketDetails,
              icon: Icons.notes_rounded,
              maxLines: 4,
            ),
            const SizedBox(height: 16),
            GoldButton(
              label: s.send,
              icon: Icons.send_rounded,
              onPressed: () async {
                if (subject.text.trim().isEmpty) return;
                final support = context.read<SupportController>();
                Navigator.of(context).pop();
                await support.createTicket(
                  title: subject.text.trim(),
                  details: details.text.trim(),
                );
                if (!mounted) return;
                showAppSnack(context, s.ticketCreated, success: true);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final support = context.watch<SupportController>();

    final diagItems = <_DiagItem>[
      _DiagItem(
        title: s.diagDelayCharge,
        subtitle: s.diagDelayChargeSub,
        icon: Icons.bolt_rounded,
      ),
      _DiagItem(
        title: s.diagDisconnect,
        subtitle: s.diagDisconnectSub,
        icon: Icons.power_off_rounded,
      ),
      _DiagItem(
        title: s.diagInvoice,
        subtitle: s.diagInvoiceSub,
        icon: Icons.receipt_long_rounded,
      ),
      _DiagItem(
        title: s.diagEmergency,
        subtitle: s.diagEmergencySub,
        icon: Icons.warning_amber_rounded,
      ),
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF16110C), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
                child: ScreenHeader(title: s.supportTitle),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
                  children: [
                    // ------------------ الكرة المتوهجة ------------------
                    Center(
                      child: GestureDetector(
                        onTap: () => _runDiagnostics(s),
                        child: SizedBox(
                          width: 150,
                          height: 130,
                          child: AnimatedBuilder(
                            animation: _orbController,
                            builder: (context, _) => CustomPaint(
                              painter: _OrbPainter(
                                phase: _orbController.value,
                                busy: support.diagnosing,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          color: AppColors.success.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: AppColors.success.withOpacity(0.45)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              support.diagnosing
                                  ? s.checking
                                  : s.networkHealthy,
                              style: const TextStyle(
                                fontFamily: AppTheme.fontFamily,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                color: AppColors.success,
                              ),
                            ),
                            const SizedBox(width: 6),
                            support.diagnosing
                                ? const SizedBox(
                                    width: 12,
                                    height: 12,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 1.8,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          AppColors.success),
                                    ),
                                  )
                                : const Icon(Icons.check_circle_rounded,
                                    size: 13, color: AppColors.success),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // ------------------ التشخيص السريع ------------------
                    GoldCard(
                      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              const Spacer(),
                              Text(
                                s.quickDiag,
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: _DiagTile(
                                  item: diagItems[0],
                                  onTap: () => _runDiagnostics(s,
                                      title: diagItems[0].title),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: _DiagTile(
                                  item: diagItems[1],
                                  onTap: () => _runDiagnostics(s,
                                      title: diagItems[1].title),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: _DiagTile(
                                  item: diagItems[2],
                                  onTap: () => _runDiagnostics(s,
                                      title: diagItems[2].title),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: _DiagTile(
                                  item: diagItems[3],
                                  onTap: () => _runDiagnostics(s,
                                      title: diagItems[3].title),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),

                    // ------------------ سجل التذاكر ------------------
                    SectionHeader(
                      title: s.ticketsLog,
                      actionLabel: s.newTicket,
                      actionIcon: Icons.add_circle_outline_rounded,
                      onAction: () => _newTicket(s),
                    ),
                    const SizedBox(height: 10),
                    ...support.tickets.map((t) => TicketCard(ticket: t)),
                    const SizedBox(height: 10),
                    const DemoBadge(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DiagItem {
  const _DiagItem({
    required this.title,
    required this.subtitle,
    required this.icon,
  });
  final String title;
  final String subtitle;
  final IconData icon;
}

class _DiagTile extends StatelessWidget {
  const _DiagTile({required this.item, required this.onTap});

  final _DiagItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
        decoration: BoxDecoration(
          color: AppColors.field.withOpacity(0.8),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.goldBorder),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    item.title,
                    textAlign: TextAlign.right,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    item.subtitle,
                    textAlign: TextAlign.right,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 10,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            GoldIconBox(icon: item.icon, size: 34, radius: 11),
          ],
        ),
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
///  رسم الكرة الذهبية المتوهجة مع المسارات المدارية
/// ---------------------------------------------------------------------------
class _OrbPainter extends CustomPainter {
  _OrbPainter({required this.phase, required this.busy});

  final double phase;
  final bool busy;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.24;

    // هالة خارجية
    canvas.drawCircle(
      center,
      radius * 2.2,
      Paint()
        ..shader = RadialGradient(
          colors: [
            AppColors.gold.withOpacity(0.28),
            AppColors.gold.withOpacity(0.06),
            Colors.transparent,
          ],
          stops: const [0.2, 0.6, 1.0],
        ).createShader(
          Rect.fromCircle(center: center, radius: radius * 2.2),
        ),
    );

    // المسارات المدارية
    for (var i = 0; i < 3; i++) {
      canvas.save();
      canvas.translate(center.dx, center.dy);
      canvas
          .rotate(-0.35 + i * 0.62 + math.sin(phase * math.pi * 2 + i) * 0.04);
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset.zero,
          width: radius * (4.0 + i * 0.35),
          height: radius * (1.35 + i * 0.12),
        ),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.9
          ..color = const Color(0xFFC9BBA6).withOpacity(0.35 - i * 0.06),
      );
      // قمر صغير يدور على المسار
      final angle = phase * math.pi * 2 + i * 2.1;
      final orbitW = radius * (4.0 + i * 0.35) / 2;
      final orbitH = radius * (1.35 + i * 0.12) / 2;
      final dot = Offset(math.cos(angle) * orbitW, math.sin(angle) * orbitH);
      canvas.drawCircle(
        dot,
        1.9,
        Paint()..color = const Color(0xFFFFE7B8).withOpacity(0.85),
      );
      canvas.restore();
    }

    // الكرة
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.35, -0.45),
          colors: [
            Color(0xFFFFF0C9),
            Color(0xFFFFC96B),
            Color(0xFFB9741C),
            Color(0xFF6B4210),
          ],
          stops: [0.0, 0.35, 0.75, 1.0],
        ).createShader(Rect.fromCircle(center: center, radius: radius)),
    );

    // لمعة
    canvas.drawCircle(
      Offset(center.dx - radius * 0.30, center.dy - radius * 0.35),
      radius * 0.20,
      Paint()
        ..color = Colors.white.withOpacity(0.55)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    if (busy) {
      canvas.drawCircle(
        center,
        radius * 1.6,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = AppColors.gold.withOpacity(0.6),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) =>
      old.phase != phase || old.busy != busy;
}
