import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/ui_helpers.dart';
import '../../state/energy_controller.dart';
import '../../state/session_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/brand_logo.dart';
import '../../widgets/gold_widgets.dart';
import '../../widgets/stat_card.dart';

/// ============================================================================
///  حسابي: بيانات المشترك (قابلة للتعديل) + العدادات المرتبطة
/// ============================================================================
class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _email;
  late final TextEditingController _city;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final user = context.read<SessionController>().user;
    _name = TextEditingController(text: user?.name ?? '');
    _phone = TextEditingController(text: user?.phone ?? '');
    _email = TextEditingController(text: user?.email ?? '');
    _city = TextEditingController(text: user?.city ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _email.dispose();
    _city.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final s = AppStrings.of(context);
    final session = context.read<SessionController>();
    final user = session.user;
    if (user == null) return;
    setState(() => _busy = true);
    await session.updateProfile(
      user.copyWith(
        name: _name.text.trim(),
        phone: _phone.text.trim(),
        email: _email.text.trim(),
        city: _city.text.trim(),
      ),
    );
    if (!mounted) return;
    setState(() => _busy = false);
    showAppSnack(context, s.profileUpdated, success: true);
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final session = context.watch<SessionController>();
    final energy = context.watch<EnergyController>();
    final user = session.user;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF16110C), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
                child: ScreenHeader(title: s.myAccount),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 22),
                  children: [
                    const Center(child: GoldAvatar(size: 78)),
                    const SizedBox(height: 10),
                    Center(
                      child: Text(
                        user?.name ?? '—',
                        style: const TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    Center(
                      child: Text(
                        '@${user?.username ?? ''}',
                        style: const TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),

                    GoldCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              const Spacer(),
                              Text(
                                s.accountInfo,
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          GoldTextField(
                            controller: _name,
                            hint: s.fullName,
                            icon: Icons.person_outline_rounded,
                          ),
                          const SizedBox(height: 10),
                          GoldTextField(
                            controller: _phone,
                            hint: s.phone,
                            icon: Icons.phone_outlined,
                            keyboardType: TextInputType.phone,
                          ),
                          const SizedBox(height: 10),
                          GoldTextField(
                            controller: _email,
                            hint: s.email,
                            icon: Icons.alternate_email_rounded,
                            keyboardType: TextInputType.emailAddress,
                          ),
                          const SizedBox(height: 10),
                          GoldTextField(
                            controller: _city,
                            hint: s.city,
                            icon: Icons.location_city_rounded,
                          ),
                          const SizedBox(height: 14),
                          Builder(
                            builder: (context) => GoldButton(
                              label: s.save,
                              icon: Icons.check_rounded,
                              loading: _busy,
                              onPressed: _busy ? null : _save,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),

                    // بيانات ثابتة
                    GoldCard(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      child: Column(
                        children: [
                          InfoRow(
                            label: s.subscriberNumber,
                            value: user?.subscriberNumber ?? '—',
                          ),
                          InfoRow(
                            label: s.subscriberSince,
                            value: user?.memberSince ?? '—',
                          ),
                          InfoRow(
                            label: s.city,
                            value: user?.city ?? '—',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    SectionHeader(title: s.myMeters),
                    const SizedBox(height: 8),
                    ...energy.meters.map(
                      (m) => GoldCard(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(13),
                        onTap: () {
                          final index = energy.meters.indexOf(m);
                          energy.selectMeter(index);
                          showAppSnack(
                            context,
                            '${s.meterNumberLabel}: ${m.number}',
                            success: true,
                          );
                        },
                        child: Row(
                          children: [
                            const GoldIconBox(
                              icon: Icons.speed_rounded,
                              size: 38,
                              color: AppColors.goldLight,
                              radius: 12,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    m.number,
                                    style: const TextStyle(
                                      fontFamily: 'Cairo',
                                      fontSize: 13.5,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 1,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                  Text(
                                    '${m.alias} • ${Fmt.currency(m.balance, s.currency, arabic: s.isArabic)}',
                                    style: const TextStyle(
                                      fontFamily: AppTheme.fontFamily,
                                      fontSize: 10.5,
                                      color: AppColors.textMuted,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            LiveBadge(
                              label: m.connected
                                  ? s.meterConnected
                                  : s.pick('غير متصل', 'Offline'),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const DemoBadge(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
