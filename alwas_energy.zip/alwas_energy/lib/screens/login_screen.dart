import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/l10n/app_strings.dart';
import '../core/theme/app_colors.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/ui_helpers.dart';
import '../state/lamp_controller.dart';
import '../state/session_controller.dart';
import '../state/settings_controller.dart';
import '../widgets/app_headers.dart';
import '../widgets/brand_logo.dart';
import '../widgets/gold_widgets.dart';
import '../widgets/hanging_lamp.dart';
import 'register_screen.dart';

/// ============================================================================
///  شاشة تسجيل الدخول — قلب التصميم: مصباح معلّق تفاعلي + حلقة دخول دائرية
/// ============================================================================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _username = TextEditingController();
  final _password = TextEditingController();
  bool _remember = true;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _remember = context.read<AppSettingsController>().rememberMe;
  }

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final s = AppStrings.of(context);
    if (_username.text.trim().isEmpty || _password.text.isEmpty) {
      showAppSnack(context, s.loginEmptyFields, error: true);
      return;
    }
    setState(() => _loading = true);
    final session = context.read<SessionController>();
    final settings = context.read<AppSettingsController>();
    await settings.setRememberMe(_remember);
    final ok = await session.signIn(
      username: _username.text,
      password: _password.text,
    );
    if (!mounted) return;
    setState(() => _loading = false);
    if (ok) {
      showAppSnack(context, s.loginSuccess, success: true);
    } else {
      showAppSnack(context, s.loginFailed, error: true);
    }
  }

  void _forgotPassword() {
    final s = AppStrings.of(context);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.forgotPassword),
        content: Text(
          s.pick(
            'لإعادة تعيين كلمة المرور تواصل مع مركز الدعم على الرقم 8000 أو من خلال مركز الدعم داخل التطبيق.\n\n(للتجربة استخدم: ahmed / 1234)',
            'To reset your password contact support on 8000 or via the in-app support center.\n\n(Demo login: ahmed / 1234)',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(
              s.ok,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                color: AppColors.gold,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final lamp = context.watch<LampController>();
    final settings = context.watch<AppSettingsController>();

    return Scaffold(
      backgroundColor: AppColors.background,
      resizeToAvoidBottomInset: true,
      body: LampAmbience(
        isOn: lamp.isOn,
        child: Container(
          decoration: const BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(0, -0.85),
              radius: 1.15,
              colors: [Color(0xFF271B0E), Color(0xFF0B0806)],
            ),
          ),
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final lampHeight =
                    (constraints.maxHeight * 0.30).clamp(180.0, 300.0);
                final lampWidth = constraints.maxWidth * 0.72;
                return SingleChildScrollView(
                  physics: const ClampingScrollPhysics(),
                  child: ConstrainedBox(
                    constraints:
                        BoxConstraints(minHeight: constraints.maxHeight),
                    child: Column(
                      children: [
                        // ------------------ الشريط العلوي ------------------
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                          child: Row(
                            children: [
                              LanguageChip(
                                label: s.switchLanguage,
                                onTap: settings.toggleLanguage,
                              ),
                              const Spacer(),
                              const BrandLogo(size: 42),
                            ],
                          ),
                        ),

                        // ------------------ المصباح المعلّق ------------------
                        Padding(
                          padding: const EdgeInsets.only(top: 0),
                          child: HangingLamp(
                            isOn: lamp.isOn,
                            onToggle: lamp.toggle,
                            width: lampWidth,
                            height: lampHeight,
                            showHint: true,
                            hintText: lamp.isOn
                                ? s.pick('اسحب الخيط لإطفاء المصباح',
                                    'Pull the cord to switch off')
                                : s.pick('اسحب الخيط لتشغيل المصباح',
                                    'Pull the cord to switch on'),
                          ),
                        ),

                        const SizedBox(height: 18),

                        // ------------------ حلقة تسجيل الدخول ------------------
                        _LoginCircle(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                s.loginTitle,
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 21,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                s.loginSubtitle,
                                style: const TextStyle(
                                  fontFamily: AppTheme.fontFamily,
                                  fontSize: 11.5,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              const SizedBox(height: 14),
                              GoldTextField(
                                controller: _username,
                                hint: s.username,
                                icon: Icons.person_outline_rounded,
                                textInputAction: TextInputAction.next,
                              ),
                              const SizedBox(height: 10),
                              GoldTextField(
                                controller: _password,
                                hint: s.password,
                                icon: Icons.lock_outline_rounded,
                                obscure: true,
                                textInputAction: TextInputAction.done,
                                onSubmitted: (_) => _submit(),
                              ),
                              const SizedBox(height: 10),
                              // تذكّر + نسيت كلمة المرور
                              Row(
                                children: [
                                  _RememberToggle(
                                    value: _remember,
                                    label: s.rememberMe,
                                    onChanged: (v) =>
                                        setState(() => _remember = v),
                                  ),
                                  const Spacer(),
                                  GestureDetector(
                                    onTap: _forgotPassword,
                                    child: Text(
                                      s.forgotPassword,
                                      style: const TextStyle(
                                        fontFamily: AppTheme.fontFamily,
                                        fontSize: 11.5,
                                        fontWeight: FontWeight.w600,
                                        color: AppColors.gold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),
                              GoldButton(
                                label: s.loginButton,
                                loading: _loading,
                                height: 48,
                                onPressed: _loading ? null : _submit,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        buildRegisterLink(context, s),

                        const SizedBox(height: 10),
                        Text(
                          s.isArabic
                              ? 'حساب تجريبي: ahmed / 1234'
                              : 'Demo account: ahmed / 1234',
                          style: const TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 10.5,
                            color: AppColors.textMuted,
                          ),
                        ),
                        const SizedBox(height: 18),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget buildRegisterLink(BuildContext context, AppStrings s) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          s.noAccount,
          style: const TextStyle(
            fontFamily: AppTheme.fontFamily,
            fontSize: 12.5,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(width: 6),
        GestureDetector(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const RegisterScreen()),
          ),
          child: Text(
            s.registerNow,
            style: const TextStyle(
              fontFamily: AppTheme.fontFamily,
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: AppColors.goldLight,
              decoration: TextDecoration.underline,
              decorationColor: AppColors.gold,
            ),
          ),
        ),
      ],
    );
  }
}

/// ---------------------------------------------------------------------------
///  الحلقة الدائرية الكبيرة التي تحتوي نموذج الدخول
/// ---------------------------------------------------------------------------
class _LoginCircle extends StatelessWidget {
  const _LoginCircle({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final diameter =
            (constraints.maxWidth * 0.94).clamp(280.0, 400.0).toDouble();
        return SizedBox(
          width: diameter,
          height: diameter,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // الخلفية الدائرية + الإطار
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFF1B1510).withOpacity(0.96),
                      const Color(0xFF0D0A08).withOpacity(0.92),
                    ],
                  ),
                  border: Border.all(
                    color: AppColors.gold.withOpacity(0.22),
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.gold.withOpacity(0.12),
                      blurRadius: 40,
                      spreadRadius: 4,
                    ),
                  ],
                ),
              ),
              // حلقة داخلية باهتة
              Container(
                width: diameter * 0.86,
                height: diameter * 0.86,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.gold.withOpacity(0.07),
                    width: 1,
                  ),
                ),
              ),
              // مقابض جانبية ديكورية (كما في التصميم)
              Positioned(
                left: diameter * 0.015,
                top: diameter * 0.46,
                child: const _Knob(height: 26),
              ),
              Positioned(
                left: diameter * 0.015,
                top: diameter * 0.60,
                child: const _Knob(height: 20),
              ),
              // المحتوى
              Padding(
                padding: EdgeInsets.symmetric(horizontal: diameter * 0.11),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: SizedBox(width: diameter * 0.70, child: child),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Knob extends StatelessWidget {
  const _Knob({required this.height});
  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 4,
      height: height,
      decoration: BoxDecoration(
        color: AppColors.goldBorder,
        borderRadius: BorderRadius.circular(3),
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
///  مفتاح "تذكّر" الدائري
/// ---------------------------------------------------------------------------
class _RememberToggle extends StatelessWidget {
  const _RememberToggle({
    required this.value,
    required this.label,
    required this.onChanged,
  });

  final bool value;
  final String label;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onChanged(!value),
      behavior: HitTestBehavior.opaque,
      child: Row(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 18,
            height: 18,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: value ? AppColors.gold : Colors.transparent,
              border: Border.all(
                color: value ? AppColors.goldLight : AppColors.textMuted,
                width: 1.4,
              ),
              boxShadow: value
                  ? [
                      BoxShadow(
                        color: AppColors.gold.withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ]
                  : null,
            ),
            child: value
                ? const Icon(Icons.check_rounded,
                    size: 12, color: Color(0xFF2A1B08))
                : null,
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              fontFamily: AppTheme.fontFamily,
              fontSize: 11.5,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
