import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/ui_helpers.dart';
import '../../data/models/models.dart';
import '../../services/export_service.dart';
import '../../state/energy_controller.dart';
import '../../state/session_controller.dart';
import '../../state/support_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/charts.dart';
import '../../widgets/gold_widgets.dart';
import '../../widgets/segmented_tabs.dart';
import '../../widgets/stat_card.dart';
import '../analysis/analysis_screen.dart';
import '../notifications/notifications_screen.dart';

/// ============================================================================
///  الصفحة الرئيسية: الرصيد + الحمل + الإحصاءات + تحليل الاستهلاك + العمليات
/// ============================================================================
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, this.now});

  /// وقت ثابت للعرض (يُستخدم في الاختبارات لتثبيت التاريخ؛ الافتراضي: الآن)
  final DateTime? now;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final energy = context.watch<EnergyController>();
    final session = context.watch<SessionController>();
    final support = context.watch<SupportController>();
    final meter = energy.selectedMeter;

    return RefreshIndicator(
      color: AppColors.gold,
      backgroundColor: AppColors.cardAlt,
      onRefresh: () async {
        await energy.load();
        await support.load();
      },
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          // ------------------------- الترويسة -------------------------
          HomeHeader(
            greeting: s.welcome,
            name: session.user?.name.split(' ').first ?? '—',
            unread: support.unreadCount,
            onAvatarTap: () => Scaffold.of(context).openDrawer(),
            onNotifications: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const NotificationsScreen()),
            ),
          ),
          const SizedBox(height: 12),
          DateChip(
            label: Fmt.headerDate(now ?? DateTime.now(), arabic: s.isArabic),
          ),
          const SizedBox(height: 14),

          // ------------------------- بطاقة الرصيد -------------------------
          GoldCard(
            glow: true,
            padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
            child: Row(
              children: [
                MeterIsoGlyph(
                  size: 84,
                  connected: meter?.connected ?? false,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              s.balance,
                              style: const TextStyle(
                                fontFamily: AppTheme.fontFamily,
                                fontSize: 11.5,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ),
                          LiveBadge(
                            label: meter?.connected ?? false
                                ? s.meterConnected
                                : s.pick('غير متصل', 'Disconnected'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            Fmt.number(meter?.balance ?? 0),
                            style: const TextStyle(
                              fontFamily: AppTheme.numberFontFamily,
                              fontSize: 30,
                              fontWeight: FontWeight.w700,
                              height: 1.05,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Text(
                              s.currency,
                              style: const TextStyle(
                                fontFamily: AppTheme.fontFamily,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: AppColors.gold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          const Icon(Icons.bolt_rounded,
                              size: 13, color: AppColors.gold),
                          const SizedBox(width: 3),
                          Text(
                            '${s.currentLoad} ${Fmt.oneDecimal(meter?.currentLoadKw ?? 0)} ${s.kwh}',
                            style: const TextStyle(
                              fontFamily: AppTheme.fontFamily,
                              fontSize: 11,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // ------------------------- بطاقات الإحصاء -------------------------
          Row(
            children: [
              Expanded(
                child: StatCard(
                  label: s.upcomingOutage,
                  value: '11',
                  unit: s.isArabic ? 'يوم' : 'days',
                  icon: Icons.calendar_today_rounded,
                  sparkValues: const [4, 5, 4.5, 5.6, 5.0, 6.0, 5.4],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: StatCard(
                  label: s.remainingEnergy,
                  value: Fmt.oneDecimal(meter?.remainingKwh ?? 0),
                  unit: s.kwh,
                  icon: Icons.bolt_rounded,
                  sparkValues: const [3.0, 4.0, 3.6, 5.0, 6.2, 5.5, 6.6],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // ------------------------- أزرار سريعة -------------------------
          Row(
            children: [
              Expanded(
                child: GoldOutlineButton(
                  label: s.downloadData,
                  icon: Icons.download_rounded,
                  expand: true,
                  height: 44,
                  onPressed: () => _exportData(context, energy, s),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GoldOutlineButton(
                  label: s.shareUsage,
                  icon: Icons.share_rounded,
                  expand: true,
                  height: 44,
                  onPressed: () => _shareUsage(context, energy, s),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // ------------------------- تحليل الاستهلاك -------------------------
          GoldCard(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
            child: Column(
              children: [
                Row(
                  children: [
                    _DatePickChip(
                        label: s.pickDate, onTap: () => _pickDate(context)),
                    const Spacer(),
                    Text(
                      s.consumptionAnalysis,
                      style: const TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SegmentedTabs(
                  labels: [s.hours, s.days, s.months],
                  index: energy.range.index,
                  onChanged: (i) => energy.setRange(ConsumptionRange.values[i]),
                ),
                const SizedBox(height: 10),
                LineAreaChart(
                  current: energy.summary?.currentPeriod ?? const [],
                  previous: energy.summary?.previousPeriod ?? const [],
                  height: 170,
                  yTicks: _ticksFor(energy),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    _Legend(
                      color: AppColors.gold,
                      label: s.currentPeriod,
                      filled: true,
                    ),
                    const SizedBox(width: 12),
                    _Legend(
                        color: const Color(0xFFB9B2A6), label: s.lastPeriod),
                    const Spacer(),
                    Text(
                      '${s.thisMonthTotal} ${Fmt.oneDecimal(energy.summary?.totalKwh ?? 0)}',
                      style: const TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: 11,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                GoldOutlineButton(
                  label: s.seeFullAnalysis,
                  icon: Icons.insights_rounded,
                  expand: true,
                  height: 42,
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const AnalysisScreen()),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // ------------------------- أحدث العمليات -------------------------
          SectionHeader(
            title: s.latestOperations,
            actionLabel: s.seeAll,
            actionIcon: Icons.arrow_left_rounded,
            onAction: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const NotificationsScreen()),
            ),
          ),
          const SizedBox(height: 8),
          ...support.notifications.take(3).map(
                (n) => _OperationRow(notification: n),
              ),
          const SizedBox(height: 10),
          const DemoBadge(),
        ],
      ),
    );
  }

  List<double> _ticksFor(EnergyController energy) {
    switch (energy.range) {
      case ConsumptionRange.hours:
        return const [0, 1, 2, 3];
      case ConsumptionRange.days:
        return const [0, 2, 4, 7];
      case ConsumptionRange.months:
        return const [0, 50, 100, 160];
    }
  }

  Future<void> _pickDate(BuildContext context) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 1),
      lastDate: now,
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.dark(
            primary: AppColors.gold,
            onPrimary: Color(0xFF2A1B08),
            surface: AppColors.card,
            onSurface: AppColors.textPrimary,
          ),
          datePickerTheme: const DatePickerThemeData(
            backgroundColor: AppColors.card,
            headerBackgroundColor: AppColors.cardAlt,
            headerForegroundColor: AppColors.goldLight,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null && context.mounted) {
      showAppSnack(
        context,
        '${AppStrings.of(context).pickDate}: ${Fmt.shortDate(picked)}',
        success: true,
      );
    }
  }

  Future<void> _exportData(
    BuildContext context,
    EnergyController energy,
    AppStrings s,
  ) async {
    final rows = <List<String>>[
      ['label', 'kwh'],
      for (final p in energy.summary?.currentPeriod ?? <ConsumptionPoint>[])
        [p.label, p.value.toStringAsFixed(1)],
    ];
    final path = await ExportService.saveCsv(rows, 'alwas_consumption.csv');
    if (!context.mounted) return;
    showAppSnack(
      context,
      path == null ? s.receiptSaveFailed : '${s.exportReady}\n$path',
      success: path != null,
      error: path == null,
    );
  }

  Future<void> _shareUsage(
    BuildContext context,
    EnergyController energy,
    AppStrings s,
  ) async {
    final summary = energy.summary;
    final text = s.isArabic
        ? 'استهلاكي هذا الشهر: ${Fmt.oneDecimal(summary?.totalKwh ?? 0)} كيلوواط\n'
            'الرصيد الحالي: ${Fmt.number(energy.selectedMeter?.balance ?? 0)} ر.ي\n'
            'من تطبيق ${s.appName}'
        : 'My usage this month: ${Fmt.oneDecimal(summary?.totalKwh ?? 0)} kWh\n'
            'Current balance: ${Fmt.number(energy.selectedMeter?.balance ?? 0)} YER\n'
            'From ${s.appName} app';
    await ExportService.shareText(text);
  }
}

// ---------------------------------------------------------------------------
//  عناصر مساعدة داخل الصفحة
// ---------------------------------------------------------------------------
class _DatePickChip extends StatelessWidget {
  const _DatePickChip({required this.label, required this.onTap});

  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.field,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.goldBorder),
        ),
        child: Row(
          children: [
            Text(
              label,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 10.5,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(width: 4),
            const Icon(Icons.calendar_month_rounded,
                size: 12, color: AppColors.gold),
          ],
        ),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend(
      {required this.color, required this.label, this.filled = false});

  final Color color;
  final String label;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 7,
          height: 7,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: filled ? color : Colors.transparent,
            border: Border.all(color: color, width: 1.2),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: const TextStyle(
            fontFamily: AppTheme.fontFamily,
            fontSize: 10,
            color: AppColors.textMuted,
          ),
        ),
      ],
    );
  }
}

class _OperationRow extends StatelessWidget {
  const _OperationRow({required this.notification});

  final AppNotification notification;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final isRecharge = notification.kind == NotificationKind.recharge;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: AppColors.card.withOpacity(0.65),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.goldDivider),
      ),
      child: Row(
        children: [
          GoldIconBox(
            icon: isRecharge ? Icons.bolt_rounded : Icons.campaign_outlined,
            size: 34,
            color: isRecharge ? AppColors.goldLight : AppColors.info,
            radius: 11,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  notification.title.resolve(arabic: s.isArabic),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  notification.body.resolve(arabic: s.isArabic),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 10.5,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            Fmt.shortDate(notification.date),
            style: const TextStyle(
              fontFamily: AppTheme.fontFamily,
              fontSize: 10,
              color: AppColors.textMuted,
            ),
          ),
        ],
      ),
    );
  }
}
