import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/models.dart';
import '../../widgets/gold_widgets.dart';
import '../invoices/receipt_details_screen.dart';

/// ============================================================================
///  شاشة نجاح الشحن — تعرض ملخّص العملية وتفتح الإيصال
/// ============================================================================
class PaymentSuccessScreen extends StatefulWidget {
  const PaymentSuccessScreen({super.key, required this.receipt});

  final ReceiptModel receipt;

  @override
  State<PaymentSuccessScreen> createState() => _PaymentSuccessScreenState();
}

class _PaymentSuccessScreenState extends State<PaymentSuccessScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..forward();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final r = widget.receipt;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.5),
            radius: 1.1,
            colors: [Color(0xFF231A0F), AppColors.background],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ScaleTransition(
                  scale: CurvedAnimation(
                      parent: _controller, curve: Curves.elasticOut),
                  child: Container(
                    width: 108,
                    height: 108,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          AppColors.success.withOpacity(0.28),
                          AppColors.success.withOpacity(0.05),
                        ],
                      ),
                      border: Border.all(
                        color: AppColors.success.withOpacity(0.6),
                        width: 1.4,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.success.withOpacity(0.28),
                          blurRadius: 34,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.check_rounded,
                        size: 56, color: AppColors.success),
                  ),
                ),
                const SizedBox(height: 22),
                Text(
                  s.topUpSuccessTitle,
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  r.receiptNumber,
                  style: const TextStyle(
                    fontFamily: AppTheme.numberFontFamily,
                    fontSize: 13,
                    letterSpacing: 1.2,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 20),
                GoldCard(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  glow: true,
                  child: Column(
                    children: [
                      InfoRow(
                        label: s.chargedAmount,
                        value: Fmt.currency(r.amount, s.currency,
                            arabic: s.isArabic),
                        valueColor: AppColors.gold,
                      ),
                      InfoRow(
                        label: s.energyAdded,
                        value: '${Fmt.oneDecimal(r.kwh)} ${s.kwh}',
                      ),
                      InfoRow(
                        label: s.newBalance,
                        value: Fmt.currency(r.balanceAfter, s.currency,
                            arabic: s.isArabic),
                      ),
                      InfoRow(
                        label: s.paymentMethod,
                        value: r.methodName.resolve(arabic: s.isArabic),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                GoldButton(
                  label: s.viewReceipt,
                  icon: Icons.receipt_long_rounded,
                  onPressed: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (_) => ReceiptDetailsScreen(receipt: r),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                GoldOutlineButton(
                  label: s.backHome,
                  icon: Icons.home_rounded,
                  expand: true,
                  onPressed: () =>
                      Navigator.of(context).popUntil((route) => route.isFirst),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
