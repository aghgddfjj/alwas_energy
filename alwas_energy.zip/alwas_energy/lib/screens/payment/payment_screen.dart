import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/ui_helpers.dart';
import '../../state/energy_controller.dart';
import '../../state/session_controller.dart';
import '../../state/support_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/charts.dart';
import '../../widgets/gold_widgets.dart';
import '../../widgets/segmented_tabs.dart';
import '../../widgets/stat_card.dart';
import '../notifications/notifications_screen.dart';
import 'payment_success_screen.dart';

/// ============================================================================
///  صفحة الدفع والشحن
///  اختيار العداد ← اختيار طريقة الدفع ← بيانات التسديد ← المبلغ ← تأكيد الشحن
///  ملاحظة: الشحن هنا محاكاة (MockAppRepository) ولا يخصم أي مبلغ حقيقي.
/// ============================================================================
class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key, this.now});

  /// وقت ثابت للعرض (للاختبارات)
  final DateTime? now;

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final _amountController = TextEditingController(text: '5000');
  int _meterType = 0; // 0 = عدادي، 1 = عداد آخر

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _confirmTopUp() async {
    final s = AppStrings.of(context);
    final energy = context.read<EnergyController>();
    final amount = double.tryParse(_amountController.text.trim()) ?? 0;
    if (amount < 500) {
      showAppSnack(context, s.minAmount, error: true);
      return;
    }
    if (energy.selectedMethod == null || energy.selectedMeter == null) {
      showAppSnack(context, s.noPaymentMethod, error: true);
      return;
    }
    final ok = await showConfirmDialog(
      context,
      title: s.confirmTopUpTitle,
      body:
          '${s.confirmTopUpBody}\n\n${s.amount}: ${Fmt.number(amount)} ${s.currency}\n'
          '${s.meterNumberLabel}: ${energy.selectedMeter!.number}\n'
          '${s.paymentMethod}: ${energy.selectedMethod!.name.resolve(arabic: s.isArabic)}',
      confirmLabel: s.confirm,
      cancelLabel: s.cancel,
    );
    if (!ok || !mounted) return;

    final receipt = await energy.topUp(amount);
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PaymentSuccessScreen(receipt: receipt)),
    );
  }

  Future<void> _chooseOtherMeter() async {
    final s = AppStrings.of(context);
    final controller = TextEditingController();
    final energy = context.read<EnergyController>();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.otherMeter),
        content: GoldTextField(
          controller: controller,
          hint: s.meterNumberLabel,
          icon: Icons.speed_rounded,
          keyboardType: TextInputType.number,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(s.cancel,
                style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () {
              final found =
                  energy.meters.any((m) => m.number == controller.text.trim());
              Navigator.of(ctx).pop();
              if (found) {
                energy.selectMeterByNumber(controller.text.trim());
                setState(() => _meterType = 0);
                showAppSnack(
                    context, '${s.meterNumberLabel}: ${controller.text.trim()}',
                    success: true);
              } else {
                showAppSnack(context, s.noInvoices, error: true);
              }
            },
            child: Text(s.confirm,
                style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontWeight: FontWeight.w700,
                    color: AppColors.gold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final energy = context.watch<EnergyController>();
    final session = context.watch<SessionController>();
    final support = context.watch<SupportController>();
    final meter = energy.selectedMeter;
    final method = energy.selectedMethod;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
      children: [
        HomeHeader(
          greeting: s.welcome,
          name: session.user?.name.split(' ').first ?? '—',
          unread: support.unreadCount,
          onAvatarTap: () => Scaffold.of(context).openDrawer(),
          onNotifications: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const NotificationsScreen()),
          ),
        ),
        const SizedBox(height: 12),
        DateChip(
          label:
              Fmt.headerDate(widget.now ?? DateTime.now(), arabic: s.isArabic),
        ),
        const SizedBox(height: 14),

        // ---------------------- نوع العداد ----------------------
        SegmentedWide(
          labels: [s.myMeter, s.otherMeter],
          index: _meterType,
          onChanged: (i) {
            setState(() => _meterType = i);
            if (i == 1) {
              _chooseOtherMeter();
            } else if (energy.meters.isNotEmpty) {
              energy.selectMeter(0);
            }
          },
        ),
        const SizedBox(height: 10),

        // ---------------------- أرقام العدادات ----------------------
        if (energy.meters.length > 1)
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              for (var i = 0; i < energy.meters.length; i++)
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: GestureDetector(
                    onTap: () => energy.selectMeter(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        gradient: i == energy.selectedMeterIndex
                            ? AppColors.goldGradient
                            : null,
                        color: i == energy.selectedMeterIndex
                            ? null
                            : AppColors.cardAlt.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: i == energy.selectedMeterIndex
                              ? AppColors.goldLight
                              : AppColors.goldBorder,
                        ),
                      ),
                      child: Text(
                        energy.meters[i].number,
                        style: TextStyle(
                          fontFamily: AppTheme.numberFontFamily,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: i == energy.selectedMeterIndex
                              ? const Color(0xFF2A1B08)
                              : AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        const SizedBox(height: 12),

        // ---------------------- بطاقة العداد المراد شحنه ----------------------
        GoldCard(
          glow: true,
          padding: const EdgeInsets.fromLTRB(14, 16, 14, 14),
          child: Row(
            children: [
              BatteryGlyph(size: 78, level: meter?.capRatio ?? 0.5),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      s.meterToCharge,
                      style: const TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: 11.5,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    MeterDigits(number: meter?.number ?? '0000000'),
                    const SizedBox(height: 10),
                    RichText(
                      textDirection: TextDirection.rtl,
                      text: TextSpan(
                        text: '${s.balance}: ',
                        style: const TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          fontSize: 11.5,
                          color: AppColors.textSecondary,
                        ),
                        children: [
                          TextSpan(
                            text: Fmt.currency(meter?.balance ?? 0, s.currency,
                                arabic: s.isArabic),
                            style: const TextStyle(
                              fontFamily: AppTheme.fontFamily,
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.gold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${s.chargeVia} ${method?.name.resolve(arabic: s.isArabic) ?? ''}',
                      style: const TextStyle(
                        fontFamily: AppTheme.fontFamily,
                        fontSize: 11,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // ---------------------- طرق الدفع ----------------------
        SectionHeader(title: s.chooseTransfer),
        const SizedBox(height: 8),
        Row(
          children: [
            for (var i = 0; i < energy.methods.length; i++) ...[
              Expanded(
                child: MethodTile(
                  label: energy.methods[i].name.resolve(arabic: s.isArabic),
                  color: Color(energy.methods[i].colorValue),
                  selected: i == energy.selectedMethodIndex,
                  icon: _methodIcon(energy.methods[i].id),
                  onTap: () => energy.selectMethod(i),
                ),
              ),
              if (i != energy.methods.length - 1) const SizedBox(width: 8),
            ],
          ],
        ),
        const SizedBox(height: 16),

        // ---------------------- بيانات التسديد ----------------------
        GoldCard(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(Icons.assignment_outlined,
                      size: 16, color: AppColors.gold),
                  const SizedBox(width: 6),
                  Text(
                    s.paymentData,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              CopyField(
                label: s.stationWallet,
                value: method?.walletNumber ?? '—',
                copyLabel: s.copy,
                onCopy: () => showAppSnack(context, s.copied, success: true),
              ),
              const SizedBox(height: 10),
              CopyField(
                label: s.meterNumberNote,
                value: meter?.number ?? '—',
                copyLabel: s.copy,
                onCopy: () => showAppSnack(context, s.copied, success: true),
              ),
              const SizedBox(height: 14),
              const GoldDivider(opacity: 0.8),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  '${s.howToPayJaib} ${method?.name.resolve(arabic: s.isArabic) ?? ''}',
                  style: const TextStyle(
                    fontFamily: AppTheme.fontFamily,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              ...List.generate(
                method?.steps.length ?? 0,
                (i) => _StepRow(
                  index: i + 1,
                  text: method!.steps[i].resolve(arabic: s.isArabic),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // ---------------------- المبلغ والتأكيد ----------------------
        GoldCard(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(Icons.payments_outlined,
                      size: 16, color: AppColors.gold),
                  const SizedBox(width: 6),
                  Text(
                    s.amount,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    s.minAmount,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 10,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              GoldTextField(
                controller: _amountController,
                hint: '5000',
                icon: Icons.payments_outlined,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: false),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Text(
                    s.quickAmounts,
                    style: const TextStyle(
                      fontFamily: AppTheme.fontFamily,
                      fontSize: 11,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  for (final amount in [1000, 3000, 5000, 10000]) ...[
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _amountController.text = '$amount';
                          });
                          HapticFeedback.selectionClick();
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          padding: const EdgeInsets.symmetric(vertical: 9),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppColors.field,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _amountController.text == '$amount'
                                  ? AppColors.gold
                                  : AppColors.goldBorder,
                            ),
                          ),
                          child: Text(
                            Fmt.number(amount),
                            style: TextStyle(
                              fontFamily: AppTheme.numberFontFamily,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: _amountController.text == '$amount'
                                  ? AppColors.goldLight
                                  : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 14),
              GoldButton(
                label: s.confirmTopUp,
                icon: Icons.bolt_rounded,
                loading: energy.topUpBusy,
                onPressed: energy.topUpBusy ? null : _confirmTopUp,
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const DemoBadge(),
      ],
    );
  }
}

/// أيقونة كل محفظة (تُطابق هوية الشعار في التصميم المرجعي)
IconData _methodIcon(String id) {
  switch (id) {
    case 'jaib':
      return Icons.account_balance_wallet_rounded;
    case 'jawali':
      return Icons.phone_iphone_rounded;
    case 'floosak':
      return Icons.payments_rounded;
    default:
      return Icons.account_balance_wallet_rounded;
  }
}

/// صف خطوة مرقّمة في تعليمات التسديد
class _StepRow extends StatelessWidget {
  const _StepRow({required this.index, required this.text});

  final int index;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 19,
            height: 19,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.gold.withOpacity(0.14),
              border: Border.all(color: AppColors.gold.withOpacity(0.55)),
            ),
            child: Text(
              '$index',
              style: const TextStyle(
                fontFamily: AppTheme.numberFontFamily,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: AppColors.goldLight,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 12,
                height: 1.6,
                color: AppColors.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
