# الوس للطاقة — تطبيق أندرويد كامل (Flutter + Java + Gradle)

> تطبيق شحن العدادات الكهربائية ومتابعة الاستهلاك، بهوية بصرية **ذهبية على خلفية سوداء مائلة للبني**،
> مع **مصباح معلّق تفاعلي** يُشغَّل ويُطفأ بسحب الخيط.
>
> هذا المشروع **كود حقيقي كامل** (وليس صوراً أو واجهات تجريبية): كل عنصر في الشاشات مبني بـ `Widgets`
> و`CustomPainter`، وكل زر يعمل، والبيانات التجريبية تأتي من طبقة `Repository` يمكن استبدالها بخدمة حقيقية.

---

## المحتويات

1. [لمحة سريعة](#1-لمحة-سريعة)
2. [الشاشات](#2-الشاشات)
3. [المصباح المعلّق (التفاعل بالخيط)](#3-المصباح-المعلّق-التفاعل-بالخيط)
4. [المتطلبات والتشغيل](#4-المتطلبات-والتشغيل)
5. [بنية المشروع وشرح كل ملف](#5-بنية-المشروع-وشرح-كل-ملف)
6. [المكتبات وإصداراتها وطريقة إضافتها](#6-المكتبات-وإصداراتها-وطريقة-إضافتها)
7. [تعديل الألوان والتصميم](#7-تعديل-الألوان-والتصميم)
8. [إضافة صفحة جديدة](#8-إضافة-صفحة-جديدة)
9. [استخراج ملف APK](#9-استخراج-ملف-apk) — محلياً **أو من الهاتف بدون كمبيوتر**
10. [ربط قاعدة بيانات وخدمات حقيقية](#10-ربط-قاعدة-بيانات-وخدمات-حقيقية)
11. [الاختبارات وصور المعاينة](#11-الاختبارات-وصور-المعاينة)
12. [ملاحظات مهمة وحدود النسخة الحالية](#12-ملاحظات-مهمة-وحدود-النسخة-الحالية)

---

## 1) لمحة سريعة

| العنصر | القيمة |
|---|---|
| اسم الحزمة (applicationId) | `com.alwas.alwas_energy` |
| اسم التطبيق على الجهاز | الوس للطاقة |
| لغة الواجهة | عربية (RTL) + إنجليزية (LTR) — تبديل فوري |
| الواجهة | Flutter (Dart) — Material 3 مخصّص بالكامل |
| الأجزاء الأصلية | Java (`MainActivity.java`) + قناة `MethodChannel` |
| البناء | Gradle (AGP 8.1، JDK 17، minSdk 23، target/compile 34) |
| الخطوط | Tajawal (5 أوزان) + Cairo Variable — مضمّنة داخل المشروع |
| البيانات | تجريبية (Mock) عبر `MockAppRepository` — جاهزة للاستبدال بخدمة حقيقية |

### الهوية البصرية (كما في التصميم المرجعي)

- خلفية: `#0B0906` (أسود مائل للبني) مع تدرّجات بنية خفيفة.
- ذهبي/عسلي: `#FFC96B` → `#E8A33D` → `#B9741C`.
- بطاقات: `#15110D` بإطار ذهبي رفيع `#3A2C1B` وزوايا ناعمة (22px).
- نصوص: أبيض دافئ `#F6F1E7` + ثانوي `#A79A89`.
- تأثيرات: توهّج ذهبي هادئ، ظلال ناعمة، حركات سلسة.

> 📸 صورة تجميعية لكل الشاشات: **`docs/screens_preview.png`**

---

## 2) الشاشات

| # | الشاشة | الملف | أهم ما فيها |
|---|---|---|---|
| 1 | تسجيل الدخول | `lib/screens/login_screen.dart` | المصباح المعلّق + حلقة دخول دائرية + إظهار/إخفاء كلمة المرور + تذكّر + نسيت كلمة المرور + تبديل اللغة |
| 2 | إنشاء حساب | `lib/screens/register_screen.dart` | تحقق كامل من المدخلات + الموافقة على الشروط |
| 3 | قفل التطبيق بالبصمة | `lib/screens/lock_screen.dart` | حلقة ذهبية دوّارة + `local_auth` + بديل عند عدم توفر البصمة |
| 4 | الصفحة الرئيسية | `lib/screens/home/home_screen.dart` | الرصيد + الحمل الحالي + انقطاع قريب + الطاقة المتبقية + تحليل الاستهلاك + أحدث العمليات |
| 5 | الدفع والشحن | `lib/screens/payment/payment_screen.dart` | نوع العداد، أرقام العدادات (1 0 0 0 0 0 1)، البطارية، 3 محافظ، بيانات التسديد بالنسخ، خطوات، المبلغ، تأكيد الشحن |
| 6 | نجاح الشحن | `lib/screens/payment/payment_success_screen.dart` | ملخّص العملية + الانتقال للإيصال |
| 7 | الفواتير والشحنات | `lib/screens/invoices/invoices_screen.dart` | ملخص (إجمالي/عدد) + رسم أعمدة ومنحنى + سجل كامل |
| 8 | تفاصيل الإيصال | `lib/screens/invoices/receipt_details_screen.dart` | إيصال بشكل تذكرة + QR حقيقي + باركود + حفظ كصورة + مشاركة + إنشاء بلاغ |
| 9 | الدعم والتشخيص الذكي | `lib/screens/support/support_screen.dart` | كرة متوهجة متحركة، تشخيص سريع بأربعة أزرار، سجل تذاكر بمسار حالة، إنشاء تذكرة |
| 10 | تحليل الاستهلاك | `lib/screens/analysis/analysis_screen.dart` | مؤشرات (إجمالي/متوسط/أعلى/تكلفة) + رسم خطي + جدول تفاصيل |
| 11 | الإعدادات | `lib/screens/settings/settings_screen.dart` | بطاقة المشترك الذهبية، السقف الشهري (حلقة 36% + شريط تمرير)، الإشعارات، القفل بالبصمة، معاينة القفل، تغيير كلمة المرور، اللغة، عن التطبيق، خروج |
| 12 | القائمة الجانبية | `lib/widgets/app_drawer.dart` | صورة + اسم + @اسم + عدادات + حسابي/إشعارات/دعم/إعدادات + شريحة اللغة |
| 13 | الإشعارات | `lib/screens/notifications/notifications_screen.dart` | تصنيف بالألوان (شحن/صيانة/تعرفة/انقطاع) + تحديد الكل كمقروء |
| 14 | حسابي | `lib/screens/account/account_screen.dart` | تعديل البيانات فعلياً + العدادات المرتبطة |
| 15 | تغيير كلمة المرور | `lib/screens/settings/change_password_screen.dart` | تحقق كامل |
| 16 | شاشة البداية | `lib/screens/splash_screen.dart` | شعار متوهّج + حلقة تحميل |

كل الشاشات مترابطة: التنقل عبر `Navigator`، والشريط السفلي (`الرئيسية / الدفع / الفواتير`) عبر
`lib/screens/main_shell.dart` مع `IndexedStack` للحفاظ على حالة كل صفحة.

---

## 3) المصباح المعلّق (التفاعل بالخيط)

الملف: **`lib/widgets/hanging_lamp.dart`** — كل شيء مرسوم برمجياً بـ `CustomPainter`
(لا صورة ولا ملف Lottie)، لذلك يبقى حاداً على أي حجم شاشة وخفيفاً على الأداء.

### ما يفعله

| المطلوب | التنفيذ |
|---|---|
| مصباح معلّق بسلك من الأعلى | `_LampBodyPainter`: سلك + قاعدة سقف + وصلة + مظلّة (شيد) |
| خيط صغير متدلٍ بجانب المصباح | خيط رفيع ينتهي بحبّة ذهبية مرسومة داخل نفس الـ painter |
| سحب الخيط للأسفل باللمس يُطفئ المصباح | `onVerticalDragUpdate` يحرّك الخيط (0..1) |
| السحب مرة أخرى يُضيء | عند تجاوز 45% من السحب أو سرعة > 320px/s يتم `onToggle` |
| الشاشة تصبح مظلمة عند الانطفاء مع بقاء النصوص واضحة | `LampAmbience` (طبقة تعتيم دافئة 65% شفافة بتدرّج) |
| إضاءة ذهبية دافئة تنتشر تدريجياً عند التشغيل | `_glow` AnimationController (750ms) يتدرّج من 0 إلى 1 ويشغّل الشعاع |
| حركة واقعية للخيط والمصباح عند السحب | ارتداد `Curves.elasticOut` بعد السحب + تمايل مستمر `sin()` + زيادة سعة التمايل أثناء السحب |
| تشغيل/إطفاء سلس وجميل | انتقال 750ms لمنحنى الشدة + `AnimatedOpacity` للتعتيم + اهتزاز خفيف `HapticFeedback` |

### أين يُستخدم

- `LoginScreen` (المصباح كبير فوق حلقة الدخول) و`RegisterScreen` (نسخة أصغر).
- الحالة محفوظة في `LampController` وتُخزَّن في `SharedPreferences` (يبقى المصباح كما تركه المستخدم).

### ضبط الإحساس بالسحب

```dart
// lib/widgets/hanging_lamp.dart
_dragStartValue = (_dragStartValue + details.delta.dy / 46).clamp(0.0, 1.0);
//                                                 ↑ غيّر 46 لتصبح السحبة أسهل/أصعب

final shouldToggle = _pull.value > 0.45 || details.velocity.pixelsPerSecond.dy > 320;
//                                   ↑ نسبة السحب المطلوبة        ↑ سرعة السحب
```

### إضافة المصباح إلى شاشة جديدة

```dart
final lamp = context.watch<LampController>();

LampAmbience(               // يعتّم الشاشة تلقائياً عند الإطفاء
  isOn: lamp.isOn,
  child: HangingLamp(
    isOn: lamp.isOn,
    onToggle: lamp.toggle,
    width: MediaQuery.of(context).size.width * 0.7,
    height: 280,
    showHint: true,
    hintText: 'اسحب الخيط لتشغيل/إطفاء المصباح',
  ),
)
```

> لمس اللمبة نفسها يبدّل المصباح أيضاً (اختصار للمستخدم).

---

## 4) المتطلبات والتشغيل

### المتطلبات

| الأداة | الإصدار الموصى به |
|---|---|
| Flutter SDK | 3.24.x أو أحدث (Dart 3.5+) |
| Android SDK | Platform 34 + Build-Tools 34 |
| JDK | 17 (مطلوب من AGP 8) |
| Android Studio | Ladybug أو أحدث (اختياري) |

### خطوات التشغيل

```bash
# 1) فك المشروع وفتح المجلد
cd alwas_energy

# 2) تحميل المكتبات
flutter pub get

# 3) فحص الأخطاء (يجب أن يعطي: No issues found!)
flutter analyze

# 4) تشغيل على جهاز/محاكي موصول
flutter devices
flutter run

# 5) بناء نسخة للتجربة
flutter build apk --debug
```

### بيانات الدخول التجريبية

```
اسم المستخدم: ahmed
كلمة المرور : 1234
```

> زر «القفل بالبصمة» يعمل على جهاز فيه بصمة مسجّلة. على المحاكي (بدون بصمة) تُرجع الخدمة
> `unavailable` ويُفتح القفل تلقائياً مع رسالة توضيحية — السلوك مقصود للتجربة.

---

## 5) بنية المشروع وشرح كل ملف

```
alwas_energy/
├── pubspec.yaml                  # الحزم + الخطوط + الأصول + الإصدار
├── analysis_options.yaml         # قواعد التحليل (flutter_lints)
├── README.md                     # هذا الملف
├── BUILD_GUIDE.md                # ★ دليل بناء APK من الهاتف (Codemagic / GitHub Actions)
├── codemagic.yaml                # ★ إعداد البناء السحابي على Codemagic (Release APK + AAB)
├── .github/workflows/build-apk.yml  # ★ بديل مجاني: بناء APK على GitHub Actions
│
├── android/                      # طبقة أندرويد (Java + Gradle)
│   ├── build.gradle              # إعدادات المشروع الجذرية
│   ├── settings.gradle           # سكربتات AGP/Flutter + include :app
│   ├── gradle.properties         # خصائص Gradle (ذاكرة/AndroidX)
│   ├── gradle/wrapper/…          # Gradle Wrapper 8.3
│   ├── key.properties.example    # مثال بيانات توقيع الإصدار
│   └── app/
│       ├── build.gradle          # applicationId / minSdk / التوقيع / التبعيات
│       ├── proguard-rules.pro    # قواعد R8 (إن فعّلت التصغير)
│       └── src/main/
│           ├── AndroidManifest.xml                   # الصلاحيات + النشاط + RTL
│           ├── java/com/alwas/alwas_energy/
│           │   └── MainActivity.java                 # FlutterFragmentActivity + MethodChannel "alwas/native"
│           └── res/
│               ├── values/{colors,styles}.xml        # ثيم داكن + شاشة إقلاع بدون وميض
│               ├── values-night/styles.xml
│               ├── drawable*/launch_background.xml   # خلفية الإقلاع
│               └── mipmap-*/ic_launcher.png          # أيقونات التطبيق (5 أحجام)
│
├── assets/
│   ├── fonts/                    # Tajawal-Light/Regular/Medium/Bold/ExtraBold + Cairo-Variable
│   ├── images/logo_mark.png      # شعار عالي الدقة (512)
│   └── icons/ic_meter.png        # أيقونة عدّاد
│
├── lib/
│   ├── main.dart                 # تشغيل التطبيق + تسجيل Provider + قفل الاتجاه العمودي
│   ├── app.dart                  # MaterialApp + الثيم + اللغة + RootGate (بوابة البداية)
│   │
│   ├── core/
│   │   ├── theme/app_colors.dart      # ★ كل ألوان المشروع (Design Tokens)
│   │   ├── theme/app_theme.dart       # ★ الثيم: خطوط، حقول، أزرار، حوارات، مسافات
│   │   ├── l10n/app_strings.dart      # ★ كل النصوص عربي/إنجليزي + LocalizationsDelegate
│   │   ├── l10n/localized_text.dart   # نوع L (نص ثنائي اللغة داخل البيانات)
│   │   └── utils/
│   │       ├── formatters.dart        # تنسيق الأرقام (18,500) والتواريخ (الأربعاء، 28 أكتوبر)
│   │       └── ui_helpers.dart        # SnackBar/Dialog/BottomSheet/اهتزاز
│   │
│   ├── data/
│   │   ├── models/models.dart          # UserProfile, MeterModel, ReceiptModel, ConsumptionSummary, SupportTicket, AppNotification …
│   │   ├── mock/mock_data.dart         # ★ كل البيانات التجريبية (عدّاد 1000001، رصيد 18,500 …)
│   │   └── repositories/app_repository.dart  # واجهة البيانات + MockAppRepository
│   │
│   ├── services/
│   │   ├── storage_service.dart        # SharedPreferences (اللغة، البصمة، الإشعارات، الجلسة، المصباح)
│   │   ├── biometric_service.dart      # local_auth: البصمة/رمز الجهاز
│   │   └── export_service.dart         # تصدير الإيصال كصورة PNG + مشاركة + CSV
│   │
│   ├── state/                          # إدارة الحالة (ChangeNotifier + provider)
│   │   ├── settings_controller.dart    # اللغة/الإشعارات/البصمة/تذكّر الدخول
│   │   ├── session_controller.dart     # الدخول/الخروج/القفل/الفتح
│   │   ├── energy_controller.dart      # العدادات/المحافظ/الإيصالات/الاستهلاك/الشحن
│   │   ├── support_controller.dart     # التذاكر/التشخيص/الإشعارات
│   │   └── lamp_controller.dart        # حالة المصباح
│   │
│   ├── screens/                        # كل الشاشات (انظر الجدول أعلاه)
│   │
│   └── widgets/
│       ├── hanging_lamp.dart      # ★ المصباح المعلّق + LampAmbience (تعتيم الشاشة)
│       ├── gold_widgets.dart      # GoldCard, GoldButton, GoldOutlineButton, GoldTextField, GoldPill, InfoRow, CopyField, GoldDropdown…
│       ├── brand_logo.dart        # شعار «الوس» + GoldAvatar (بدون صور)
│       ├── app_headers.dart       # HomeHeader / ScreenHeader / DateChip / GoldTopBar / LanguageChip / DemoBadge
│       ├── app_bottom_nav.dart    # الشريط السفلي العائم
│       ├── app_drawer.dart        # القائمة الجانبية
│       ├── charts.dart            # BarWaveChart, LineAreaChart, MiniSparkline, RingProgress, BatteryGlyph
│       ├── stat_card.dart         # StatCard, MeterIsoGlyph, LiveBadge, MeterDigits, MethodTile
│       ├── segmented_tabs.dart    # SegmentedTabs / SegmentedWide
│       ├── receipt_ticket.dart    # الإيصال على شكل تذكرة (شق + QR + باركود)
│       └── ticket_card.dart       # بطاقة تذكرة الدعم مع مسار الحالة
│
├── test/
│   ├── helpers/fonts.dart         # تحميل الخطوط داخل بيئة الاختبار
│   ├── app_flow_test.dart         # اختبارات وظيفية (سحب الخيط، الدخول، الشحن، اللغة، التذاكر، تشغيل التطبيق كاملاً)
│   ├── goldens_preview_test.dart  # يولّد صور الشاشات للمراجعة البصرية
│   └── goldens/*.png              # صور الشاشات المرجعية
│
├── tools/
│   ├── generate_icons.py          # توليد أيقونات التطبيق من الشعار
│   └── build_preview.py           # تجميع صور الشاشات في صورة واحدة
│
└── docs/
    ├── screens_preview.png        # صورة تجميعية للشاشات
    └── backend_integration.md     # دليل الربط بقاعدة بيانات/خدمات حقيقية (كود جاهز)
```

### تدفّق التطبيق (Architecture)

```
main.dart
  └─ MultiProvider (Settings, Lamp, Session, Energy, Support)
      └─ AlwasApp (MaterialApp + Theme + Locale)
          └─ RootGate
               ├─ SplashScreen (1.5s)
               ├─ SessionStatus.signedOut → LoginScreen / RegisterScreen
               ├─ SessionStatus.locked    → LockScreen (بصمة)
               └─ SessionStatus.unlocked  → MainShell (الرئيسية/الدفع/الفواتير + Drawer)

Screens ←→ Controllers (ChangeNotifier) ←→ AppRepository ←→ MockAppRepository (الآن)
                                                          └→ ApiAppRepository (لاحقاً)
```

---

## 6) المكتبات وإصداراتها وطريقة إضافتها

كلها من [pub.dev](https://pub.dev) وموثوقة ومتوافقة مع Flutter 3.24 / Dart 3.5:

| المكتبة | الإصدار | الوظيفة | لماذا اخترناها |
|---|---|---|---|
| `provider` | `^6.1.2` | إدارة الحالة (ChangeNotifier) | خفيفة، رسمية، بدون code-gen |
| `shared_preferences` | `^2.3.2` | تخزين محلي (اللغة، الجلسة، المصباح…) | بسيطة وموثوقة |
| `local_auth` | `^2.3.0` | قفل التطبيق بالبصمة/رمز الجهاز | المكتبة المعتمدة من Flutter لـ BiometricPrompt |
| `share_plus` | `^10.0.2` | مشاركة الإيصال/البيانات | دعم واسع لكل التطبيقات |
| `path_provider` | `^2.1.4` | مسارات حفظ صورة الإيصال | رسمية |
| `qr_flutter` | `^4.1.0` | توليد QR حقيقي لرقم الإيصال | مرسوم بالكامل ولا يحتاج Native |
| `intl` | `^0.19.0` | تنسيق الأرقام والتواريخ | مطلوبة أيضاً من `flutter_localizations` |
| `flutter_localizations` | SDK | دعم RTL والتقويم | رسمية |
| `cupertino_icons` | `^1.0.8` | أيقونات iOS | افتراضية |
| `flutter_lints` (dev) | `^4.0.0` | قواعد جودة الكود | رسمية |

### طريقة الإضافة

```bash
flutter pub add provider shared_preferences local_auth share_plus path_provider qr_flutter intl
```

أو يدوياً في `pubspec.yaml` ثم:

```bash
flutter pub get
```

**بدائل اختيارية** (غير مستخدمة الآن لتقليل الاعتماديات):

- `fl_chart ^0.69.0` — رسوم بيانية جاهزة (المشروع يرسمها بـ CustomPainter لمطابقة التصميم بدقة).
- `pdf ^3.11.1` + `printing ^5.13.4` — تصدير الإيصال PDF بدل صورة PNG.
- `http ^1.2.2` أو `dio ^5.7.0` — عند ربط API حقيقي (مذكور في `docs/backend_integration.md`).
- `lottie ^3.1.0` — لو رغبت باستبدال حركة المصباح بملف Lottie (الحركة الحالية أفضل أداءً لأنها أصلية).

---

## 7) تعديل الألوان والتصميم

### أ) الألوان — ملف واحد فقط

```dart
// lib/core/theme/app_colors.dart
static const Color background  = Color(0xFF0B0906); // خلفية الشاشة
static const Color gold        = Color(0xFFE8A33D); // الذهبي الأساسي
static const Color goldLight   = Color(0xFFFFC96B); // ذهبي فاتح
static const Color goldDark    = Color(0xFFB9741C); // ذهبي غامق
static const Color card        = Color(0xFF15110D); // البطاقات
static const Color textPrimary = Color(0xFFF6F1E7);
```

أي تغيير هنا ينعكس فوراً على **كل** الشاشات (بطاقات، أزرار، إطارات، رسوم بيانية، المصباح).

### ب) الخطوط والأحجام والزوايا

```dart
// lib/core/theme/app_theme.dart
static const String fontFamily = 'Tajawal';   // الخط الأساسي
static const String numberFontFamily = 'Cairo'; // أرقام العناوين الكبيرة
static const double radiusCard = 22;   // زوايا البطاقات
static const double radiusField = 16;  // زوايا الحقول
static const double pagePadding = 16;  // حشوة الصفحات
```

### ج) إضافة خط جديد

1. ضع ملفات `.ttf` في `assets/fonts/`.
2. أضفها في `pubspec.yaml` تحت `fonts:`.
3. استخدم `fontFamily: 'اسم_العائلة'` أو غيّر `AppTheme.fontFamily`.

### د) تغيير نص أو ترجمته

كل النصوص في `lib/core/l10n/app_strings.dart` بصيغة:

```dart
String get home => pick('الرئيسية', 'Home');
```

أضف/عدّل النص في مكان واحد فقط ليظهر في كل الشاشات وبكل اللغات.

### هـ) تغيير بيانات العرض (الرصيد، العدادات، الإيصالات)

```
lib/data/mock/mock_data.dart
```

- `meters` → العدادات وأرصدتها.
- `receipts()` → سجل الفواتير.
- `daysPeriod / monthsPeriod` → نقاط الرسم البياني.
- `tariffPerKwh = 250` → سعر الكيلوواط المستخدم في حساب الطاقة المضافة.

---

## 8) إضافة صفحة جديدة

### مثال: صفحة «البلاغات المغلقة»

**1) أنشئ الملف** `lib/screens/reports/closed_reports_screen.dart`:

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/models.dart';
import '../../state/support_controller.dart';
import '../../widgets/app_headers.dart';
import '../../widgets/gold_widgets.dart';
import '../../widgets/ticket_card.dart';

class ClosedReportsScreen extends StatelessWidget {
  const ClosedReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final support = context.watch<SupportController>();
    // البلاغات المغلقة فقط
    final closed = support.tickets
        .where((t) => t.status == TicketStatus.resolved)
        .toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: ScreenHeader(title: s.pick('البلاغات المغلقة', 'Closed reports')),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  GoldCard(child: Text(s.ticketsLog)),
                  const SizedBox(height: 12),
                  ...closed.map((t) => TicketCard(ticket: t)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
```

**2) أضف النصوص** في `app_strings.dart` إن لزم.

**3) اربط التنقل** من أي مكان:

```dart
Navigator.of(context).push(
  MaterialPageRoute(builder: (_) => const ClosedReportsScreen()),
);
```

**4) أو أضفها كتبويب رابع في الشريط السفلي**:

```dart
// lib/widgets/app_bottom_nav.dart → أضف عنصراً
_NavItem(Icons.report_outlined, Icons.report_rounded, s.pick('البلاغات', 'Reports')),

// lib/screens/main_shell.dart → أضف الشاشة في IndexedStack بنفس الترتيب
children: const [HomeScreen(), PaymentScreen(), InvoicesScreen(), ClosedReportsScreen()],
```

**قواعد التصميم عند إضافة صفحة:** استخدم `ScreenHeader` أو `HomeHeader` + `GoldCard` + `GoldButton`
+ `AppColors` من الثيم فقط، حتى تبقى الهوية متطابقة.

---

## 9) استخراج ملف APK

> 🟢 **تعمل من الهاتف فقط ولا تملك كمبيوتراً؟** لا تحتاج كل الخطوات التالية.
> المشروع مُجهَّز للبناء السحابي: ارفع ملف ZIP إلى GitHub ثم ابنِ على **Codemagic**
> (عبر `codemagic.yaml`) أو على **GitHub Actions** (عبر `.github/workflows/build-apk.yml`)،
> ونزّل الـ APK من قسم Artifacts.
> **الدليل الكامل خطوة بخطوة: [`BUILD_GUIDE.md`](BUILD_GUIDE.md).**

### أ) نسخة تجريبية سريعة (بدون توقيع إصدار)

```bash
flutter build apk --debug
# الناتج: build/app/outputs/flutter-apk/app-debug.apk
```

### ب) نسخة Release موقّعة (المطلوبة للنشر)

**1) أنشئ مفتاح التوقيع مرة واحدة:**

```bash
keytool -genkey -v -keystore ~/alwas-release.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias alwas-release
```

**2) أنشئ ملف** `android/key.properties` (انسخ `key.properties.example`):

```properties
storePassword=كلمة_مرور_المخزن
keyPassword=كلمة_مرور_المفتاح
keyAlias=alwas-release
storeFile=/home/اسمك/alwas-release.jks
```

> المشروع يقرأ هذا الملف تلقائياً في `android/app/build.gradle`.
> إن لم يوجد، يستخدم توقيع debug حتى لا يتعطّل البناء.

**3) ابنِ الملف:**

```bash
flutter build apk --release
# APK واحد لكل المعماريات: build/app/outputs/flutter-apk/app-release.apk
```

**4) نسخة أصغر (لكل معمارية على حدة) — موصى بها للنشر:**

```bash
flutter build apk --release --split-per-abi
# app-armeabi-v7a-release.apk  (أغلب الأجهزة القديمة)
# app-arm64-v8a-release.apk    (أغلب الأجهزة الحديثة)
# app-x86_64-release.apk       (المحاكيات)
```

**5) للنشر على Google Play (صيغة AAB):**

```bash
flutter build appbundle --release
# build/app/outputs/bundle/release/app-release.aab
```

**6) التثبيت على الجهاز:**

```bash
flutter install            # عبر USB
# أو
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

### ج) البناء السحابي (بدون كمبيوتر) — Codemagic

الملف **`codemagic.yaml`** جاهز ويحتوي مسارَين:

| Workflow | الناتج |
|---|---|
| `android-release-apk` | `app-release.apk` + نسخ `--split-per-abi` + `app-release.aab` |
| `android-debug-apk` | `app-debug.apk` (أسرع للتجربة) |

خطوات مختصرة (التفاصيل في `BUILD_GUIDE.md`):

1. ارفع المشروع إلى GitHub (ملف ZIP واحد يكفي — سكربت البناء يستخرجه تلقائياً).
2. [codemagic.io](https://codemagic.io) ← تسجيل بحساب GitHub ← Add application ← اختر المستودع.
3. Start new build ← Workflow: **Alwas Energy • Release APK**.
4. بعد 5–12 دقيقة: نزّل `app-release.apk` من **Artifacts** وثبّته على هاتفك.

**التوقيع**: إن لم تُضف مفاتيح keystore في متغيرات بيئة Codemagic، يُبنى الـ APK بتوقيع
debug (يُثبَّت على الهاتف ويعمل، لكن Google Play سيرفضه). لإضافة توقيع رسمي راجع
`BUILD_GUIDE.md` (قسم «توقيع رسمي») — الأسماء المدعومة:
`CM_KEYSTORE`, `CM_KEYSTORE_PASSWORD`, `CM_KEY_ALIAS`, `CM_KEY_PASSWORD`.

**بديل مجاني**: GitHub Actions عبر `.github/workflows/build-apk.yml` (تبويب Actions ←
Build Release APK ← Run workflow ← نزّل الـ APK من Artifacts).

### د) تغيير رقم الإصدار

```yaml
# pubspec.yaml
version: 1.0.0+1   #  1.0.0 = versionName   |   1 = versionCode
```

---

## 10) ربط قاعدة بيانات وخدمات حقيقية

البنية جاهزة لذلك: الواجهات لا تعرف مصدر البيانات، فقط `AppRepository`.

```dart
// lib/data/repositories/app_repository.dart
abstract class AppRepository {
  Future<UserProfile?> signIn({required String username, required String password});
  Future<UserProfile?> currentUser();
  Future<UserProfile> register({...});
  Future<List<MeterModel>> fetchMeters();
  Future<List<PaymentMethodModel>> fetchPaymentMethods();
  Future<List<ReceiptModel>> fetchReceipts();
  Future<ConsumptionSummary> fetchConsumption(ConsumptionRange range);
  Future<List<SupportTicket>> fetchTickets();
  Future<SupportTicket> createTicket({required String title, required String details});
  Future<List<AppNotification>> fetchNotifications();
  Future<ReceiptModel> createTopUp({required MeterModel meter, required double amount, required PaymentMethodModel method});
  Future<UserProfile> updateProfile(UserProfile user);
}
```

الخطوات باختصار:

1. نفّذ `ApiAppRepository` (كود كامل جاهز في **`docs/backend_integration.md`**).
2. في `lib/main.dart` استبدل سطراً واحداً:

```dart
// final AppRepository repo = MockAppRepository();
final AppRepository repo = ApiAppRepository(baseUrl: 'https://api.example.com', token: ...);
```

3. تأكد من الصلاحيات والشبكة (`INTERNET` موجودة بالفعل في `AndroidManifest.xml`).

> ⚠️ **مهم**: الشحن والدفع في هذه النسخة **محاكاة تجريبية** ولا يخصم أي مبلغ حقيقي.
> لتنفيذ شحن حقيقي يجب الربط بمزوّد خدمة معتمد (بوابة دفع مثل جيب/جوالي/فلوسك أو API شركة الكهرباء)،
> والتحقق من الإيصال في الخادم (Server-side verification) قبل إضافة الرصيد.

---

## 11) الاختبارات وصور المعاينة

```bash
# كل الاختبارات
flutter test

# الاختبارات الوظيفية فقط (سحب خيط المصباح، الدخول، الشحن، اللغة، التذاكر، التشخيص، تشغيل التطبيق كاملاً)
flutter test test/app_flow_test.dart

# توليد صور الشاشات (Golden) في test/goldens/
flutter test --update-goldens test/goldens_preview_test.dart

# صورة تجميعية 3×3
python3 tools/build_preview.py     # → docs/screens_preview.png

# إعادة توليد أيقونات التطبيق
python3 tools/generate_icons.py
```

النتيجة الحالية:

```
flutter analyze  →  No issues found!
flutter test     →  19/19 اختباراً ناجحاً  (10 وظيفية + 9 صور شاشات)
```

---

## 12) ملاحظات مهمة وحدود النسخة الحالية

1. **لا يوجد شحن أو دفع حقيقي**: كل العمليات تحاكي الخادم محلياً (`MockAppRepository`) — لا خصم أموال.
2. **لا يوجد مزوّد خدمة مربوط**: أرقام المحافظ (700000001 …) والعدادات **وهمية** لأغراض العرض فقط.
3. **قفل البصمة**: يعمل فعلياً عبر `local_auth`، ويحتاج جهازاً به بصمة مسجّلة؛ على المحاكي يُفعّل الوضع التجريبي.
4. **حفظ الإيصال** يكتب الصورة في مجلد التطبيق الخارجي (`Android/data/com.alwas.alwas_energy/files/alwas_receipts/`).
   لإظهاره في معرض الصور أضف حزمة مثل `gal` أو استخدم MediaStore (مشروح في `docs/backend_integration.md`).
5. **الباركود** في الإيصال مرسوم هندسياً من رقم الإيصال لأغراض بصرية؛ للاستخدام الرسمي استخدم `barcode_widget` لتوليد Code128 حقيقي.
6. **اللغة**: العربية والإنجليزية فقط. لإضافة لغة ثالثة: أضف قيمة في `enum AppLang` وفرعاً في `pick()`.
7. **الأيقونات**: مولّدة برمجياً (`tools/generate_icons.py`)؛ للأيقونات التكيفية (Adaptive Icons) أضف `mipmap-anydpi-v26/ic_launcher.xml`.
8. هذا المشروع مستقل تماماً ولا ينتمي لأي شركة كهرباء؛ استخدم الشعار والاسم حسب ما يلزم قانونياً عند النشر.

---

### إخلاء مسؤولية

التطبيق نموذج برمجي جاهز للتطوير. المسؤولية عن ربط مزوّد خدمة معتمد، وأمان المفاتيح، وحماية بيانات
المشتركين (تشفير، HTTPS، مصادقة tokens، تسجيل خروج تلقائي…) تقع على عاتق من ينشره تجارياً.

**تم بناء المشروع بالكامل: واجهات + حركات + منطق + اختبارات + توثيق.** ✅
