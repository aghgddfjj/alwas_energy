import 'package:alwas_energy/core/l10n/app_strings.dart';
import 'package:alwas_energy/core/theme/app_theme.dart';
import 'package:alwas_energy/data/mock/mock_data.dart';
import 'package:alwas_energy/data/repositories/app_repository.dart';
import 'package:alwas_energy/screens/home/home_screen.dart';
import 'package:alwas_energy/screens/invoices/invoices_screen.dart';
import 'package:alwas_energy/screens/invoices/receipt_details_screen.dart';
import 'package:alwas_energy/screens/lock_screen.dart';
import 'package:alwas_energy/screens/login_screen.dart';
import 'package:alwas_energy/screens/payment/payment_screen.dart';
import 'package:alwas_energy/screens/settings/settings_screen.dart';
import 'package:alwas_energy/screens/support/support_screen.dart';
import 'package:alwas_energy/services/storage_service.dart';
import 'package:alwas_energy/state/energy_controller.dart';
import 'package:alwas_energy/state/lamp_controller.dart';
import 'package:alwas_energy/state/session_controller.dart';
import 'package:alwas_energy/state/settings_controller.dart';
import 'package:alwas_energy/state/support_controller.dart';
import 'package:alwas_energy/widgets/app_drawer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'helpers/fonts.dart';

/// ===========================================================================
///  اختبارات "ذهبية" لتوليد صور للشاشات (Preview) ومراجعة التصميم بصرياً.
///  التشغيل:
///      flutter test --update-goldens test/goldens_preview_test.dart
///  تخرج الصور إلى test/goldens/*.png
/// ===========================================================================
/// تاريخ ثابت حتى تبقى صور الشاشات قابلة للمقارنة في كل تشغيل
final DateTime _fixedNow = DateTime(2026, 10, 28, 6, 58);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await loadAppFonts();
    await loadMaterialIcons();
  });

  testWidgets(
      '01 login',
      (tester) async =>
          _render(tester, const LoginScreen(), name: '01_login', waitMs: 1200));

  testWidgets(
      '02 lock',
      (tester) async => _render(
          tester, const LockScreen(autoAuthenticate: false),
          name: '02_lock', waitMs: 400));

  testWidgets(
      '03 home',
      (tester) async => _render(
          tester, Scaffold(body: HomeScreen(now: _fixedNow)),
          name: '03_home', waitMs: 900));

  testWidgets(
      '04 payment',
      (tester) async => _render(
          tester, Scaffold(body: PaymentScreen(now: _fixedNow)),
          name: '04_payment', waitMs: 900));

  testWidgets(
      '05 invoices',
      (tester) async => _render(
          tester, Scaffold(body: InvoicesScreen(now: _fixedNow)),
          name: '05_invoices', waitMs: 900));

  testWidgets(
      '06 receipt',
      (tester) async => _render(
          tester, ReceiptDetailsScreen(receipt: MockData.receipts().first),
          name: '06_receipt', waitMs: 700));

  testWidgets(
      '07 support',
      (tester) async => _render(tester, const SupportScreen(),
          name: '07_support', waitMs: 700));

  testWidgets(
      '08 settings',
      (tester) async => _render(tester, const SettingsScreen(),
          name: '08_settings', waitMs: 700));

  testWidgets(
      '09 drawer',
      (tester) async => _render(
          tester,
          const Scaffold(
            backgroundColor: Color(0xFF0B0906),
            body: Directionality(
              textDirection: TextDirection.rtl,
              child: SizedBox(width: 356, child: AppDrawer()),
            ),
          ),
          name: '09_drawer',
          waitMs: 600));
}

// ---------------------------------------------------------------------------
//  تحميل الخطوط (خطوط التطبيق + خط أيقونات Material)
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
//  بناء الشاشة ضمن تطبيق مصغّر بنفس الثيم واللغة، ثم التقاط الصورة
// ---------------------------------------------------------------------------
Future<void> _render(
  WidgetTester tester,
  Widget screen, {
  required String name,
  int waitMs = 800,
}) async {
  tester.view.physicalSize = const Size(430, 932);
  tester.view.devicePixelRatio = 1.0;
  addTearDown(tester.view.reset);

  late StorageService storage;
  late EnergyController energy;
  late SupportController support;
  final repo = MockAppRepository();

  await tester.runAsync(() async {
    storage = StorageService();
    await storage.init();
    energy = EnergyController(repo);
    await energy.load();
    support = SupportController(repo);
    await support.load();
  });

  await tester.pumpWidget(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppSettingsController(storage)),
        ChangeNotifierProvider(create: (_) => LampController(storage)),
        ChangeNotifierProvider(
          create: (_) => SessionController(repository: repo, storage: storage),
        ),
        ChangeNotifierProvider.value(value: energy),
        ChangeNotifierProvider.value(value: support),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          AppStringsDelegate(),
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: screen,
      ),
    ),
  );

  await tester.pump(Duration(milliseconds: waitMs));

  await expectLater(
    find.byType(MaterialApp),
    matchesGoldenFile('goldens/$name.png'),
  );
}
