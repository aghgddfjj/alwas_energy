import 'dart:io';

import 'package:flutter/services.dart';

/// ===========================================================================
///  تحميل الخطوط في بيئة الاختبار
///  بدونها يستخدم Flutter خط الاختبار الافتراضي (كل حرف في مربع ثابت العرض)
///  فتظهر النصوص أطول من الحقيقة وقد تنتج تحذيرات overflow غير واقعية.
/// ===========================================================================
Future<void> loadAppFonts() async {
  final tajawal = FontLoader('Tajawal');
  for (final f in [
    'Tajawal-Light.ttf',
    'Tajawal-Regular.ttf',
    'Tajawal-Medium.ttf',
    'Tajawal-Bold.ttf',
    'Tajawal-ExtraBold.ttf',
  ]) {
    tajawal.addFont(rootBundle.load('assets/fonts/$f'));
  }
  await tajawal.load();

  final cairo = FontLoader('Cairo');
  cairo.addFont(rootBundle.load('assets/fonts/Cairo-Variable.ttf'));
  await cairo.load();
}

/// خط أيقونات Material (يُحمَّل من مسار Flutter SDK إن وُجد)
Future<void> loadMaterialIcons() async {
  final root = Platform.environment['FLUTTER_ROOT'] ?? '';
  final candidates = <String>[
    if (root.isNotEmpty)
      '$root/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
    '${Platform.environment['HOME'] ?? ''}/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf',
  ];
  for (final path in candidates) {
    final file = File(path);
    if (file.existsSync()) {
      final loader = FontLoader('MaterialIcons');
      loader.addFont(
        Future<ByteData>.value(ByteData.sublistView(file.readAsBytesSync())),
      );
      await loader.load();
      return;
    }
  }
}
