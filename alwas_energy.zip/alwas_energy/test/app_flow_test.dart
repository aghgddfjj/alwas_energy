import 'package:alwas_energy/app.dart';
import 'package:alwas_energy/core/l10n/app_strings.dart';
import 'package:alwas_energy/core/theme/app_theme.dart';
import 'package:alwas_energy/data/mock/mock_data.dart';
import 'package:alwas_energy/data/models/models.dart';
import 'package:alwas_energy/data/repositories/app_repository.dart';
import 'package:alwas_energy/screens/login_screen.dart';
import 'package:alwas_energy/screens/main_shell.dart';
import 'package:alwas_energy/screens/splash_screen.dart';
import 'package:alwas_energy/services/storage_service.dart';
import 'package:alwas_energy/state/energy_controller.dart';
import 'package:alwas_energy/state/lamp_controller.dart';
import 'package:alwas_energy/state/session_controller.dart';
import 'package:alwas_energy/state/settings_controller.dart';
import 'package:alwas_energy/state/support_controller.dart';
import 'package:alwas_energy/widgets/hanging_lamp.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'helpers/fonts.dart';

/// ===========================================================================
///  اختبارات الوظائف الأساسية (بدون واجهات ذهبية)
///  التشغيل:  flutter test test/app_flow_test.dart
/// ===========================================================================
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    await loadAppFonts();
    await loadMaterialIcons();
  });

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('المصباح المعلّق', () {
    test('يبدأ مضاءً ويتبدّل عند السحب', () async {
      final storage = StorageService();
      await storage.init();
      final lamp = LampController(storage);
      expect(lamp.isOn, isTrue);
      await lamp.toggle();
      expect(lamp.isOn, isFalse);
      await lamp.toggle();
      expect(lamp.isOn, isTrue);
    });

    testWidgets('يُستدعى onToggle عند سحب الخيط', (tester) async {
      var toggled = 0;
      final storage = StorageService();
      await tester.runAsync(storage.init);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: StatefulBuilder(
                builder: (context, setState) => HangingLamp(
                  isOn: toggled.isEven,
                  width: 260,
                  height: 320,
                  onToggle: () => setState(() => toggled++),
                ),
              ),
            ),
          ),
        ),
      );
      await tester.pump(const Duration(milliseconds: 100));

      // الخيط يقع يمين المصباح: نسحب للأسفل
      final lampFinder = find.byType(HangingLamp);
      final rect = tester.getRect(lampFinder);
      final cordPoint = Offset(
        rect.center.dx + 260 * 0.109,
        rect.top + 320 * 0.22,
      );
      await tester.dragFrom(cordPoint, const Offset(0, 60));
      await tester.pump(const Duration(milliseconds: 100));

      expect(toggled, 1);
    });
  });

  group('الجلسة وتسجيل الدخول', () {
    test('رفض بيانات خاطئة وقبول الحساب التجريبي', () async {
      final storage = StorageService();
      await storage.init();
      final repo = MockAppRepository();
      final session = SessionController(repository: repo, storage: storage);

      final bad = await session.signIn(username: 'x', password: '1');
      expect(bad, isFalse);
      expect(session.status, SessionStatus.signedOut);

      final ok = await session.signIn(
        username: MockData.demoUsername,
        password: MockData.demoPassword,
      );
      expect(ok, isTrue);
      expect(session.status, SessionStatus.unlocked);
      expect(session.user?.name, MockData.user.name);
    });

    test('تغيير اللغة يغيّر النصوص', () async {
      final storage = StorageService();
      await storage.init();
      final settings = AppSettingsController(storage);
      expect(settings.strings.home, 'الرئيسية');
      await settings.toggleLanguage();
      expect(settings.lang, AppLang.en);
      expect(settings.strings.home, 'Home');
      await settings.toggleLanguage();
      expect(settings.strings.home, 'الرئيسية');
    });
  });

  group('الشحن والاستهلاك', () {
    test('الشحن يزيد الرصيد ويضيف إيصالاً', () async {
      final repo = MockAppRepository();
      final energy = EnergyController(repo);
      await energy.load();

      final before = energy.selectedMeter!.balance;
      final receiptsBefore = energy.receiptsCount;
      expect(energy.selectedMethod, isNotNull);

      final receipt = await energy.topUp(5000);

      expect(receipt.amount, 5000);
      expect(receipt.kwh, closeTo(20.0, 0.001));
      expect(energy.selectedMeter!.balance, before + 5000);
      expect(energy.receiptsCount, receiptsBefore + 1);
      expect(energy.receipts.first.receiptNumber, receipt.receiptNumber);
    });

    test('اختيار العداد وطريقة الدفع وتحليل الاستهلاك', () async {
      final repo = MockAppRepository();
      final energy = EnergyController(repo);
      await energy.load();

      expect(energy.meters.length, 2);
      energy.selectMeter(1);
      expect(energy.selectedMeterIndex, 1);
      energy.selectMeterByNumber('1000001');
      expect(energy.selectedMeterIndex, 0);

      energy.selectMethod(2);
      expect(energy.selectedMethod!.id, 'floosak');

      await energy.setRange(ConsumptionRange.months);
      expect(energy.summary, isNotNull);
      expect(energy.summary!.currentPeriod.length, greaterThan(2));
    });
  });

  group('الدعم والإشعارات', () {
    test('إنشاء تذكرة يضيفها للسجل', () async {
      final repo = MockAppRepository();
      final support = SupportController(repo);
      await support.load();
      final before = support.tickets.length;

      final ticket = await support.createTicket(
        title: 'تأخر شحن',
        details: 'لم يصل الرصيد',
      );

      expect(ticket.status, TicketStatus.open);
      expect(support.tickets.length, before + 1);
      expect(support.tickets.first.id, ticket.id);
    });

    test('التشخيص السريع يكتمل بنجاح', () async {
      final repo = MockAppRepository();
      final support = SupportController(repo);
      await support.load();
      final result = await support.runDiagnostics();
      expect(result, isTrue);
      expect(support.diagnosing, isFalse);
    });
  });

  group('واجهة تسجيل الدخول', () {
    testWidgets('إدخال البيانات الصحيحة يفتح الجلسة', (tester) async {
      tester.view.physicalSize = const Size(430, 932);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.reset);

      late StorageService storage;
      late EnergyController energy;
      late SupportController support;
      final repo = MockAppRepository();
      await tester.runAsync(() async {
        storage = StorageService();
        await storage.init();
        energy = EnergyController(repo);
        await energy.load();
        support = SupportController(repo);
        await support.load();
      });

      final session = SessionController(repository: repo, storage: storage);

      await tester.pumpWidget(
        MultiProvider(
          providers: [
            ChangeNotifierProvider(
                create: (_) => AppSettingsController(storage)),
            ChangeNotifierProvider(create: (_) => LampController(storage)),
            ChangeNotifierProvider.value(value: session),
            ChangeNotifierProvider.value(value: energy),
            ChangeNotifierProvider.value(value: support),
          ],
          child: MaterialApp(
            theme: AppTheme.dark,
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar'), Locale('en')],
            localizationsDelegates: const [
              AppStringsDelegate(),
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: const LoginScreen(),
          ),
        ),
      );
      await tester.pump(const Duration(milliseconds: 300));

      final fields = find.byType(TextFormField);
      expect(fields, findsNWidgets(2));
      await tester.enterText(fields.at(0), MockData.demoUsername);
      await tester.enterText(fields.at(1), MockData.demoPassword);
      await tester.pump();

      await tester.tap(find.text('تسجيل الدخول').last);
      await tester.pump(const Duration(milliseconds: 1200));

      expect(session.status, SessionStatus.unlocked);
    });
  });

  group('تشغيل التطبيق كاملاً', () {
    testWidgets('سبلاش ← تسجيل الدخول ← الواجهة الرئيسية', (tester) async {
      tester.view.physicalSize = const Size(430, 932);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.reset);

      late StorageService storage;
      late EnergyController energy;
      late SupportController support;
      final repo = MockAppRepository();
      await tester.runAsync(() async {
        storage = StorageService();
        await storage.init();
        energy = EnergyController(repo);
        await energy.load();
        support = SupportController(repo);
        await support.load();
      });

      await tester.pumpWidget(
        MultiProvider(
          providers: [
            ChangeNotifierProvider(
                create: (_) => AppSettingsController(storage)),
            ChangeNotifierProvider(create: (_) => LampController(storage)),
            ChangeNotifierProvider(
              create: (_) =>
                  SessionController(repository: repo, storage: storage),
            ),
            ChangeNotifierProvider.value(value: energy),
            ChangeNotifierProvider.value(value: support),
          ],
          child: const AlwasApp(),
        ),
      );

      // شاشة البداية
      await tester.pump(const Duration(milliseconds: 200));
      expect(find.byType(SplashScreen), findsOneWidget);

      // بعد انتهاء التحميل يظهر تسجيل الدخول
      await tester.pump(const Duration(milliseconds: 1800));
      await tester.pump(const Duration(milliseconds: 600));
      expect(find.byType(LoginScreen), findsOneWidget);

      // تسجيل الدخول بالحساب التجريبي
      final fields = find.byType(TextFormField);
      await tester.enterText(fields.at(0), MockData.demoUsername);
      await tester.enterText(fields.at(1), MockData.demoPassword);
      await tester.pump();
      await tester.tap(find.text('تسجيل الدخول').last);
      await tester.pump(const Duration(milliseconds: 1500));
      await tester.pump(const Duration(milliseconds: 600));

      // الواجهة الرئيسية بالشريط السفلي
      expect(find.byType(MainShell), findsOneWidget);
      expect(find.text('الرئيسية'), findsWidgets);
      expect(find.text('الفواتير'), findsWidgets);
    });
  });
}
