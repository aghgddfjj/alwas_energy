#!/usr/bin/env python3
# =============================================================================
#  يجمع صور الشاشات (test/goldens/*.png) في صورة واحدة 3×3 لعرض التصميم.
#  الاستخدام:  python3 tools/build_preview.py
#  الناتج   :  docs/screens_preview.png
# =============================================================================
import os

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GOLDENS = os.path.join(ROOT, "test", "goldens")
OUT_DIR = os.path.join(ROOT, "docs")
OUT = os.path.join(OUT_DIR, "screens_preview.png")

FILES = [
    "02_lock.png",
    "06_receipt.png",
    "04_payment.png",
    "01_login.png",
    "07_support.png",
    "05_invoices.png",
    "03_home.png",
    "09_drawer.png",
    "08_settings.png",
]

BG = (10, 8, 6)
GOLD = (232, 163, 61)
PAD = 18
TARGET_W = 330


def main():
    if not os.path.isdir(GOLDENS):
        raise SystemExit("لم يتم العثور على مجلد test/goldens — شغّل الاختبارات أولاً.")
    os.makedirs(OUT_DIR, exist_ok=True)

    shots = []
    for name in FILES:
        path = os.path.join(GOLDENS, name)
        if not os.path.exists(path):
            continue
        img = Image.open(path).convert("RGB")
        h = int(img.height * TARGET_W / img.width)
        shots.append(img.resize((TARGET_W, h), Image.LANCZOS))

    if not shots:
        raise SystemExit("لا توجد صور.")

    cols = 3
    rows = (len(shots) + cols - 1) // cols
    cell_h = shots[0].height
    header = 70
    width = PAD + cols * (TARGET_W + PAD)
    height = header + rows * (cell_h + PAD) + PAD

    canvas = Image.new("RGB", (width, height), BG)
    draw = ImageDraw.Draw(canvas)

    try:
        font = ImageFont.truetype(
            os.path.join(ROOT, "assets", "fonts", "Tajawal-Bold.ttf"), 26
        )
    except OSError:
        font = ImageFont.load_default()
    draw.text(
        (width / 2, header / 2),
        "الوس للطاقة — شاشات التطبيق",
        font=font,
        fill=GOLD,
        anchor="mm",
        direction="rtl",
        language="ar",
    )

    for i, shot in enumerate(shots):
        r, c = divmod(i, cols)
        x = PAD + c * (TARGET_W + PAD)
        y = header + r * (cell_h + PAD)
        # إطار ذهبي رفيع
        draw.rectangle([x - 2, y - 2, x + TARGET_W + 1, y + cell_h + 1], outline=GOLD)
        canvas.paste(shot, (x, y))

    canvas.save(OUT)
    print("saved:", OUT, canvas.size)


if __name__ == "__main__":
    main()
