#!/usr/bin/env python3
# =============================================================================
#  مولد أيقونات التطبيق (App Icons Generator)
#  الاستخدام:
#      python3 tools/generate_icons.py
#  ينتج:
#      android/app/src/main/res/mipmap-*/ic_launcher.png   (أيقونة المشغّل)
#      assets/images/logo_mark.png                        (شعار عالي الدقة)
#      assets/icons/ic_meter.png                          (أيقونة عدّاد)
#
#  المتطلبات:  pip install pillow
#  ملاحظة: يستخدم خط Tajawal الموجود في assets/fonts (دعم تشكيل عربي عبر raqm)
# =============================================================================
import os

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = os.path.join(ROOT, "assets", "fonts", "Tajawal-ExtraBold.ttf")

GOLD_LIGHT = (255, 212, 137)
GOLD = (232, 163, 61)
GOLD_DARK = (140, 92, 24)
BACKGROUND = (11, 9, 6)


def radial_glow(size, color, inner=0.0, outer=1.0):
    """ينشئ هالة دائرية متدرجة بلون محدد"""
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(glow)
    steps = 60
    for i in range(steps, 0, -1):
        t = i / steps
        radius = size / 2 * t
        alpha = int(200 * (1 - t) ** 2.2)
        draw.ellipse(
            [
                size / 2 - radius,
                size / 2 - radius,
                size / 2 + radius,
                size / 2 + radius,
            ],
            fill=color + (alpha,),
        )
    return glow.filter(ImageFilter.GaussianBlur(size / 40))


def make_base(size, radius_ratio=0.24):
    """خلفية داكنة + هالة ذهبية + إطار ذهبي متدرج + مونوجرام (وس)"""
    img = Image.new("RGBA", (size, size), BACKGROUND + (255,))

    # هالة ذهبية في الأعلى
    glow = radial_glow(size, GOLD, inner=0.1)
    glow = glow.resize((size, size))
    top_glow = glow.crop((0, 0, size, int(size * 0.75)))
    img.alpha_composite(top_glow, (0, 0))

    draw = ImageDraw.Draw(img)
    margin = int(size * 0.055)
    radius = int(size * radius_ratio)

    # إطار ذهبي متدرج (ثلاث طبقات)
    for i, color in enumerate([GOLD_DARK, GOLD, GOLD_LIGHT]):
        inset = margin + i * max(1, int(size * 0.004))
        draw.rounded_rectangle(
            [inset, inset, size - inset, size - inset],
            radius=radius,
            outline=color,
            width=max(2, int(size * 0.006)),
        )

    # مونوجرام "الوس" بتدرّج ذهبي
    try:
        font = ImageFont.truetype(FONT, int(size * 0.26))
    except OSError:
        font = ImageFont.load_default()

    text = "الوس"
    mask = Image.new("L", (size, size), 0)
    mdraw = ImageDraw.Draw(mask)
    mdraw.text(
        (size / 2, size / 2),
        text,
        font=font,
        fill=255,
        anchor="mm",
        direction="rtl",
        language="ar",
    )

    # تدرّج لوني للنص
    grad = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(grad)
    for y in range(size):
        t = y / size
        color = tuple(
            int(GOLD_LIGHT[i] + (GOLD_DARK[i] - GOLD_LIGHT[i]) * t) for i in range(3)
        )
        gdraw.line([(0, y), (size, y)], fill=color + (255,))
    img.paste(grad, (0, 0), mask)

    # توهّج خفيف خلف النص
    glow_mask = mask.filter(ImageFilter.GaussianBlur(size / 45))
    glow_gold = Image.new("RGBA", (size, size), GOLD + (200,))
    img.alpha_composite(Image.composite(glow_gold, Image.new("RGBA", (size, size), (0, 0, 0, 0)), glow_mask))

    return img


def make_meter_icon(size):
    """أيقونة عدّاد ذهبية بسيطة (تُستخدم داخل التطبيق)"""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    pad = size * 0.12
    draw.rounded_rectangle(
        [pad, pad * 0.6, size - pad, size - pad * 1.1],
        radius=size * 0.22,
        fill=(26, 20, 14, 255),
        outline=GOLD,
        width=max(2, int(size * 0.03)),
    )
    # برق
    bolt = [
        (size * 0.56, size * 0.24),
        (size * 0.36, size * 0.53),
        (size * 0.50, size * 0.53),
        (size * 0.44, size * 0.78),
        (size * 0.66, size * 0.46),
        (size * 0.52, size * 0.46),
    ]
    draw.polygon(bolt, fill=GOLD_LIGHT)
    return img


def main():
    master = make_base(1024)
    sizes = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192,
    }
    for folder, px in sizes.items():
        out_dir = os.path.join(ROOT, "android", "app", "src", "main", "res", folder)
        os.makedirs(out_dir, exist_ok=True)
        master.resize((px, px), Image.LANCZOS).convert("RGB").save(
            os.path.join(out_dir, "ic_launcher.png")
        )
        print("icon:", folder, px)

    images_dir = os.path.join(ROOT, "assets", "images")
    icons_dir = os.path.join(ROOT, "assets", "icons")
    os.makedirs(images_dir, exist_ok=True)
    os.makedirs(icons_dir, exist_ok=True)
    master.resize((512, 512), Image.LANCZOS).save(os.path.join(images_dir, "logo_mark.png"))
    make_meter_icon(256).save(os.path.join(icons_dir, "ic_meter.png"))
    print("done")


if __name__ == "__main__":
    main()
